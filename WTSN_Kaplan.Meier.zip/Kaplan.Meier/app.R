library(shiny)
library(shinythemes)
library(DT)
library(survival)
library(survminer)
library(dplyr)
library(ggplot2)
# 设置最大上传文件大小为100MB
options(shiny.maxRequestSize = 100 * 1024^2)
# UI界面
ui <- fluidPage(
  theme = shinytheme("flatly"),
  titlePanel("单基因预后分析 - KM曲线绘制"),
  
  sidebarLayout(
    sidebarPanel(
      width = 3,
      h4("数据上传"),
      
      # 数据上传区域
      fileInput("exprFile", "上传表达谱CSV文件",
                accept = c(".csv", ".txt"),
                buttonLabel = "选择文件"),
      helpText("第一行为样本名，第一列为基因名"),
      
      fileInput("survFile", "上传生存数据CSV文件",
                accept = c(".csv", ".txt"),
                buttonLabel = "选择文件"),
      helpText("包含三列：sample, OS, OS.time"),
      
      hr(),
      h4("分析设置"),
      
      # 基因输入
      textInput("geneName", "输入基因名称：", 
                value = "A1BG",
                placeholder = "例如: A1BG"),
      
      # 分组方法选择
      selectInput("cutMethod", "选择分组方法：",
                  choices = c("最佳截点法" = "optimal",
                              "中位数" = "median",
                              "平均值" = "mean",
                              "自定义阈值" = "custom"),
                  selected = "optimal"),
      
      # 自定义阈值输入
      conditionalPanel(
        condition = "input.cutMethod == 'custom'",
        numericInput("customCutoff", "自定义阈值：", value = 1, min = 0)
      ),
      
      # 颜色选择
      selectInput("highColor", "高表达组颜色：",
                  choices = c("红色" = "#E41A1C",
                              "蓝色" = "#377EB8",
                              "绿色" = "#4DAF4A",
                              "紫色" = "#984EA3"),
                  selected = "#E41A1C"),
      
      selectInput("lowColor", "低表达组颜色：",
                  choices = c("蓝色" = "#377EB8",
                              "红色" = "#E41A1C",
                              "绿色" = "#4DAF4A",
                              "紫色" = "#984EA3"),
                  selected = "#377EB8"),
      
      # 分析按钮
      actionButton("runAnalysis", "生成KM曲线", 
                   class = "btn-primary btn-block",
                   icon = icon("chart-line"))
    ),
    
    mainPanel(
      width = 9,
      tabsetPanel(
        tabPanel("KM生存曲线",
                 br(),
                 uiOutput("statusMessage"),
                 plotOutput("kmPlot", height = "500px"),
                 br(),
                 fluidRow(
                   column(6,
                          h4("统计摘要"),
                          verbatimTextOutput("statsSummary")
                   ),
                   column(6,
                          h4("分组信息"),
                          tableOutput("groupTable")
                   )
                 )
        ),
        
        tabPanel("数据预览",
                 br(),
                 h4("表达谱数据（前五行，前五列）"),
                 DTOutput("exprPreview"),
                 br(),
                 h4("生存数据（前五行）"),
                 DTOutput("survPreview"),
                 br(),
                 h4("合并数据（前五行，前五列）"),
                 DTOutput("mergedPreview")
        ),
        
        tabPanel("结果下载",
                 br(),
                 h4("下载分析结果"),
                 downloadButton("downloadKMPlot", "下载KM曲线图（PNG）",
                                class = "btn-success"),
                 br(), br(),
                 downloadButton("downloadPDF", "下载KM曲线图（PDF）",
                                class = "btn-info"),
                 br(), br(),
                 downloadButton("downloadData", "下载分析数据（CSV）",
                                class = "btn-warning"),
                 br(), br(),
                 downloadButton("downloadReport", "下载分析报告（TXT）",
                                class = "btn-primary")
        ),
        
        tabPanel("使用指南",
                 br(),
                 h4("使用说明"),
                 tags$div(
                   class = "well",
                   tags$h5("数据格式要求："),
                   tags$ul(
                     tags$li("表达谱数据：第一列为基因名，第一行为样本名"),
                     tags$li("生存数据：包含三列（sample, OS, OS.time）"),
                     tags$li("样本名需要在两个文件中匹配")
                   ),
                   tags$h5("分析步骤："),
                   tags$ol(
                     tags$li("上传表达谱数据和生存数据"),
                     tags$li("输入要分析的基因名称"),
                     tags$li("选择分组方法（推荐使用最佳截点法）"),
                     tags$li("点击'生成KM曲线'按钮"),
                     tags$li("查看结果并下载")
                   ),
                   tags$h5("结果解读："),
                   tags$ul(
                     tags$li("P < 0.05：基因与预后显著相关"),
                     tags$li("P ≥ 0.05：基因与预后无显著相关性")
                   )
                 )
        )
      )
    )
  )
)

# 服务器逻辑
server <- function(input, output, session) {
  
  # 读取表达谱数据
  exprData <- reactive({
    req(input$exprFile)
    
    # 读取CSV文件
    df <- read.csv(input$exprFile$datapath, 
                   row.names = 1,  # 第一列作为行名（基因名）
                   check.names = FALSE,  # 保持列名不变
                   stringsAsFactors = FALSE)
    
    # 转置数据，使行为样本，列为基因
    df_t <- as.data.frame(t(df))
    df_t$sample <- rownames(df_t)
    
    return(list(raw = df, transposed = df_t))
  })
  
  # 读取生存数据
  survData <- reactive({
    req(input$survFile)
    
    df <- read.csv(input$survFile$datapath,
                   stringsAsFactors = FALSE)
    
    # 确保列名正确
    if (!all(c("sample", "OS", "OS.time") %in% colnames(df))) {
      stop("生存数据必须包含'sample', 'OS', 'OS.time'三列")
    }
    
    return(df)
  })
  
  # 合并数据
  mergedData <- reactive({
    req(exprData(), survData())
    
    expr_df <- exprData()$transposed
    surv_df <- survData()
    
    # 合并数据
    merged <- merge(expr_df, surv_df, by = "sample")
    
    # 移除有缺失值的行
    merged <- na.omit(merged)
    
    return(merged)
  })
  
  # 显示状态消息
  output$statusMessage <- renderUI({
    req(mergedData(), input$geneName)
    
    gene <- input$geneName
    data <- mergedData()
    
    if (gene %in% colnames(data)) {
      div(class = "alert alert-success",
          icon("check-circle"),
          paste("✓ 基因", gene, "分析准备就绪，共有", 
                nrow(data), "个有效样本"))
    } else {
      div(class = "alert alert-danger",
          icon("exclamation-triangle"),
          paste("✗ 错误：基因", gene, "在数据中不存在"))
    }
  })
  
  # 执行KM分析
  kmAnalysis <- eventReactive(input$runAnalysis, {
    req(mergedData(), input$geneName)
    
    gene <- input$geneName
    data <- mergedData()
    
    # 检查基因是否存在
    if (!gene %in% colnames(data)) {
      return(NULL)
    }
    
    # 获取基因表达值
    expr_values <- data[[gene]]
    
    # 根据选择的方法确定截点
    if (input$cutMethod == "optimal") {
      # 使用survminer的最佳截点
      res.cut <- surv_cutpoint(data, 
                               time = "OS.time", 
                               event = "OS", 
                               variables = gene)
      cutoff <- res.cut$cutpoint$cutpoint
      data$group <- ifelse(expr_values > cutoff, "High", "Low")
      
    } else if (input$cutMethod == "median") {
      cutoff <- median(expr_values, na.rm = TRUE)
      data$group <- ifelse(expr_values > cutoff, "High", "Low")
      
    } else if (input$cutMethod == "mean") {
      cutoff <- mean(expr_values, na.rm = TRUE)
      data$group <- ifelse(expr_values > cutoff, "High", "Low")
      
    } else if (input$cutMethod == "custom") {
      cutoff <- input$customCutoff
      data$group <- ifelse(expr_values > cutoff, "High", "Low")
    }
    
    # 将分组转换为因子
    data$group <- factor(data$group, levels = c("Low", "High"))
    
    # 拟合生存曲线
    fit <- survfit(Surv(OS.time, OS) ~ group, data = data)
    
    # 计算log-rank检验p值
    surv_diff <- survdiff(Surv(OS.time, OS) ~ group, data = data)
    pval <- 1 - pchisq(surv_diff$chisq, 1)
    
    # 绘制KM曲线
    km_plot <- ggsurvplot(
      fit,
      data = data,
      pval = TRUE,
      pval.method = TRUE,
      conf.int = FALSE,
      risk.table = TRUE,
      risk.table.height = 0.25,
      surv.median.line = "hv",
      legend.labs = c("Low Expression", "High Expression"),
      legend.title = paste0(gene, "\nCutoff: ", round(cutoff, 3)),
      title = paste("KM Survival Curve -", gene),
      xlab = "Time (days)",
      ylab = "Survival Probability",
      palette = c(input$lowColor, input$highColor),
      ggtheme = theme_bw(),
      risk.table.y.text = FALSE,
      font.title = c(16, "bold"),
      font.x = c(14, "bold"),
      font.y = c(14, "bold"),
      font.legend = c(12, "plain"),
      pval.coord = c(max(data$OS.time) * 0.1, 0.9),
      pval.method.coord = c(max(data$OS.time) * 0.1, 0.95)
    )
    
    # 格式化p值显示
    if (pval < 0.001) {
      pval_text <- "p < 0.001"
    } else {
      pval_text <- paste("p =", format(round(pval, 3), nsmall = 3))
    }
    
    # 返回结果
    return(list(
      plot = km_plot,
      data = data,
      fit = fit,
      cutoff = cutoff,
      pval = pval,
      pval_text = pval_text,
      gene = gene,
      n_samples = nrow(data),
      n_high = sum(data$group == "High"),
      n_low = sum(data$group == "Low")
    ))
  })
  
  # 显示KM曲线
  output$kmPlot <- renderPlot({
    result <- kmAnalysis()
    
    if (is.null(result)) {
      plot.new()
      text(0.5, 0.5, "请检查基因名称是否正确", 
           col = "red", cex = 1.5)
    } else {
      print(result$plot, newpage = FALSE)
    }
  })
  
  # 显示统计摘要
  output$statsSummary <- renderPrint({
    result <- kmAnalysis()
    
    if (is.null(result)) {
      cat("等待分析结果...\n")
    } else {
      cat("====================\n")
      cat("  分析结果摘要\n")
      cat("====================\n\n")
      cat("基因名称: ", result$gene, "\n")
      cat("分组方法: ", input$cutMethod, "\n")
      cat("截断值:   ", round(result$cutoff, 4), "\n")
      cat("Log-rank检验: ", result$pval_text, "\n")
      cat("总样本数: ", result$n_samples, "\n")
      cat("高表达组: ", result$n_high, "\n")
      cat("低表达组: ", result$n_low, "\n")
      
      if (result$pval < 0.05) {
        cat("\n★ 结果显著 (p < 0.05)\n")
        cat("该基因与患者预后显著相关\n")
      } else {
        cat("\n○ 结果不显著 (p ≥ 0.05)\n")
        cat("该基因与患者预后无显著相关性\n")
      }
    }
  })
  
  # 显示分组信息
  output$groupTable <- renderTable({
    result <- kmAnalysis()
    
    if (is.null(result)) {
      return(NULL)
    }
    
    # 计算各组的生存统计
    data <- result$data
    
    group_stats <- data %>%
      group_by(group) %>%
      summarise(
        n = n(),
        mean_expr = round(mean(get(result$gene), na.rm = TRUE), 3),
        median_survival = round(median(OS.time), 1),
        .groups = 'drop'
      )
    
    colnames(group_stats) <- c("分组", "样本数", "平均表达", "中位生存期(天)")
    
    return(group_stats)
  })
  
  # 数据预览 - 表达谱数据（前五行，前五列）
  output$exprPreview <- renderDT({
    req(exprData())
    
    df <- exprData()$raw
    
    # 取前5行和前5列（如果列数足够）
    n_rows <- min(5, nrow(df))
    n_cols <- min(6, ncol(df) + 1)  # +1是因为要包含基因名列
    
    # 创建预览数据框，包含基因名和前4个样本
    preview_df <- data.frame(
      Gene = rownames(df)[1:n_rows],
      df[1:n_rows, 1:min(4, ncol(df)), drop = FALSE]
    )
    
    datatable(
      preview_df,
      options = list(
        pageLength = 5,
        scrollX = TRUE,
        dom = 't'  # 只显示表格，不显示搜索框等
      ),
      caption = "表达谱数据预览（前5行，前5列）"
    )
  })
  
  # 数据预览 - 生存数据（前五行）
  output$survPreview <- renderDT({
    req(survData())
    
    df <- survData()
    
    datatable(
      head(df, 5),
      options = list(
        pageLength = 5,
        scrollX = TRUE,
        dom = 't'
      ),
      caption = "生存数据预览（前5行）"
    )
  })
  
  # 数据预览 - 合并数据（前五行，前五列）
  output$mergedPreview <- renderDT({
    req(mergedData())
    
    df <- mergedData()
    
    # 取前5行和前5列
    n_rows <- min(5, nrow(df))
    n_cols <- min(5, ncol(df))
    
    # 如果包含的列多于5列，只显示前5列
    if (n_cols < ncol(df)) {
      preview_df <- df[1:n_rows, 1:n_cols, drop = FALSE]
      caption <- paste0("合并数据预览（前5行，前5列，共", ncol(df), "列）")
    } else {
      preview_df <- df[1:n_rows, , drop = FALSE]
      caption <- "合并数据预览（前5行）"
    }
    
    datatable(
      preview_df,
      options = list(
        pageLength = 5,
        scrollX = TRUE,
        dom = 't'
      ),
      caption = caption
    )
  })
  
  # 下载功能
  output$downloadKMPlot <- downloadHandler(
    filename = function() {
      gene <- input$geneName
      paste0("KM_curve_", gene, "_", Sys.Date(), ".png")
    },
    content = function(file) {
      result <- kmAnalysis()
      
      if (is.null(result)) return()
      
      # 保存为PNG
      png(file, width = 10, height = 8, units = "in", res = 300)
      print(result$plot)
      dev.off()
    }
  )
  
  output$downloadPDF <- downloadHandler(
    filename = function() {
      gene <- input$geneName
      paste0("KM_curve_", gene, "_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      result <- kmAnalysis()
      
      if (is.null(result)) return()
      
      # 保存为PDF
      pdf(file, width = 10, height = 8)
      print(result$plot)
      dev.off()
    }
  )
  
  output$downloadData <- downloadHandler(
    filename = function() {
      gene <- input$geneName
      paste0("analysis_data_", gene, "_", Sys.Date(), ".csv")
    },
    content = function(file) {
      result <- kmAnalysis()
      
      if (is.null(result)) return()
      
      write.csv(result$data, file, row.names = FALSE)
    }
  )
  
  output$downloadReport <- downloadHandler(
    filename = function() {
      gene <- input$geneName
      paste0("analysis_report_", gene, "_", Sys.Date(), ".txt")
    },
    content = function(file) {
      result <- kmAnalysis()
      
      if (is.null(result)) {
        writeLines("分析失败：请检查基因名称是否正确", file)
        return()
      }
      
      report_text <- c(
        "==============================",
        "    单基因预后分析报告",
        "==============================",
        paste("\n分析时间：", Sys.time()),
        paste("\n基因名称：", result$gene),
        paste("分组方法：", input$cutMethod),
        paste("截断值：", round(result$cutoff, 4)),
        paste("Log-rank P值：", result$pval_text),
        paste("\n样本统计："),
        paste("总样本数：", result$n_samples),
        paste("高表达组：", result$n_high, "个样本"),
        paste("低表达组：", result$n_low, "个样本"),
        "\n------------------------------",
        "\n结果解读："
      )
      
      if (result$pval < 0.05) {
        report_text <- c(report_text,
                         paste("★ 基因", result$gene, "与患者预后显著相关 (p < 0.05)"),
                         "高表达组和低表达组的生存率存在显著差异"
        )
      } else {
        report_text <- c(report_text,
                         paste("○ 基因", result$gene, "与患者预后无显著相关性 (p ≥ 0.05)"),
                         "高表达组和低表达组的生存率差异不显著"
        )
      }
      
      writeLines(report_text, file)
    }
  )
}

# 运行应用
shinyApp(ui = ui, server = server)