# app.R
library(shiny)
library(shinythemes)
library(DT)
library(ggplot2)
library(ggrepel)
library(limma)
library(DESeq2)
library(ComplexHeatmap)
library(circlize)
library(dplyr)
library(readxl)
library(tools)
library(data.table)
library(grid)
library(rsvg)

# 增加上传文件大小限制（设为100MB）
options(shiny.maxRequestSize = 100 * 1024^2)

# UI界面
ui <- fluidPage(
  theme = shinytheme("flatly"),
  
  # CSS样式
  tags$head(
    tags$style(HTML("
      .well {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 5px;
        padding: 15px;
      }
      .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
      }
      .btn-success {
        background-color: #28a745;
        border-color: #28a745;
      }
      .btn-info {
        background-color: #17a2b8;
        border-color: #17a2b8;
      }
      .shiny-output-error {
        color: #dc3545;
        font-weight: bold;
      }
      .progress-bar {
        background-color: #007bff;
      }
      .img-container {
        width: 100%;
        overflow-x: auto;
      }
    "))
  ),
  
  # 标题
  titlePanel(div(
    icon("dna"),
    "差异表达基因分析平台 (limma & DESeq2)",
    style = "color: #2c3e50;"
  )),
  
  sidebarLayout(
    sidebarPanel(
      width = 3,
      
      # 文件上传
      h4(icon("upload"), "1. 数据上传"),
      helpText("支持CSV、TXT、TSV格式，最大100MB"),
      fileInput("expr_file", "表达谱文件:",
                accept = c(".csv", ".txt", ".tsv"),
                multiple = FALSE,
                buttonLabel = "浏览...",
                placeholder = "选择文件"),
      
      fileInput("group_file", "分组信息文件:",
                accept = c(".csv", ".xlsx", ".xls"),
                multiple = FALSE,
                buttonLabel = "浏览...",
                placeholder = "选择文件"),
      
      hr(),
      
      # 分析方法选择
      h4(icon("cog"), "2. 分析参数"),
      radioButtons("method", "分析方法:",
                   choices = c("limma (芯片数据)" = "limma",
                               "DESeq2 (RNA-seq数据)" = "deseq2"),
                   selected = "limma"),
      
      # 对照组设置
      textInput("control_group", "对照组名称:", value = "Control"),
      textInput("case_group", "实验组名称:", value = "Case"),
      
      hr(),
      
      # 阈值设置
      h4(icon("sliders-h"), "3. 差异阈值"),
      numericInput("logfc_cutoff", "logFC阈值:", value = 1, min = 0, step = 0.1),
      selectInput("pval_type", "P值类型:",
                  choices = c("矫正P值 (adj.P.Val/padj)" = "adj",
                              "原始P值 (P.Value/pvalue)" = "raw")),
      numericInput("pval_cutoff", "P值阈值:", value = 0.05, min = 0.0001, max = 1, step = 0.01),
      
      hr(),
      
      # 图片设置
      h4(icon("image"), "4. 图片设置"),
      numericInput("volcano_width", "火山图宽度(英寸):", value = 10, min = 5, max = 20, step = 0.5),
      numericInput("volcano_height", "火山图高度(英寸):", value = 8, min = 5, max = 20, step = 0.5),
      numericInput("heatmap_width", "热图宽度(英寸):", value = 12, min = 5, max = 20, step = 0.5),
      numericInput("heatmap_height", "热图高度(英寸):", value = 10, min = 5, max = 20, step = 0.5),
      selectInput("heatmap_fontsize", "热图字体大小:", 
                  choices = c("小" = 8, "中" = 10, "大" = 12),
                  selected = 10),
      
      hr(),
      
      # 分析按钮
      actionButton("analyze", "开始分析", 
                   class = "btn-primary btn-block",
                   icon = icon("play-circle"),
                   width = "100%"),
      
      hr(),
      
      # 进度条
      conditionalPanel(
        condition = "$('html').hasClass('shiny-busy')",
        tags$div(
          class = "well",
          tags$p("分析进行中...", style = "text-align: center;"),
          tags$div(
            class = "progress",
            tags$div(
              class = "progress-bar progress-bar-striped active",
              role = "progressbar",
              style = "width: 100%"
            )
          )
        )
      ),
      
      # 下载按钮
      h4(icon("download"), "5. 结果下载"),
      conditionalPanel(
        condition = "output.analysis_done == true",
        downloadButton("download_all", "完整结果", 
                       class = "btn-success btn-block",
                       style = "margin-bottom: 10px;"),
        downloadButton("download_sig", "差异基因",
                       class = "btn-success btn-block",
                       style = "margin-bottom: 10px;"),
        br(),
        h5("火山图下载:"),
        downloadButton("download_volcano_png", "火山图(PNG)",
                       class = "btn-info btn-block",
                       style = "margin-bottom: 5px;"),
        downloadButton("download_volcano_pdf", "火山图(PDF)",
                       class = "btn-info btn-block",
                       style = "margin-bottom: 10px;"),
        h5("热图下载:"),
        downloadButton("download_heatmap_png", "热图(PNG)",
                       class = "btn-info btn-block",
                       style = "margin-bottom: 5px;"),
        downloadButton("download_heatmap_pdf", "热图(PDF)",
                       class = "btn-info btn-block")
      ),
      
      hr(),
      
      # 状态指示
      conditionalPanel(
        condition = "output.data_loaded == true && output.analysis_done == false",
        tags$div(
          class = "alert alert-info",
          icon("info-circle"),
          "数据已加载，请点击'开始分析'"
        )
      )
    ),
    
    mainPanel(
      width = 9,
      tabsetPanel(
        id = "main_tabs",
        tabPanel(icon("table"), "数据概览",
                 fluidRow(
                   column(12,
                          h4("表达谱数据预览"),
                          helpText("显示前10行数据，确保行为基因，列为样本"),
                          DTOutput("expr_preview"),
                          br(),
                          h4("分组信息预览"),
                          DTOutput("group_preview"),
                          br(),
                          verbatimTextOutput("data_summary")
                   )
                 )),
        
        tabPanel(icon("chart-bar"), "分析结果",
                 fluidRow(
                   column(12,
                          h4("差异表达基因统计"),
                          uiOutput("deg_summary_ui"),
                          br(),
                          h4("显著差异基因 (前100个)"),
                          DTOutput("sig_results_table"),
                          br(),
                          h4("前10个上调基因"),
                          DTOutput("up_genes_table"),
                          br(),
                          h4("前10个下调基因"),
                          DTOutput("down_genes_table")
                   )
                 )),
        
        tabPanel(icon("image"), "可视化",
                 fluidRow(
                   column(12,
                          h4("火山图"),
                          div(class = "img-container",
                              plotOutput("volcano_plot", height = "600px")
                          ),
                          br(),
                          h4("热图 (前20个差异基因)"),
                          div(class = "img-container",
                              plotOutput("heatmap_plot", height = "700px")
                          )
                   )
                 )),
        
        tabPanel(icon("question-circle"), "使用说明",
                 h4("📋 平台使用指南"),
                 tags$div(
                   class = "well",
                   h5("📁 1. 数据格式要求:"),
                   tags$ul(
                     tags$li(tags$b("表达谱文件:"), "CSV/TXT/TSV格式，第一列为基因名，后续列为样本"),
                     tags$li(tags$b("分组信息文件:"), "包含两列：'sample'（样本名）和 'group'（分组信息）"),
                     tags$li(tags$b("示例数据:"), "可在下方下载示例文件进行测试")
                   ),
                   
                   h5("🔧 2. 分析方法选择:"),
                   tags$ul(
                     tags$li(tags$b("limma:"), "适用于芯片数据或已标准化的表达数据"),
                     tags$li(tags$b("DESeq2:"), "适用于RNA-seq原始count数据")
                   ),
                   
                   h5("⚙️ 3. 参数设置建议:"),
                   tags$ul(
                     tags$li("logFC阈值: 通常设为1（表示2倍变化）"),
                     tags$li("P值类型: 推荐使用矫正P值以减少假阳性"),
                     tags$li("P值阈值: 通常设为0.05或0.01")
                   ),
                   
                   h5("🖼️ 4. 图片设置:"),
                   tags$ul(
                     tags$li("可调整火山图和热图的宽度和高度"),
                     tags$li("可调整热图的字体大小"),
                     tags$li("支持PNG和PDF格式下载")
                   ),
                   
                   h5("🚀 5. 分析流程:"),
                   tags$ol(
                     tags$li("上传表达谱和分组信息文件"),
                     tags$li("在'数据概览'标签页检查数据格式"),
                     tags$li("选择分析方法和设置参数"),
                     tags$li("设置图片参数"),
                     tags$li("点击'开始分析'按钮"),
                     tags$li("查看'分析结果'和'可视化'标签页"),
                     tags$li("下载所需结果文件")
                   )
                 ),
                 
                 hr(),
                 
                 h4("📥 示例数据下载"),
                 tags$div(
                   class = "well",
                   p("点击下载示例数据进行测试："),
                   downloadButton("download_example_expr", 
                                  "下载表达谱示例 (1000基因 × 20样本)",
                                  class = "btn-info btn-block",
                                  style = "margin-bottom: 10px;"),
                   downloadButton("download_example_group", 
                                  "下载分组信息示例",
                                  class = "btn-info btn-block",
                                  style = "margin-bottom: 10px;")
                 ),
                 
                 hr(),
                 
                 h4("⚠️ 常见问题"),
                 tags$div(
                   class = "well",
                   h5("Q1: 上传文件时提示'Maximum upload size exceeded'"),
                   p("A: 平台已设置为最大100MB，如果文件超过此限制，请压缩文件或联系管理员。"),
                   
                   h5("Q2: 分析出错怎么办？"),
                   p("A: 请检查：1) 样本名是否匹配；2) 分组信息是否正确；3) 表达谱数据格式是否正确。"),
                   
                   h5("Q3: DESeq2分析很慢怎么办？"),
                   p("A: 对于大数据集，DESeq2可能需要较长时间，请耐心等待。"),
                   
                   h5("Q4: 结果如何解读？"),
                   p("A: logFC > 0表示上调，logFC < 0表示下调；P值越小表示差异越显著。"),
                   
                   h5("Q5: 图片不显示怎么办？"),
                   p("A: 请确保已安装所有必要的R包，并检查是否有足够的系统内存。")
                 )
        )
      )
    )
  )
)

# 服务器逻辑
server <- function(input, output, session) {
  
  # 数据加载状态
  data_loaded <- reactiveVal(FALSE)
  
  # 更新数据加载状态
  observe({
    req(expr_data(), group_data())
    data_loaded(TRUE)
  })
  
  output$data_loaded <- reactive({
    data_loaded()
  })
  outputOptions(output, "data_loaded", suspendWhenHidden = FALSE)
  
  # 创建示例数据
  create_example_data <- function() {
    set.seed(123)
    
    # 创建基因名
    genes <- paste0("GENE", sprintf("%04d", 1:1000))
    
    # 创建样本名
    samples <- paste0("Sample_", 1:20)
    
    # 创建表达矩阵
    expr_data <- matrix(rnorm(1000*20, mean = 10, sd = 2), nrow = 1000, ncol = 20)
    
    # 添加一些差异表达
    # 上调基因
    expr_data[1:50, 11:20] <- expr_data[1:50, 11:20] + runif(500, 1.5, 3)
    # 下调基因
    expr_data[51:100, 11:20] <- expr_data[51:100, 11:20] - runif(500, 1.5, 3)
    
    # 设置行名和列名
    rownames(expr_data) <- genes
    colnames(expr_data) <- samples
    
    # 分组信息
    group_data <- data.frame(
      sample = samples,
      group = c(rep("Control", 10), rep("Case", 10)),
      stringsAsFactors = FALSE
    )
    
    list(expr = expr_data, group = group_data)
  }
  
  # 下载示例数据
  output$download_example_expr <- downloadHandler(
    filename = function() {
      "example_expression_data.csv"
    },
    content = function(file) {
      example_data <- create_example_data()
      df <- as.data.frame(example_data$expr)
      df <- cbind(Gene = rownames(df), df)
      write.csv(df, file, row.names = FALSE, quote = FALSE)
    }
  )
  
  output$download_example_group <- downloadHandler(
    filename = function() {
      "example_group_info.csv"
    },
    content = function(file) {
      example_data <- create_example_data()
      write.csv(example_data$group, file, row.names = FALSE, quote = FALSE)
    }
  )
  
  # 读取表达谱数据
  expr_data <- reactive({
    req(input$expr_file)
    
    tryCatch({
      ext <- tools::file_ext(input$expr_file$name)
      path <- input$expr_file$datapath
      
      # 使用fread读取大文件
      if (ext == "csv") {
        data <- fread(path, header = TRUE, sep = ",", check.names = FALSE)
      } else if (ext == "tsv") {
        data <- fread(path, header = TRUE, sep = "\t", check.names = FALSE)
      } else if (ext == "txt") {
        # 尝试自动检测分隔符
        first_line <- readLines(path, n = 1)
        if (grepl("\t", first_line)) {
          data <- fread(path, header = TRUE, sep = "\t", check.names = FALSE)
        } else {
          data <- fread(path, header = TRUE, check.names = FALSE)
        }
      } else {
        stop("不支持的文件格式。请上传CSV、TXT或TSV文件。")
      }
      
      # 转换为数据框
      df <- as.data.frame(data)
      
      # 检查数据维度
      if (ncol(df) < 2) {
        stop("文件至少需要两列（基因名和至少一个样本）")
      }
      
      if (nrow(df) == 0) {
        stop("文件为空")
      }
      
      # 第一列作为行名（基因名）
      gene_col <- names(df)[1]
      row_names <- df[[gene_col]]
      
      # 检查行名是否有效
      if (any(is.na(row_names) | row_names == "")) {
        stop("第一列包含空的基因名")
      }
      
      # 处理重复的基因名
      if (any(duplicated(row_names))) {
        row_names <- make.unique(row_names)
      }
      
      # 设置行名并移除基因名列
      rownames(df) <- row_names
      df <- df[, -1, drop = FALSE]
      
      # 转换为数值矩阵
      df_numeric <- as.data.frame(lapply(df, function(x) {
        suppressWarnings(as.numeric(as.character(x)))
      }))
      rownames(df_numeric) <- row_names
      
      # 检查是否有数值数据
      if (all(is.na(df_numeric))) {
        stop("表达谱数据不包含有效的数值")
      }
      
      # 移除全为NA的行
      df_numeric <- df_numeric[rowSums(!is.na(df_numeric)) > 0, , drop = FALSE]
      
      return(df_numeric)
      
    }, error = function(e) {
      showNotification(paste("读取表达谱文件出错:", e$message), 
                       type = "error", duration = 10)
      return(NULL)
    })
  })
  
  # 读取分组信息
  group_data <- reactive({
    req(input$group_file)
    
    tryCatch({
      ext <- tools::file_ext(input$group_file$name)
      
      if (ext == "csv") {
        df <- read.csv(input$group_file$datapath, 
                       stringsAsFactors = FALSE, 
                       fileEncoding = "UTF-8")
      } else if (ext %in% c("xlsx", "xls")) {
        df <- as.data.frame(read_excel(input$group_file$datapath))
      } else {
        stop("不支持的文件格式。请上传CSV或Excel文件。")
      }
      
      # 尝试自动识别列名
      colnames_lower <- tolower(colnames(df))
      
      # 查找样本列
      sample_patterns <- c("sample", "samples", "id", "name", "样本", "样品")
      sample_col <- NULL
      for (pattern in sample_patterns) {
        matches <- grep(pattern, colnames_lower, ignore.case = TRUE)
        if (length(matches) > 0) {
          sample_col <- colnames(df)[matches[1]]
          break
        }
      }
      
      # 查找分组列
      group_patterns <- c("group", "groups", "condition", "type", "class", "分组", "类别")
      group_col <- NULL
      for (pattern in group_patterns) {
        matches <- grep(pattern, colnames_lower, ignore.case = TRUE)
        if (length(matches) > 0) {
          group_col <- colnames(df)[matches[1]]
          break
        }
      }
      
      if (!is.null(sample_col) && !is.null(group_col)) {
        # 重命名列
        df <- df[, c(sample_col, group_col)]
        colnames(df) <- c("sample", "group")
      } else if (!all(c("sample", "group") %in% colnames(df))) {
        # 如果前两列不是sample和group，假设前两列是
        if (ncol(df) >= 2) {
          df <- df[, 1:2]
          colnames(df) <- c("sample", "group")
        } else {
          stop("文件必须包含样本和分组信息")
        }
      }
      
      # 清理数据
      df$sample <- as.character(df$sample)
      df$group <- as.character(df$group)
      
      # 移除空值
      df <- df[!is.na(df$sample) & df$sample != "" & 
                 !is.na(df$group) & df$group != "", ]
      
      if (nrow(df) == 0) {
        stop("分组信息文件为空或所有数据都是空值")
      }
      
      return(df)
      
    }, error = function(e) {
      showNotification(paste("读取分组信息文件出错:", e$message), 
                       type = "error", duration = 10)
      return(NULL)
    })
  })
  
  # 数据预览
  output$expr_preview <- renderDT({
    req(expr_data())
    
    data <- expr_data()
    
    # 只显示前10行和前10列
    show_rows <- min(10, nrow(data))
    show_cols <- min(10, ncol(data))
    
    preview_data <- data[1:show_rows, 1:show_cols, drop = FALSE]
    
    # 转换为数据框，包含行名
    preview_df <- as.data.frame(preview_data)
    preview_df <- cbind(Gene = rownames(preview_df), preview_df)
    
    datatable(
      preview_df,
      options = list(
        scrollX = TRUE,
        pageLength = 10,
        dom = 'Bfrtip',
        buttons = c('copy', 'csv', 'excel')
      ),
      caption = paste("显示前", show_rows, "行，前", show_cols, 
                      "列（总共", nrow(data), "行，", ncol(data), "列）"),
      rownames = FALSE
    )
  })
  
  output$group_preview <- renderDT({
    req(group_data())
    
    datatable(
      group_data(),
      options = list(
        scrollX = TRUE,
        pageLength = 10
      ),
      caption = "分组信息预览",
      rownames = FALSE
    )
  })
  
  output$data_summary <- renderPrint({
    req(expr_data(), group_data())
    
    expr <- expr_data()
    group_info <- group_data()
    
    cat("=== 数据概览 ===\n\n")
    cat("表达谱数据:\n")
    cat("  基因数:", nrow(expr), "\n")
    cat("  样本数:", ncol(expr), "\n")
    cat("  样本名示例:", paste(head(colnames(expr), 5), collapse = ", "))
    if (ncol(expr) > 5) cat(", ...")
    cat("\n")
    
    cat("\n分组信息:\n")
    cat("  样本数:", nrow(group_info), "\n")
    cat("  分组情况:\n")
    group_table <- table(group_info$group)
    for (group_name in names(sort(group_table, decreasing = TRUE))) {
      cat(paste0("    ", group_name, ": ", group_table[group_name], " 个样本\n"))
    }
    
    # 检查样本匹配
    expr_samples <- colnames(expr)
    group_samples <- group_info$sample
    
    common_samples <- intersect(expr_samples, group_samples)
    only_in_expr <- setdiff(expr_samples, group_samples)
    only_in_group <- setdiff(group_samples, expr_samples)
    
    cat("\n样本匹配检查:\n")
    cat("  匹配的样本:", length(common_samples), "\n")
    cat("  仅在表达谱中:", length(only_in_expr), "\n")
    if (length(only_in_expr) > 0) {
      cat("    ", paste(head(only_in_expr, 5), collapse = ", "))
      if (length(only_in_expr) > 5) cat(", ...")
      cat("\n")
    }
    
    cat("  仅在分组信息中:", length(only_in_group), "\n")
    if (length(only_in_group) > 0) {
      cat("    ", paste(head(only_in_group, 5), collapse = ", "))
      if (length(only_in_group) > 5) cat(", ...")
      cat("\n")
    }
    
    if (length(common_samples) == 0) {
      cat("\n❌ 错误: 没有匹配的样本！\n")
      cat("请检查样本名是否一致（区分大小写和空格）\n")
    } else if (length(common_samples) < min(length(expr_samples), length(group_samples))) {
      cat("\n⚠️ 警告: 部分样本不匹配！\n")
      cat("分析将仅使用", length(common_samples), "个匹配的样本\n")
    } else {
      cat("\n✅ 样本完全匹配！\n")
    }
  })
  
  # 分析结果
  analysis_results <- reactiveVal(NULL)
  
  # 分析完成标志
  output$analysis_done <- reactive({
    !is.null(analysis_results())
  })
  outputOptions(output, "analysis_done", suspendWhenHidden = FALSE)
  
  # 监听分析按钮
  observeEvent(input$analyze, {
    req(expr_data(), group_data())
    
    # 显示模态框
    showModal(modalDialog(
      title = div(icon("spinner", class = "fa-spin"), " 分析进行中"),
      "正在运行差异表达分析，请稍候...",
      footer = NULL,
      easyClose = FALSE,
      size = "s"
    ))
    
    tryCatch({
      # 提取数据
      expr <- expr_data()
      group_info <- group_data()
      
      # 确保样本顺序一致
      common_samples <- intersect(colnames(expr), group_info$sample)
      
      if (length(common_samples) == 0) {
        stop("错误：表达谱和分组信息中没有匹配的样本名。请检查样本名是否一致。")
      }
      
      if (length(common_samples) < 3) {
        stop("错误：匹配的样本数太少（至少需要3个样本）。")
      }
      
      expr <- expr[, common_samples, drop = FALSE]
      group_info <- group_info[group_info$sample %in% common_samples, ]
      group_info <- group_info[match(common_samples, group_info$sample), ]
      
      # 设置分组因子
      group_info$group <- factor(group_info$group)
      group_levels <- levels(group_info$group)
      
      # 检查用户指定的组是否存在
      control_group <- trimws(input$control_group)
      case_group <- trimws(input$case_group)
      
      if (!control_group %in% group_levels) {
        stop(paste("错误：对照组'", control_group, 
                   "'不存在。可用组为:", paste(group_levels, collapse = ", ")))
      }
      
      if (!case_group %in% group_levels) {
        stop(paste("错误：实验组'", case_group, 
                   "'不存在。可用组为:", paste(group_levels, collapse = ", ")))
      }
      
      if (control_group == case_group) {
        stop("错误：对照组和实验组不能相同")
      }
      
      # 运行差异分析
      if (input$method == "limma") {
        # limma分析
        
        design <- model.matrix(~0 + group_info$group)
        colnames(design) <- levels(group_info$group)
        rownames(design) <- group_info$sample
        
        # 创建对比矩阵
        contrast_formula <- paste(case_group, control_group, sep = "-")
        contrast <- makeContrasts(contrasts = contrast_formula, levels = design)
        
        # 拟合模型
        fit <- lmFit(expr, design)
        fit2 <- contrasts.fit(fit, contrast)
        fit3 <- eBayes(fit2)
        
        # 提取结果
        res <- topTable(fit3, coef = 1, number = Inf, sort.by = "p")
        
        # 确保列名一致
        if (!"adj.P.Val" %in% colnames(res)) {
          res$adj.P.Val <- p.adjust(res$P.Value, method = "BH")
        }
        
      } else {
        # DESeq2分析
        
        colData <- data.frame(
          row.names = group_info$sample,
          group = group_info$group
        )
        
        # 确保数据是整数（count数据）
        expr_int <- round(as.matrix(expr))
        
        # 移除全为零的行
        keep <- rowSums(expr_int) > 0
        expr_int <- expr_int[keep, , drop = FALSE]
        
        if (nrow(expr_int) == 0) {
          stop("错误：所有基因的表达值都是0")
        }
        
        dds <- DESeqDataSetFromMatrix(
          countData = expr_int,
          colData = colData,
          design = ~ group
        )
        
        # 设置参考水平
        dds$group <- relevel(dds$group, ref = control_group)
        
        # 运行DESeq
        dds <- DESeq(dds, quiet = TRUE)
        
        # 提取结果
        res <- results(dds, 
                       contrast = c("group", case_group, control_group),
                       alpha = input$pval_cutoff)
        res <- as.data.frame(res)
        
        # 重命名列以与limma结果一致
        colnames(res)[colnames(res) == "log2FoldChange"] <- "logFC"
        colnames(res)[colnames(res) == "pvalue"] <- "P.Value"
        colnames(res)[colnames(res) == "padj"] <- "adj.P.Val"
        
        # 排序
        res <- res[order(res$P.Value, na.last = TRUE), ]
      }
      
      # 添加差异标签
      pval_col <- ifelse(input$pval_type == "adj", "adj.P.Val", "P.Value")
      pval_cutoff <- input$pval_cutoff
      logfc_cutoff <- input$logfc_cutoff
      
      res$change <- ifelse(
        !is.na(res[[pval_col]]) & 
          res[[pval_col]] < pval_cutoff & 
          abs(res$logFC) > logfc_cutoff,
        ifelse(res$logFC > logfc_cutoff, 'Up', 'Down'),
        'Not'
      )
      
      # 提取显著差异基因
      sig_res <- res[res$change %in% c("Up", "Down") & !is.na(res$change), ]
      
      # 获取上下调基因
      up_genes <- head(sig_res[sig_res$change == "Up", ], 10)
      down_genes <- head(sig_res[sig_res$change == "Down", ], 10)
      
      # 准备火山图数据
      volcano_data <- res
      volcano_data$gene <- rownames(volcano_data)
      volcano_data$log_pval <- -log10(ifelse(is.na(volcano_data[[pval_col]]), 
                                             1, 
                                             pmax(volcano_data[[pval_col]], 1e-100)))
      
      # 准备热图数据
      sig_genes <- rownames(sig_res)
      if (length(sig_genes) > 20) {
        # 选择最显著的上调和下调基因各10个
        top_up <- rownames(head(sig_res[sig_res$change == "Up", ], 10))
        top_down <- rownames(head(sig_res[sig_res$change == "Down", ], 10))
        heatmap_genes <- c(top_up, top_down)
      } else {
        heatmap_genes <- sig_genes
      }
      
      # 保存结果
      analysis_results(list(
        full_results = res,
        sig_results = sig_res,
        up_genes = up_genes,
        down_genes = down_genes,
        volcano_data = volcano_data,
        heatmap_genes = heatmap_genes,
        expr_matrix = expr,
        group_info = group_info,
        params = list(
          method = input$method,
          logfc_cutoff = logfc_cutoff,
          pval_cutoff = pval_cutoff,
          pval_type = input$pval_type,
          control_group = control_group,
          case_group = case_group
        )
      ))
      
      # 切换到结果标签页
      updateTabsetPanel(session, "main_tabs", selected = "分析结果")
      
      # 显示成功消息
      showNotification("分析完成！", type = "default", duration = 5)
      
    }, error = function(e) {
      # 显示错误消息
      showNotification(paste("分析出错:", e$message), type = "error", duration = 10)
      analysis_results(NULL)
      
    }, finally = {
      removeModal()
    })
  })
  
  # 结果摘要
  output$deg_summary_ui <- renderUI({
    req(analysis_results())
    
    res <- analysis_results()$full_results
    sig_res <- analysis_results()$sig_results
    params <- analysis_results()$params
    
    up_count <- sum(res$change == "Up", na.rm = TRUE)
    down_count <- sum(res$change == "Down", na.rm = TRUE)
    not_count <- sum(res$change == "Not", na.rm = TRUE)
    total <- nrow(res)
    
    tags$div(
      class = "well",
      tags$h4(icon("stats", lib = "glyphicon"), " 分析结果摘要"),
      
      tags$table(
        class = "table table-bordered",
        style = "width: 100%;",
        tags$thead(
          tags$tr(
            tags$th("类别", style = "width: 40%;"),
            tags$th("数量", style = "width: 30%;"),
            tags$th("百分比", style = "width: 30%;")
          )
        ),
        tags$tbody(
          tags$tr(
            class = "table-success",
            tags$td(tags$b("上调基因")),
            tags$td(up_count),
            tags$td(paste0(round(up_count/total*100, 2), "%"))
          ),
          tags$tr(
            class = "table-danger",
            tags$td(tags$b("下调基因")),
            tags$td(down_count),
            tags$td(paste0(round(down_count/total*100, 2), "%"))
          ),
          tags$tr(
            class = "table-info",
            tags$td(tags$b("显著差异基因总计")),
            tags$td(nrow(sig_res)),
            tags$td(paste0(round(nrow(sig_res)/total*100, 2), "%"))
          ),
          tags$tr(
            class = "table-secondary",
            tags$td(tags$b("非差异基因")),
            tags$td(not_count),
            tags$td(paste0(round(not_count/total*100, 2), "%"))
          ),
          tags$tr(
            class = "table-primary",
            tags$td(tags$b("总基因数")),
            tags$td(total),
            tags$td("100%")
          )
        )
      ),
      
      br(),
      
      tags$h5(icon("cogs"), " 分析参数"),
      tags$table(
        class = "table table-sm",
        tags$tbody(
          tags$tr(
            tags$td(tags$b("分析方法:")),
            tags$td(ifelse(params$method == "limma", "limma", "DESeq2"))
          ),
          tags$tr(
            tags$td(tags$b("对照组:")),
            tags$td(params$control_group)
          ),
          tags$tr(
            tags$td(tags$b("实验组:")),
            tags$td(params$case_group)
          ),
          tags$tr(
            tags$td(tags$b("logFC阈值:")),
            tags$td(params$logfc_cutoff)
          ),
          tags$tr(
            tags$td(tags$b("P值类型:")),
            tags$td(ifelse(params$pval_type == "adj", "矫正P值", "原始P值"))
          ),
          tags$tr(
            tags$td(tags$b("P值阈值:")),
            tags$td(params$pval_cutoff)
          )
        )
      )
    )
  })
  
  # 结果表格
  output$sig_results_table <- renderDT({
    req(analysis_results())
    
    sig_data <- analysis_results()$sig_results
    
    # 只显示前100个显著差异基因
    show_data <- head(sig_data, 100)
    
    # 添加基因名列
    show_data <- cbind(Gene = rownames(show_data), show_data)
    
    datatable(
      show_data,
      extensions = 'Buttons',
      options = list(
        scrollX = TRUE,
        pageLength = 10,
        dom = 'Bfrtip',
        buttons = c('copy', 'csv', 'excel'),
        columnDefs = list(
          list(className = 'dt-center', targets = '_all')
        )
      ),
      caption = paste("显著差异基因 (共", nrow(sig_data), "个，显示前", nrow(show_data), "个)"),
      rownames = FALSE
    ) %>%
      formatRound(columns = c('logFC', 'P.Value', 'adj.P.Val'), digits = 4)
  })
  
  output$up_genes_table <- renderDT({
    req(analysis_results())
    
    up_data <- analysis_results()$up_genes
    
    if (nrow(up_data) > 0) {
      up_data <- cbind(Gene = rownames(up_data), up_data)
      
      datatable(
        up_data,
        options = list(
          scrollX = TRUE,
          pageLength = 10
        ),
        rownames = FALSE
      ) %>%
        formatRound(columns = c('logFC', 'P.Value', 'adj.P.Val'), digits = 4)
    }
  })
  
  output$down_genes_table <- renderDT({
    req(analysis_results())
    
    down_data <- analysis_results()$down_genes
    
    if (nrow(down_data) > 0) {
      down_data <- cbind(Gene = rownames(down_data), down_data)
      
      datatable(
        down_data,
        options = list(
          scrollX = TRUE,
          pageLength = 10
        ),
        rownames = FALSE
      ) %>%
        formatRound(columns = c('logFC', 'P.Value', 'adj.P.Val'), digits = 4)
    }
  })
  
  # 火山图渲染
  output$volcano_plot <- renderPlot({
    req(analysis_results())
    
    data <- analysis_results()$volcano_data
    params <- analysis_results()$params
    
    # 设置颜色
    colors <- c("Up" = "#FF7F24", "Down" = "#5F9EA0", "Not" = "darkgray")
    
    # 创建基本火山图
    p <- ggplot(data, aes(x = logFC, y = log_pval, color = change)) +
      geom_point(size = 1.5, alpha = 0.6) +
      scale_color_manual(values = colors) +
      geom_vline(xintercept = c(-params$logfc_cutoff, params$logfc_cutoff), 
                 linetype = "dashed", color = "darkgray", linewidth = 0.5) +
      geom_hline(yintercept = -log10(params$pval_cutoff), 
                 linetype = "dashed", color = "darkgray", linewidth = 0.5) +
      theme_bw(base_size = 14) +
      theme(
        legend.position = "right",
        panel.grid = element_blank(),
        legend.title = element_blank(),
        plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
        axis.title = element_text(face = "bold", size = 14),
        axis.text = element_text(size = 12)
      ) +
      labs(
        x = expression(paste(log[2], "(Fold Change)")),
        y = expression(paste(-log[10], "(", 
                             ifelse(params$pval_type == "adj", "adj.P", "P"), 
                             "-value)")),
        title = paste("火山图: ", params$case_group, " vs ", params$control_group)
      )
    
    # 标记最显著的基因
    sig_data <- analysis_results()$sig_results
    if (nrow(sig_data) > 0) {
      # 选择最显著的上调和下调基因各5个
      top_up <- head(sig_data[sig_data$change == "Up", ], 5)
      top_down <- head(sig_data[sig_data$change == "Down", ], 5)
      
      label_data <- rbind(top_up, top_down)
      label_data <- data[rownames(label_data), ]
      
      if (nrow(label_data) > 0) {
        p <- p + 
          geom_text_repel(
            data = label_data,
            aes(label = gene),
            size = 4,
            max.overlaps = Inf,
            box.padding = 0.5,
            point.padding = 0.3,
            min.segment.length = 0,
            segment.color = "black",
            segment.size = 0.2,
            show.legend = FALSE
          )
      }
    }
    
    print(p)
  })
  
  # 热图渲染
  output$heatmap_plot <- renderPlot({
    req(analysis_results())
    
    data <- analysis_results()
    heatmap_genes <- data$heatmap_genes
    
    if (length(heatmap_genes) == 0) {
      # 创建空白图
      par(mar = c(0, 0, 0, 0))
      plot(0, 0, type = "n", xaxt = "n", yaxt = "n", xlab = "", ylab = "", 
           bty = "n", xlim = c(0, 1), ylim = c(0, 1))
      text(0.5, 0.5, "没有足够的差异基因绘制热图", 
           cex = 1.5, col = "gray")
      return()
    }
    
    # 提取表达矩阵
    expr_mat <- data$expr_matrix[heatmap_genes, , drop = FALSE]
    
    # 按组排序样本
    group_info <- data$group_info
    group_order <- order(group_info$group)
    expr_mat <- expr_mat[, group_order, drop = FALSE]
    group_info <- group_info[group_order, ]
    
    # 标准化（Z-score）
    expr_mat_scaled <- t(scale(t(expr_mat)))
    expr_mat_scaled[is.na(expr_mat_scaled)] <- 0
    expr_mat_scaled[expr_mat_scaled > 3] <- 3
    expr_mat_scaled[expr_mat_scaled < -3] <- -3
    
    # 分组颜色
    group_colors <- list(
      Group = setNames(
        c("#e04030", "#6cb8d2"),
        c(data$params$case_group, data$params$control_group)
      )
    )
    
    # 创建列注释
    ha <- HeatmapAnnotation(
      Group = group_info$group,
      col = group_colors,
      annotation_name_side = "left",
      annotation_legend_param = list(
        title = "分组",
        title_gp = gpar(fontsize = 12, fontface = "bold"),
        labels_gp = gpar(fontsize = 11)
      ),
      show_annotation_name = TRUE
    )
    
    # 获取字体大小
    fontsize <- as.numeric(input$heatmap_fontsize)
    
    # 创建热图
    ht <- Heatmap(
      expr_mat_scaled,
      name = "Z-score",
      top_annotation = ha,
      show_row_names = TRUE,
      show_column_names = FALSE,
      cluster_rows = TRUE,
      cluster_columns = FALSE,
      column_split = group_info$group,
      column_title = paste("差异基因热图 (n =", length(heatmap_genes), ")"),
      column_title_gp = gpar(fontsize = 14, fontface = "bold"),
      row_names_gp = gpar(fontsize = fontsize),
      row_title = "基因",
      row_title_gp = gpar(fontsize = 12, fontface = "bold"),
      col = colorRamp2(c(-3, 0, 3), c("#87CEEB", "white", "#DB7093")),
      heatmap_legend_param = list(
        title = "表达水平",
        title_gp = gpar(fontsize = 12, fontface = "bold"),
        labels_gp = gpar(fontsize = 11),
        at = c(-3, -1.5, 0, 1.5, 3),
        labels = c("低", "", "中", "", "高")
      ),
      border = TRUE,
      border_gp = gpar(col = "black", lwd = 0.5)
    )
    
    draw(ht)
  })
  
  # 下载完整结果
  output$download_all <- downloadHandler(
    filename = function() {
      paste("DEG_full_results_", Sys.Date(), ".csv", sep = "")
    },
    content = function(file) {
      req(analysis_results())
      res <- analysis_results()$full_results
      res <- cbind(Gene = rownames(res), res)
      write.csv(res, file, row.names = FALSE, quote = FALSE)
    }
  )
  
  # 下载显著差异结果
  output$download_sig <- downloadHandler(
    filename = function() {
      paste("DEG_significant_", Sys.Date(), ".csv", sep = "")
    },
    content = function(file) {
      req(analysis_results())
      res <- analysis_results()$sig_results
      res <- cbind(Gene = rownames(res), res)
      write.csv(res, file, row.names = FALSE, quote = FALSE)
    }
  )
  
  # 下载火山图PNG
  output$download_volcano_png <- downloadHandler(
    filename = function() {
      paste("volcano_plot_", Sys.Date(), ".png", sep = "")
    },
    content = function(file) {
      req(analysis_results())
      
      # 获取用户设置的尺寸
      width <- input$volcano_width
      height <- input$volcano_height
      
      # 绘制火山图
      data <- analysis_results()$volcano_data
      params <- analysis_results()$params
      
      colors <- c("Up" = "#FF7F24", "Down" = "#5F9EA0", "Not" = "darkgray")
      
      p <- ggplot(data, aes(x = logFC, y = log_pval, color = change)) +
        geom_point(size = 1.5, alpha = 0.6) +
        scale_color_manual(values = colors) +
        geom_vline(xintercept = c(-params$logfc_cutoff, params$logfc_cutoff), 
                   linetype = "dashed", color = "darkgray", linewidth = 0.5) +
        geom_hline(yintercept = -log10(params$pval_cutoff), 
                   linetype = "dashed", color = "darkgray", linewidth = 0.5) +
        theme_bw(base_size = 14) +
        theme(
          legend.position = "right",
          panel.grid = element_blank(),
          legend.title = element_blank(),
          plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
          axis.title = element_text(face = "bold", size = 14),
          axis.text = element_text(size = 12)
        ) +
        labs(
          x = expression(paste(log[2], "(Fold Change)")),
          y = expression(paste(-log[10], "(", 
                               ifelse(params$pval_type == "adj", "adj.P", "P"), 
                               "-value)")),
          title = paste("火山图: ", params$case_group, " vs ", params$control_group)
        )
      
      # 标记基因
      sig_data <- analysis_results()$sig_results
      if (nrow(sig_data) > 0) {
        top_up <- head(sig_data[sig_data$change == "Up", ], 5)
        top_down <- head(sig_data[sig_data$change == "Down", ], 5)
        label_data <- rbind(top_up, top_down)
        label_data <- data[rownames(label_data), ]
        
        if (nrow(label_data) > 0) {
          p <- p + 
            geom_text_repel(
              data = label_data,
              aes(label = gene),
              size = 4,
              max.overlaps = Inf,
              box.padding = 0.5,
              point.padding = 0.3,
              min.segment.length = 0,
              segment.color = "black",
              segment.size = 0.2,
              show.legend = FALSE
            )
        }
      }
      
      # 保存PNG
      png(file, width = width, height = height, units = "in", res = 300)
      print(p)
      dev.off()
    }
  )
  
  # 下载火山图PDF
  output$download_volcano_pdf <- downloadHandler(
    filename = function() {
      paste("volcano_plot_", Sys.Date(), ".pdf", sep = "")
    },
    content = function(file) {
      req(analysis_results())
      
      # 获取用户设置的尺寸
      width <- input$volcano_width
      height <- input$volcano_height
      
      # 绘制火山图
      data <- analysis_results()$volcano_data
      params <- analysis_results()$params
      
      colors <- c("Up" = "#FF7F24", "Down" = "#5F9EA0", "Not" = "darkgray")
      
      p <- ggplot(data, aes(x = logFC, y = log_pval, color = change)) +
        geom_point(size = 1.5, alpha = 0.6) +
        scale_color_manual(values = colors) +
        geom_vline(xintercept = c(-params$logfc_cutoff, params$logfc_cutoff), 
                   linetype = "dashed", color = "darkgray", linewidth = 0.5) +
        geom_hline(yintercept = -log10(params$pval_cutoff), 
                   linetype = "dashed", color = "darkgray", linewidth = 0.5) +
        theme_bw(base_size = 14) +
        theme(
          legend.position = "right",
          panel.grid = element_blank(),
          legend.title = element_blank(),
          plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
          axis.title = element_text(face = "bold", size = 14),
          axis.text = element_text(size = 12)
        ) +
        labs(
          x = expression(paste(log[2], "(Fold Change)")),
          y = expression(paste(-log[10], "(", 
                               ifelse(params$pval_type == "adj", "adj.P", "P"), 
                               "-value)")),
          title = paste("火山图: ", params$case_group, " vs ", params$control_group)
        )
      
      # 标记基因
      sig_data <- analysis_results()$sig_results
      if (nrow(sig_data) > 0) {
        top_up <- head(sig_data[sig_data$change == "Up", ], 5)
        top_down <- head(sig_data[sig_data$change == "Down", ], 5)
        label_data <- rbind(top_up, top_down)
        label_data <- data[rownames(label_data), ]
        
        if (nrow(label_data) > 0) {
          p <- p + 
            geom_text_repel(
              data = label_data,
              aes(label = gene),
              size = 4,
              max.overlaps = Inf,
              box.padding = 0.5,
              point.padding = 0.3,
              min.segment.length = 0,
              segment.color = "black",
              segment.size = 0.2,
              show.legend = FALSE
            )
        }
      }
      
      # 保存PDF
      pdf(file, width = width, height = height)
      print(p)
      dev.off()
    }
  )
  
  # 下载热图PNG
  output$download_heatmap_png <- downloadHandler(
    filename = function() {
      paste("heatmap_", Sys.Date(), ".png", sep = "")
    },
    content = function(file) {
      req(analysis_results())
      
      # 获取用户设置的尺寸
      width <- input$heatmap_width
      height <- input$heatmap_height
      fontsize <- as.numeric(input$heatmap_fontsize)
      
      data <- analysis_results()
      heatmap_genes <- data$heatmap_genes
      
      if (length(heatmap_genes) == 0) {
        # 创建空白图
        png(file, width = width, height = height, units = "in", res = 300)
        par(mar = c(0, 0, 0, 0))
        plot(0, 0, type = "n", xaxt = "n", yaxt = "n", xlab = "", ylab = "", 
             bty = "n", xlim = c(0, 1), ylim = c(0, 1))
        text(0.5, 0.5, "没有足够的差异基因绘制热图", 
             cex = 1.5, col = "gray")
        dev.off()
        return()
      }
      
      # 提取表达矩阵
      expr_mat <- data$expr_matrix[heatmap_genes, , drop = FALSE]
      
      # 按组排序样本
      group_info <- data$group_info
      group_order <- order(group_info$group)
      expr_mat <- expr_mat[, group_order, drop = FALSE]
      group_info <- group_info[group_order, ]
      
      # 标准化（Z-score）
      expr_mat_scaled <- t(scale(t(expr_mat)))
      expr_mat_scaled[is.na(expr_mat_scaled)] <- 0
      expr_mat_scaled[expr_mat_scaled > 3] <- 3
      expr_mat_scaled[expr_mat_scaled < -3] <- -3
      
      # 分组颜色
      group_colors <- list(
        Group = setNames(
          c("#e04030", "#6cb8d2"),
          c(data$params$case_group, data$params$control_group)
        )
      )
      
      # 创建列注释
      ha <- HeatmapAnnotation(
        Group = group_info$group,
        col = group_colors,
        annotation_name_side = "left",
        annotation_legend_param = list(
          title = "分组",
          title_gp = gpar(fontsize = 12, fontface = "bold"),
          labels_gp = gpar(fontsize = 11)
        ),
        show_annotation_name = TRUE
      )
      
      # 创建热图
      ht <- Heatmap(
        expr_mat_scaled,
        name = "Z-score",
        top_annotation = ha,
        show_row_names = TRUE,
        show_column_names = FALSE,
        cluster_rows = TRUE,
        cluster_columns = FALSE,
        column_split = group_info$group,
        column_title = paste("差异基因热图 (n =", length(heatmap_genes), ")"),
        column_title_gp = gpar(fontsize = 14, fontface = "bold"),
        row_names_gp = gpar(fontsize = fontsize),
        row_title = "基因",
        row_title_gp = gpar(fontsize = 12, fontface = "bold"),
        col = colorRamp2(c(-3, 0, 3), c("#87CEEB", "white", "#DB7093")),
        heatmap_legend_param = list(
          title = "表达水平",
          title_gp = gpar(fontsize = 12, fontface = "bold"),
          labels_gp = gpar(fontsize = 11),
          at = c(-3, -1.5, 0, 1.5, 3),
          labels = c("低", "", "中", "", "高")
        ),
        border = TRUE,
        border_gp = gpar(col = "black", lwd = 0.5)
      )
      
      # 保存PNG
      png(file, width = width, height = height, units = "in", res = 300)
      draw(ht)
      dev.off()
    }
  )
  
  # 下载热图PDF
  output$download_heatmap_pdf <- downloadHandler(
    filename = function() {
      paste("heatmap_", Sys.Date(), ".pdf", sep = "")
    },
    content = function(file) {
      req(analysis_results())
      
      # 获取用户设置的尺寸
      width <- input$heatmap_width
      height <- input$heatmap_height
      fontsize <- as.numeric(input$heatmap_fontsize)
      
      data <- analysis_results()
      heatmap_genes <- data$heatmap_genes
      
      if (length(heatmap_genes) == 0) {
        # 创建空白PDF
        pdf(file, width = width, height = height)
        par(mar = c(0, 0, 0, 0))
        plot(0, 0, type = "n", xaxt = "n", yaxt = "n", xlab = "", ylab = "", 
             bty = "n", xlim = c(0, 1), ylim = c(0, 1))
        text(0.5, 0.5, "没有足够的差异基因绘制热图", 
             cex = 1.5, col = "gray")
        dev.off()
        return()
      }
      
      # 提取表达矩阵
      expr_mat <- data$expr_matrix[heatmap_genes, , drop = FALSE]
      
      # 按组排序样本
      group_info <- data$group_info
      group_order <- order(group_info$group)
      expr_mat <- expr_mat[, group_order, drop = FALSE]
      group_info <- group_info[group_order, ]
      
      # 标准化（Z-score）
      expr_mat_scaled <- t(scale(t(expr_mat)))
      expr_mat_scaled[is.na(expr_mat_scaled)] <- 0
      expr_mat_scaled[expr_mat_scaled > 3] <- 3
      expr_mat_scaled[expr_mat_scaled < -3] <- -3
      
      # 分组颜色
      group_colors <- list(
        Group = setNames(
          c("#e04030", "#6cb8d2"),
          c(data$params$case_group, data$params$control_group)
        )
      )
      
      # 创建列注释
      ha <- HeatmapAnnotation(
        Group = group_info$group,
        col = group_colors,
        annotation_name_side = "left",
        annotation_legend_param = list(
          title = "分组",
          title_gp = gpar(fontsize = 12, fontface = "bold"),
          labels_gp = gpar(fontsize = 11)
        ),
        show_annotation_name = TRUE
      )
      
      # 创建热图
      ht <- Heatmap(
        expr_mat_scaled,
        name = "Z-score",
        top_annotation = ha,
        show_row_names = TRUE,
        show_column_names = FALSE,
        cluster_rows = TRUE,
        cluster_columns = FALSE,
        column_split = group_info$group,
        column_title = paste("差异基因热图 (n =", length(heatmap_genes), ")"),
        column_title_gp = gpar(fontsize = 14, fontface = "bold"),
        row_names_gp = gpar(fontsize = fontsize),
        row_title = "基因",
        row_title_gp = gpar(fontsize = 12, fontface = "bold"),
        col = colorRamp2(c(-3, 0, 3), c("#87CEEB", "white", "#DB7093")),
        heatmap_legend_param = list(
          title = "表达水平",
          title_gp = gpar(fontsize = 12, fontface = "bold"),
          labels_gp = gpar(fontsize = 11),
          at = c(-3, -1.5, 0, 1.5, 3),
          labels = c("低", "", "中", "", "高")
        ),
        border = TRUE,
        border_gp = gpar(col = "black", lwd = 0.5)
      )
      
      # 保存PDF
      pdf(file, width = width, height = height)
      draw(ht)
      dev.off()
    }
  )
}

# 运行应用
shinyApp(ui = ui, server = server)