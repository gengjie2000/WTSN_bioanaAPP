# app.R - 增强版，包含动态网络图和Top20高清下载
library(shiny)
library(shinyjs)
library(shinyWidgets)
library(curl)
library(tidyverse)
library(ggraph)
library(igraph)
library(viridis)
library(tidygraph)
library(patchwork)
library(visNetwork)  # 添加visNetwork用于动态图

####---- 自定义函数 ----####

# 爬虫函数（修改为返回数据，不写入文件）
get.string <- function(ids, score = 150, species = 9606){
  
  # 参数验证
  if(length(ids) == 0) {
    stop("请输入至少一个基因")
  }
  
  if(length(ids) > 200) {
    warning("基因数量超过200个，建议分批分析")
  }
  
  string_api_url <- "https://string-db.org/api"
  
  # 第一步：映射标识符
  output_format <- "tsv"
  method <- paste0("get_string_ids?species=", species, "&identifiers=")
  identifiers <- paste0(ids, collapse = '%0d')
  url <- paste0(c(string_api_url, output_format, method), collapse = '/')
  url <- paste0(url, identifiers)
  
  # 添加错误处理
  tryCatch({
    tmp <- tempfile()
    curl::curl_download(url, tmp, quiet = TRUE)
    identifiers_data <- read.delim2(tmp)
    
    # 检查是否有映射结果
    if(nrow(identifiers_data) == 0) {
      stop("没有找到基因映射信息，请检查基因名称是否正确")
    }
    
    mapped_genes <- identifiers_data %>% 
      filter(score >= 0) %>%  # 过滤掉分数为负的映射
      pull(preferredName) %>% 
      unique()
    
    if(length(mapped_genes) == 0) {
      stop("没有有效的基因映射")
    }
    
    identifiers_str <- paste0(mapped_genes, collapse = '%0d')
    unlink(tmp)
    
    # 第二步：获取PPI网络数据
    output_format <- "tsv"
    method <- paste0("network?species=", species, "&required_score=", score, "&identifiers=")
    url <- paste0(c(string_api_url, output_format, method), collapse = '/')
    url <- paste0(url, identifiers_str)
    
    tmp2 <- tempfile()
    curl::curl_download(url, tmp2, quiet = TRUE)
    ppi_data <- read.delim(tmp2, stringsAsFactors = FALSE)
    
    if(nrow(ppi_data) == 0) {
      stop("没有找到蛋白质相互作用数据")
    }
    
    # 第三步：获取网络图像
    output_format <- "highres_image"
    method <- paste0("network?species=", species, "&required_score=", score, "&identifiers=") 
    url <- paste0(c(string_api_url, output_format, method), collapse = '/')
    url <- paste0(url, identifiers_str)
    
    tmp3 <- tempfile(fileext = ".png")
    curl::curl_download(url, tmp3, quiet = TRUE)
    
    # 返回所有数据
    return(list(
      ppi_data = ppi_data,
      mapped_genes = mapped_genes,
      image_path = tmp3,
      mapping_info = identifiers_data
    ))
    
  }, error = function(e) {
    stop(paste("获取STRING数据失败:", e$message))
  })
}

# 创建图对象
create.graph <- function(data){
  edges <- data[, c("preferredName_A", "preferredName_B", "score")]
  colnames(edges) <- c("from", "to", "weight")
  nodes <- data.frame(name = unique(c(edges$from, edges$to)))
  graph <- graph_from_data_frame(d = edges, vertices = nodes, directed = FALSE)
  
  # 计算degree
  V(graph)$degree <- igraph::degree(graph)
  
  # 添加其他中心性指标
  V(graph)$betweenness <- betweenness(graph)
  V(graph)$closeness <- closeness(graph)
  
  return(graph)
}

# 绘制PPI网络图（静态）
ppi.fig <- function(graph, width = 16, height = 14, layout_type = "fr"){
  
  # 设置不同的布局选项
  if(layout_type == "circle") {
    layout <- layout_in_circle(graph)
  } else if(layout_type == "fr") {
    layout <- layout_with_fr(graph)
  } else if(layout_type == "kk") {
    layout <- layout_with_kk(graph)
  } else if(layout_type == "lgl") {
    layout <- layout_with_lgl(graph)
  } else {
    layout <- layout_with_fr(graph)
  }
  
  p <- ggraph(graph, layout = layout) +
    geom_edge_link(aes(color = weight), alpha = 0.6, width = 1) +
    geom_node_point(aes(size = degree, fill = degree), 
                    shape = 21, color = "white", alpha = 0.9) +
    geom_node_text(aes(label = name), 
                   repel = TRUE,
                   size = 4,
                   max.overlaps = 20) +
    scale_edge_color_gradientn(
      name = "交互分数",
      colors = c("#2E8B57", "#FFD700", "#FF4500")
    ) +
    scale_fill_viridis(
      name = "节点度",
      option = "plasma"
    ) +
    scale_size_continuous(
      name = "节点度",
      range = c(3, 12)
    ) +
    theme_void() +
    theme(
      legend.position = "right",
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.margin = margin(20, 20, 20, 20)
    ) +
    labs(
      title = "蛋白质相互作用网络"
    )
  
  return(p)
}

# 绘制前20个基因的网络图（静态）
plot_top20 <- function(graph, top20_genes){
  top20_graph <- induced_subgraph(graph, top20_genes)
  
  p <- ggraph(top20_graph, layout = "circle") +
    geom_edge_link(aes(color = weight), alpha = 0.7, width = 1.2) +
    geom_node_point(aes(size = degree, fill = degree), 
                    shape = 21, color = "white", alpha = 0.9, size = 8) +
    geom_node_text(aes(label = name), 
                   color = "black",
                   size = 5,
                   fontface = "bold") +
    scale_edge_color_gradientn(
      colors = c("#104680", "#D80305"),
      name = "交互分数"
    ) +
    scale_fill_gradient(
      low = "#9e9ac8",
      high = "#3f007d",
      name = "节点度"
    ) +
    theme_void() +
    theme(
      legend.position = "right",
      plot.title = element_text(hjust = 0.5, size = 14, face = "bold")
    ) +
    labs(title = "Top 20 基因（按节点度排序）")
  
  return(p)
}

# 创建动态网络图（visNetwork）
create.visnetwork <- function(graph, top20 = FALSE) {
  # 提取节点和边数据
  nodes_data <- as_data_frame(graph, what = "vertices")
  edges_data <- as_data_frame(graph, what = "edges")
  
  # 准备节点数据
  nodes <- data.frame(
    id = nodes_data$name,
    label = nodes_data$name,
    value = nodes_data$degree,  # 节点大小基于degree
    title = paste0(
      "基因: ", nodes_data$name, "<br>",
      "度中心性: ", round(nodes_data$degree, 2), "<br>",
      "中介中心性: ", round(nodes_data$betweenness, 2), "<br>",
      "接近中心性: ", round(nodes_data$closeness, 4)
    ),
    group = if(nrow(nodes_data) > 20) {
      # 如果是全网络，将top20标记为不同组
      ifelse(nodes_data$name %in% names(sort(nodes_data$degree, decreasing = TRUE)[1:min(20, nrow(nodes_data))]), 
             "Top20", "Other")
    } else {
      "All"
    },
    stringsAsFactors = FALSE
  )
  
  # 准备边数据
  edges <- data.frame(
    from = edges_data$from,
    to = edges_data$to,
    value = edges_data$weight,  # 边宽度基于权重
    title = paste0("交互分数: ", round(edges_data$weight, 2)),
    color = if(top20) {
      "#104680"  # Top20网络使用固定颜色
    } else {
      # 根据权重设置颜色梯度
      colorRampPalette(c("#2E8B57", "#FFD700", "#FF4500"))(100)[
        as.numeric(cut(edges_data$weight, breaks = 100))
      ]
    },
    stringsAsFactors = FALSE
  )
  
  # 创建visNetwork
  visNetwork(nodes, edges, 
             width = "100%", 
             height = if(top20) "500px" else "700px") %>%
    visOptions(
      highlightNearest = list(
        enabled = TRUE,
        degree = 1,
        hover = TRUE
      ),
      nodesIdSelection = TRUE,
      selectedBy = "group"
    ) %>%
    visInteraction(
      navigationButtons = TRUE,
      dragNodes = TRUE,
      dragView = TRUE,
      zoomView = TRUE,
      tooltipDelay = 100
    ) %>%
    visPhysics(
      solver = "forceAtlas2Based",
      forceAtlas2Based = list(gravitationalConstant = -50),
      stabilization = list(
        enabled = TRUE,
        iterations = 1000
      )
    ) %>%
    visLayout(randomSeed = 123) %>%
    visEdges(
      smooth = list(enabled = TRUE, type = "dynamic"),
      scaling = list(min = 1, max = 5)
    ) %>%
    visNodes(
      scaling = list(min = 10, max = 30),
      shape = "dot",
      shadow = list(enabled = TRUE, size = 10)
    ) %>%
    visLegend(
      position = "right",
      useGroups = if(top20) FALSE else TRUE,
      zoom = FALSE
    )
}

####---- UI界面 ----####
ui <- fluidPage(
  useShinyjs(),
  tags$head(
    tags$style(HTML("
      .shiny-output-error { color: #d9534f; }
      .shiny-output-error:before { content: '错误: '; }
      .well { background-color: #f8f9fa; }
      .btn { margin-right: 5px; }
      .main-header { 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px;
        border-radius: 5px;
        margin-bottom: 20px;
      }
      .sidebar-panel { background-color: #f8f9fa; }
      .btn-action { margin-top: 10px; margin-bottom: 10px; }
      .loading-spinner {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100px;
      }
      .loading-spinner::after {
        content: '';
        width: 40px;
        height: 40px;
        border: 4px solid #f3f3f3;
        border-top: 4px solid #3498db;
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      .vis-network-tooltip {
        font-size: 12px !important;
        max-width: 300px !important;
      }
      .vis-tooltip {
        word-wrap: break-word !important;
        white-space: normal !important;
      }
    "))
  ),
  
  titlePanel(
    div(class = "main-header",
        h1("🔄 蛋白质相互作用（PPI）网络分析平台"),
        h4("基于STRING数据库的PPI网络可视化")
    )
  ),
  
  sidebarLayout(
    sidebarPanel(
      width = 3,
      class = "sidebar-panel",
      
      h4("📝 输入设置", icon = "cog"),
      hr(),
      
      radioButtons(
        "input_type",
        "输入方式:",
        choices = c("手动输入" = "manual", "文件上传" = "file"),
        selected = "manual",
        inline = TRUE
      ),
      
      conditionalPanel(
        condition = "input.input_type == 'manual'",
        textAreaInput(
          "genes",
          "输入基因列表（每行一个或逗号分隔）:",
          rows = 6,
          placeholder = "例如:\nTP53\nBRCA1\nEGFR\n或\nTP53, BRCA1, EGFR"
        )
      ),
      
      conditionalPanel(
        condition = "input.input_type == 'file'",
        fileInput(
          "file",
          "上传基因列表文件:",
          accept = c(".txt", ".csv", ".tsv"),
          placeholder = "支持.txt, .csv, .tsv格式"
        ),
        helpText("文件应包含一列基因名，无表头或表头为'gene'")
      ),
      
      h4("⚙️ 分析参数", icon = "sliders-h"),
      hr(),
      
      selectInput(
        "species",
        "物种:",
        choices = c(
          "人类 (9606)" = 9606,
          "小鼠 (10090)" = 10090,
          "大鼠 (10116)" = 10116,
          "果蝇 (7227)" = 7227,
          "线虫 (6239)" = 6239
        ),
        selected = 9606
      ),
      
      sliderInput(
        "score_threshold",
        "置信度阈值:",
        min = 150,
        max = 900,
        value = 400,
        step = 50,
        ticks = TRUE,
        post = "分"
      ),
      
      helpText("置信度说明: 150(低), 400(中), 700(高), 900(最高)"),
      
      div(class = "btn-action",
          actionButton(
            "analyze",
            "开始分析",
            icon = icon("play"),
            class = "btn-primary btn-block",
            style = "background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                   color: white; font-weight: bold;"
          )
      ),
      
      br(),
      
      conditionalPanel(
        condition = "output.analysis_done",
        h4("💾 下载选项", icon = "download"),
        hr(),
        
        div(class = "btn-action",
            downloadButton("download_csv", "下载CSV数据",
                           class = "btn-success btn-block",
                           style = "margin-bottom: 10px;")
        ),
        
        div(class = "btn-action",
            downloadButton("download_png", "下载PNG图片",
                           class = "btn-warning btn-block",
                           style = "margin-bottom: 10px;")
        ),
        
        div(class = "btn-action",
            downloadButton("download_pdf", "下载PDF图片",
                           class = "btn-danger btn-block",
                           style = "margin-bottom: 10px;")
        ),
        
        div(class = "btn-action",
            downloadButton("download_top20", "下载Top20基因列表",
                           class = "btn-info btn-block",
                           style = "margin-bottom: 10px;")
        ),
        
        div(class = "btn-action",
            downloadButton("download_top20_png", "下载Top20 PNG图片",
                           class = "btn-primary btn-block",
                           style = "margin-bottom: 10px; background-color: #17a2b8;")
        ),
        
        div(class = "btn-action",
            downloadButton("download_top20_pdf", "下载Top20 PDF图片",
                           class = "btn-primary btn-block",
                           style = "margin-bottom: 10px; background-color: #20c997;")
        )
      )
    ),
    
    mainPanel(
      width = 9,
      
      tabsetPanel(
        id = "main_tabs",
        
        tabPanel(
          "📊 动态网络图",
          icon = icon("project-diagram"),
          fluidRow(
            column(12,
                   uiOutput("warning_box"),
                   conditionalPanel(
                     condition = "output.show_loading",
                     div(class = "loading-spinner", "正在加载中...")
                   ),
                   h4("交互式PPI网络图", style = "text-align: center; margin-bottom: 20px;"),
                   p("提示: 可以拖拽节点、滚轮缩放、点击节点高亮关联边", 
                     style = "text-align: center; color: #666; margin-bottom: 10px;"),
                   visNetworkOutput("vis_network", height = "700px"),
                   br(),
                   wellPanel(
                     h5("交互功能说明:"),
                     tags$ul(
                       tags$li("🖱️ 点击节点: 查看节点详细信息"),
                       tags$li("🎯 拖拽节点: 重新布局网络"),
                       tags$li("🔍 鼠标滚轮: 缩放视图"),
                       tags$li("📌 右上角工具栏: 提供多种交互选项"),
                       tags$li("🔍 左上角下拉框: 选择特定节点或组别")
                     )
                   )
            )
          )
        ),
        
        tabPanel(
          "📈 Top 20 基因",
          icon = icon("chart-bar"),
          fluidRow(
            column(6,
                   h4("Top 20基因网络图", style = "text-align: center;"),
                   p("节点大小表示度中心性，边颜色表示交互分数", 
                     style = "text-align: center; color: #666; margin-bottom: 10px;"),
                   plotOutput("top20_static_plot", height = "500px"),
                   div(style = "text-align: center; margin-top: 10px;",
                       actionButton("show_top20_dynamic", "查看动态图", 
                                    icon = icon("sync-alt"),
                                    class = "btn-info btn-sm")
                   )
            ),
            column(6,
                   h4("Top 20基因排名", style = "text-align: center;"),
                   dataTableOutput("top20_table")
            )
          ),
          fluidRow(
            column(12,
                   conditionalPanel(
                     condition = "input.show_top20_dynamic > 0",
                     h4("Top 20基因动态网络图", style = "text-align: center; margin-top: 20px;"),
                     visNetworkOutput("top20_vis_network", height = "500px")
                   )
            )
          )
        ),
        
        tabPanel(
          "📋 数据概览",
          icon = icon("table"),
          fluidRow(
            column(12,
                   h4("网络统计信息"),
                   verbatimTextOutput("network_stats"),
                   br(),
                   h4("节点数据"),
                   dataTableOutput("nodes_table"),
                   br(),
                   h4("边数据"),
                   dataTableOutput("edges_table")
            )
          )
        ),
        
        tabPanel(
          "❓ 使用说明",
          icon = icon("question-circle"),
          div(
            style = "padding: 20px;",
            h3("PPI网络分析平台使用说明"),
            hr(),
            h4("📖 功能介绍"),
            p("本平台基于STRING数据库，提供蛋白质相互作用（PPI）网络的分析和可视化功能。"),
            
            h4("🔧 使用方法"),
            h5("1. 数据输入"),
            p("- 手动输入：在文本框中输入基因名称，每行一个或用逗号分隔"),
            p("- 文件上传：上传包含基因列表的文本文件（支持.txt、.csv、.tsv格式）"),
            
            h5("2. 参数设置"),
            p("- 物种：选择分析的物种（默认：人类）"),
            p("- 置信度阈值：设置PPI互作的置信度阈值（150-900分）"),
            
            h5("3. 分析执行"),
            p("点击'开始分析'按钮，系统将自动："),
            p("- 从STRING数据库获取PPI数据"),
            p("- 构建网络图"),
            p("- 计算网络属性"),
            
            h5("4. 结果查看"),
            p("- 动态网络图：交互式PPI网络可视化"),
            p("- Top 20基因：查看度中心性最高的20个基因"),
            p("- 数据概览：查看详细的网络统计信息"),
            
            h5("5. 数据下载"),
            p("支持下载："),
            p("- CSV格式的网络数据"),
            p("- PNG格式的全网络和Top20网络图"),
            p("- PDF格式的全网络和Top20网络图"),
            p("- Top 20基因列表"),
            
            h4("⚠️ 注意事项"),
            p("1. 基因数量：建议一次分析不超过200个基因"),
            p("2. 网络连接：需要稳定的网络连接访问STRING数据库"),
            p("3. 数据处理：大型网络可能需要较长时间处理"),
            
            h4("🧬 关于STRING数据库"),
            p("STRING数据库（https://string-db.org/）是已知和预测的蛋白质-蛋白质相互作用的数据库，包括直接（物理）和间接（功能）关联。")
          )
        )
      )
    )
  )
)

####---- 服务器逻辑 ----####
server <- function(input, output, session) {
  
  # 创建反应式值存储数据
  values <- reactiveValues(
    ppi_data = NULL,
    graph = NULL,
    top20_genes = NULL,
    image_path = NULL,
    analysis_done = FALSE,
    is_loading = FALSE,
    show_top20_dynamic = FALSE
  )
  
  # 解析基因输入
  parsed_genes <- reactive({
    if(input$input_type == "manual") {
      req(input$genes)
      text <- input$genes
      
      if(text == "") {
        return(character(0))
      }
      
      # 移除空白字符，分割基因
      genes <- str_split(text, "[\n,\t; ]")[[1]] %>%
        str_trim() %>%
        .[. != ""] %>%
        unique()
    } else {
      req(input$file)
      ext <- tools::file_ext(input$file$name)
      
      tryCatch({
        if(ext == "csv") {
          df <- read.csv(input$file$datapath, stringsAsFactors = FALSE)
        } else if(ext == "tsv") {
          df <- read.delim(input$file$datapath, stringsAsFactors = FALSE)
        } else {
          df <- read.table(input$file$datapath, header = FALSE, stringsAsFactors = FALSE)
        }
        
        # 尝试多种可能的列名
        possible_names <- c("gene", "Gene", "GENE", "genes", "symbol", "Symbol", "X")
        gene_col <- NULL
        
        for(name in possible_names) {
          if(name %in% colnames(df)) {
            gene_col <- name
            break
          }
        }
        
        if(is.null(gene_col)) {
          genes <- unique(unlist(df[,1]))
        } else {
          genes <- unique(df[[gene_col]])
        }
        
        # 清理基因名
        genes <- genes[!is.na(genes) & genes != ""] %>%
          str_trim() %>%
          unique()
        
        return(genes)
        
      }, error = function(e) {
        showNotification(paste("读取文件失败:", e$message), type = "error")
        return(character(0))
      })
    }
  })
  
  # 显示警告框
  output$warning_box <- renderUI({
    genes <- parsed_genes()
    if(length(genes) > 200) {
      div(class = "alert alert-warning",
          icon("exclamation-triangle"),
          " 输入的基因数量超过200个，建议分批分析以保证性能。"
      )
    } else if(length(genes) == 0) {
      div(class = "alert alert-info",
          icon("info-circle"),
          " 请输入或上传基因列表。"
      )
    }
  })
  
  # 分析按钮点击事件
  observeEvent(input$analyze, {
    tryCatch({
      # 获取基因列表
      genes <- parsed_genes()
      
      if(length(genes) == 0) {
        stop("请输入有效的基因列表")
      }
      
      # 设置加载状态
      values$is_loading <- TRUE
      
      # 显示进度条
      showModal(modalDialog(
        title = "正在分析中...",
        div(
          style = "text-align: center;",
          tags$p("正在从STRING数据库获取数据，请稍候..."),
          tags$p(paste("分析基因数量:", length(genes))),
          tags$div(class = "progress",
                   tags$div(class = "progress-bar progress-bar-striped active",
                            style = "width: 100%;"
                   )
          )
        ),
        footer = NULL,
        easyClose = FALSE,
        size = "m"
      ))
      
      # 调用STRING API
      result <- get.string(
        ids = genes,
        score = input$score_threshold,
        species = as.numeric(input$species)
      )
      
      # 创建图对象
      graph <- create.graph(result$ppi_data)
      
      # 计算top20基因
      degree_values <- degree(graph)
      sorted_degrees <- sort(degree_values, decreasing = TRUE)
      top20_genes <- names(sorted_degrees[1:min(20, length(sorted_degrees))])
      
      # 存储结果
      values$ppi_data <- result$ppi_data
      values$graph <- graph
      values$top20_genes <- top20_genes
      values$image_path <- result$image_path
      values$analysis_done <- TRUE
      values$is_loading <- FALSE
      values$show_top20_dynamic <- FALSE
      
      # 移除进度条
      removeModal()
      
      # 切换到结果标签页
      updateTabsetPanel(session, "main_tabs", selected = "📊 动态网络图")
      
      # 显示成功消息
      showNotification(
        paste("分析完成！共找到", 
              vcount(graph), "个节点，", 
              ecount(graph), "条边"), 
        type = "success",
        duration = 5
      )
      
    }, error = function(e) {
      removeModal()
      values$is_loading <- FALSE
      showNotification(
        paste("分析失败:", e$message),
        type = "error",
        duration = 10
      )
    })
  })
  
  # 显示Top20动态图按钮
  observeEvent(input$show_top20_dynamic, {
    values$show_top20_dynamic <- input$show_top20_dynamic
  })
  
  # 显示加载状态
  output$show_loading <- reactive({
    values$is_loading
  })
  
  outputOptions(output, "show_loading", suspendWhenHidden = FALSE)
  
  # 主动态网络图
  output$vis_network <- renderVisNetwork({
    req(values$graph)
    
    create.visnetwork(values$graph, top20 = FALSE)
  })
  
  # Top20静态图
  output$top20_static_plot <- renderPlot({
    req(values$graph, values$top20_genes)
    
    if(length(values$top20_genes) > 0) {
      plot_top20(values$graph, values$top20_genes)
    }
  }, res = 96)
  
  # Top20动态网络图
  output$top20_vis_network <- renderVisNetwork({
    req(values$graph, values$top20_genes, values$show_top20_dynamic > 0)
    
    if(length(values$top20_genes) > 0) {
      top20_graph <- induced_subgraph(values$graph, values$top20_genes)
      create.visnetwork(top20_graph, top20 = TRUE)
    }
  })
  
  # Top 20 表格
  output$top20_table <- renderDataTable({
    req(values$graph, values$top20_genes)
    
    if(length(values$top20_genes) > 0) {
      degree_values <- degree(values$graph)
      betweenness_values <- betweenness(values$graph)
      closeness_values <- closeness(values$graph)
      
      data.frame(
        基因 = values$top20_genes,
        度中心性 = round(degree_values[values$top20_genes], 2),
        中介中心性 = round(betweenness_values[values$top20_genes], 2),
        接近中心性 = round(closeness_values[values$top20_genes], 4),
        排名 = 1:length(values$top20_genes)
      )
    }
  }, options = list(
    pageLength = 10,
    scrollX = TRUE,
    dom = 'Bfrtip'
  ))
  
  # 网络统计信息
  output$network_stats <- renderPrint({
    req(values$graph)
    
    cat("=== 网络统计信息 ===\n\n")
    cat("节点数:", vcount(values$graph), "\n")
    cat("边数:", ecount(values$graph), "\n")
    cat("网络密度:", round(edge_density(values$graph), 4), "\n")
    cat("平均度:", round(mean(degree(values$graph)), 2), "\n")
    cat("最大度:", max(degree(values$graph)), "\n")
    cat("平均聚类系数:", round(transitivity(values$graph, type = "average"), 4), "\n")
    
    # 检查是否连通图
    if(is_connected(values$graph)) {
      cat("平均最短路径长度:", round(average.path.length(values$graph), 4), "\n")
      cat("网络直径:", diameter(values$graph), "\n")
    } else {
      cat("注意: 网络不连通\n")
    }
  })
  
  # 节点数据表
  output$nodes_table <- renderDataTable({
    req(values$graph)
    
    as_data_frame(values$graph, what = "vertices") %>%
      select(name, degree, betweenness, closeness) %>%
      arrange(desc(degree))
  }, options = list(
    pageLength = 10,
    scrollX = TRUE
  ))
  
  # 边数据表
  output$edges_table <- renderDataTable({
    req(values$ppi_data)
    
    values$ppi_data %>%
      select(
        preferredName_A,
        preferredName_B,
        score,
        combined_score
      ) %>%
      arrange(desc(score))
  }, options = list(
    pageLength = 10,
    scrollX = TRUE
  ))
  
  # 更新分析完成状态
  output$analysis_done <- reactive({
    values$analysis_done
  })
  
  outputOptions(output, "analysis_done", suspendWhenHidden = FALSE)
  
  # 下载处理函数 - CSV数据
  output$download_csv <- downloadHandler(
    filename = function() {
      paste0("ppi_network_data_", Sys.Date(), ".zip")
    },
    content = function(file) {
      req(values$graph, values$ppi_data)
      
      # 创建临时目录
      temp_dir <- tempdir()
      
      # 保存节点数据
      nodes_df <- as_data_frame(values$graph, what = "vertices")
      write.csv(nodes_df, 
                file.path(temp_dir, "nodes.csv"), 
                row.names = FALSE)
      
      # 保存边数据
      edges_df <- as_data_frame(values$graph, what = "edges")
      write.csv(edges_df, 
                file.path(temp_dir, "edges.csv"), 
                row.names = FALSE)
      
      # 保存原始PPI数据
      write.csv(values$ppi_data, 
                file.path(temp_dir, "ppi_raw_data.csv"), 
                row.names = FALSE)
      
      # 创建ZIP文件
      zip_files <- c(
        file.path(temp_dir, "nodes.csv"),
        file.path(temp_dir, "edges.csv"),
        file.path(temp_dir, "ppi_raw_data.csv")
      )
      
      # 使用系统命令创建ZIP文件
      old_wd <- setwd(temp_dir)
      zip(file, files = basename(zip_files))
      setwd(old_wd)
    }
  )
  
  # 下载全网络PNG图片
  output$download_png <- downloadHandler(
    filename = function() {
      paste0("ppi_network_", Sys.Date(), ".png")
    },
    content = function(file) {
      req(values$graph)
      
      p <- ppi.fig(values$graph)
      ggsave(file, p, width = 16, height = 14, dpi = 300, bg = "white")
    }
  )
  
  # 下载全网络PDF图片
  output$download_pdf <- downloadHandler(
    filename = function() {
      paste0("ppi_network_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      req(values$graph)
      
      p <- ppi.fig(values$graph)
      ggsave(file, p, width = 16, height = 14, device = "pdf")
    }
  )
  
  # 下载Top20基因列表
  output$download_top20 <- downloadHandler(
    filename = function() {
      paste0("top20_genes_", Sys.Date(), ".csv")
    },
    content = function(file) {
      req(values$graph, values$top20_genes)
      
      degree_values <- degree(values$graph)
      betweenness_values <- betweenness(values$graph)
      closeness_values <- closeness(values$graph)
      
      top20_df <- data.frame(
        Gene = values$top20_genes,
        Degree = round(degree_values[values$top20_genes], 2),
        Betweenness = round(betweenness_values[values$top20_genes], 2),
        Closeness = round(closeness_values[values$top20_genes], 4),
        Rank = 1:length(values$top20_genes)
      )
      
      write.csv(top20_df, file, row.names = FALSE)
    }
  )
  
  # 下载Top20网络PNG图片
  output$download_top20_png <- downloadHandler(
    filename = function() {
      paste0("top20_network_", Sys.Date(), ".png")
    },
    content = function(file) {
      req(values$graph, values$top20_genes)
      
      if(length(values$top20_genes) > 0) {
        top20_graph <- induced_subgraph(values$graph, values$top20_genes)
        p <- plot_top20(top20_graph, values$top20_genes)
        ggsave(file, p, width = 12, height = 10, dpi = 300, bg = "white")
      }
    }
  )
  
  # 下载Top20网络PDF图片
  output$download_top20_pdf <- downloadHandler(
    filename = function() {
      paste0("top20_network_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      req(values$graph, values$top20_genes)
      
      if(length(values$top20_genes) > 0) {
        top20_graph <- induced_subgraph(values$graph, values$top20_genes)
        p <- plot_top20(top20_graph, values$top20_genes)
        ggsave(file, p, width = 12, height = 10, device = "pdf")
        
      }
    }
  )
  
  # 会话结束时清理临时文件
  session$onSessionEnded(function() {
    if(!is.null(values$image_path) && file.exists(values$image_path)) {
      unlink(values$image_path)
    }
  })
}

# 运行应用
shinyApp(ui = ui, server = server)