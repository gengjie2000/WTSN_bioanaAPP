# app.R
library(shiny)
library(shinydashboard)
library(DT)
library(clusterProfiler)
library(org.Hs.eg.db)
library(ggplot2)
library(enrichplot)
library(GOplot)
library(openxlsx)
library(stringr)
library(dplyr)
library(tibble)

# 定义UI界面
ui <- dashboardPage(
  dashboardHeader(title = "富集分析平台"),
  
  dashboardSidebar(
    sidebarMenu(
      id = "tabs",
      menuItem("数据上传", tabName = "upload", icon = icon("upload")),
      menuItem("GO富集分析", tabName = "go", icon = icon("dna")),
      menuItem("KEGG富集分析", tabName = "kegg", icon = icon("project-diagram")),
      menuItem("帮助文档", tabName = "help", icon = icon("question-circle"))
    ),
    
    # 分析参数设置
    conditionalPanel(
      'input.tabs == "go" || input.tabs == "kegg"',
      h4("分析参数"),
      numericInput("pvalue_cutoff", "p-value阈值:", 0.05, min = 0.001, max = 1, step = 0.01),
      numericInput("qvalue_cutoff", "q-value阈值:", 0.2, min = 0.001, max = 1, step = 0.01),
      numericInput("show_category", "显示通路数:", 20, min = 5, max = 50, step = 5),
      selectInput("ontology", "GO分类:", 
                  choices = c("ALL", "BP", "CC", "MF"), 
                  selected = "ALL"),
      actionButton("run_analysis", "开始分析", 
                   icon = icon("play"),
                   class = "btn-primary"),
      hr(),
      verbatimTextOutput("debug_info")
    )
  ),
  
  dashboardBody(
    tabItems(
      # 数据上传标签页
      tabItem(
        tabName = "upload",
        h2("数据上传"),
        box(
          title = "基因列表上传", width = 6, status = "primary", solidHeader = TRUE,
          fileInput("gene_file", "上传基因列表文件",
                    accept = c(".csv", ".txt", ".xlsx", ".xls")),
          helpText("支持格式: CSV, TXT, Excel"),
          helpText("文件应包含一列基因符号"),
          checkboxInput("has_header", "文件有表头", TRUE),
          helpText("如果上传CSV文件，请选择分隔符:"),
          radioButtons("sep", "分隔符:", 
                       choices = c(逗号 = ",", 分号 = ";", 制表符 = "\t"),
                       selected = ",")
        ),
        
        box(
          title = "差异分析结果上传 (可选)", width = 6, status = "warning", solidHeader = TRUE,
          fileInput("deg_file", "上传差异分析结果",
                    accept = c(".csv", ".txt", ".xlsx", ".xls")),
          helpText("如果上传，将绘制圈图；否则绘制简单图表"),
          helpText("文件应包含基因符号和log2FoldChange列"),
          conditionalPanel(
            condition = "output.deg_file_uploaded",
            textInput("gene_col", "基因列名:", value = "Gene"),
            textInput("logfc_col", "logFC列名:", value = "log2FoldChange")
          )
        ),
        
        box(
          title = "数据预览", width = 12, status = "info", solidHeader = TRUE,
          h4("基因列表预览 (前20行):"),
          DTOutput("gene_preview"),
          br(),
          conditionalPanel(
            condition = "output.deg_file_uploaded",
            h4("差异分析结果预览 (前20行):"),
            DTOutput("deg_preview")
          ),
          hr(),
          verbatimTextOutput("upload_info")
        )
      ),
      
      # GO富集分析标签页
      tabItem(
        tabName = "go",
        h2("GO富集分析结果"),
        
        # 显示状态信息
        conditionalPanel(
          condition = "output.show_go_status",
          box(
            title = "分析状态", width = 12, status = "warning", solidHeader = TRUE,
            htmlOutput("go_status_message")
          )
        ),
        
        fluidRow(
          valueBoxOutput("go_bp_count"),
          valueBoxOutput("go_cc_count"),
          valueBoxOutput("go_mf_count")
        ),
        
        tabsetPanel(
          id = "go_tabs",
          tabPanel("结果表格",
                   br(),
                   downloadButton("download_go_table", "下载GO结果 (Excel)"),
                   downloadButton("download_go_csv", "下载GO结果 (CSV)"),
                   br(), br(),
                   DTOutput("go_table")),
          
          tabPanel("可视化图表",
                   br(),
                   fluidRow(
                     column(6,
                            selectInput("go_plot_type", "图表类型:",
                                        choices = c("柱状图", "气泡图", "圈图"),
                                        selected = "柱状图"),
                            conditionalPanel(
                              condition = "input.go_plot_type == '圈图'",
                              checkboxInput("go_table_legend", "显示图例表格", TRUE)
                            )
                     ),
                     column(6,
                            downloadButton("download_go_png", "下载PNG"),
                            downloadButton("download_go_pdf", "下载PDF"),
                            br(),
                            numericInput("go_plot_width", "图表宽度 (英寸):", 10, min = 6, max = 20),
                            numericInput("go_plot_height", "图表高度 (英寸):", 8, min = 4, max = 15)
                     )
                   ),
                   br(),
                   plotOutput("go_plot", height = "600px"))
        )
      ),
      
      # KEGG富集分析标签页
      tabItem(
        tabName = "kegg",
        h2("KEGG富集分析结果"),
        
        # 显示状态信息
        conditionalPanel(
          condition = "output.show_kegg_status",
          box(
            title = "分析状态", width = 12, status = "warning", solidHeader = TRUE,
            htmlOutput("kegg_status_message")
          )
        ),
        
        valueBoxOutput("kegg_count"),
        
        tabsetPanel(
          id = "kegg_tabs",
          tabPanel("结果表格",
                   br(),
                   downloadButton("download_kegg_table", "下载KEGG结果 (Excel)"),
                   downloadButton("download_kegg_csv", "下载KEGG结果 (CSV)"),
                   br(), br(),
                   DTOutput("kegg_table")),
          
          tabPanel("可视化图表",
                   br(),
                   fluidRow(
                     column(6,
                            selectInput("kegg_plot_type", "图表类型:",
                                        choices = c("柱状图", "气泡图", "圈图"),
                                        selected = "柱状图"),
                            conditionalPanel(
                              condition = "input.kegg_plot_type == '圈图'",
                              checkboxInput("kegg_table_legend", "显示图例表格", TRUE)
                            )
                     ),
                     column(6,
                            downloadButton("download_kegg_png", "下载PNG"),
                            downloadButton("download_kegg_pdf", "下载PDF"),
                            br(),
                            numericInput("kegg_plot_width", "图表宽度 (英寸):", 10, min = 6, max = 20),
                            numericInput("kegg_plot_height", "图表高度 (英寸):", 8, min = 4, max = 15)
                     )
                   ),
                   br(),
                   plotOutput("kegg_plot", height = "600px"))
        )
      ),
      
      # 帮助文档标签页
      tabItem(
        tabName = "help",
        h2("使用说明"),
        box(
          title = "数据格式要求", width = 12, status = "info",
          h4("1. 基因列表文件格式:"),
          tags$ul(
            tags$li("纯文本文件 (CSV/TXT) 或 Excel 文件"),
            tags$li("包含一列基因符号 (Gene Symbol)"),
            tags$li("示例格式 (CSV):"),
            tags$pre("
Gene
TP53
BRCA1
EGFR
MYC
AKT1"),
            tags$li("示例格式 (Excel): 同样只需一列基因符号")
          ),
          
          h4("2. 差异分析结果文件格式 (可选):"),
          tags$ul(
            tags$li("应包含两列：基因符号和log2FoldChange"),
            tags$li("示例格式:"),
            tags$pre("
Gene,log2FoldChange
TP53,2.5
BRCA1,-1.8
EGFR,3.2
MYC,1.5
AKT1,-0.8")
          ),
          
          h4("3. 结果说明:"),
          tags$ul(
            tags$li("上传差异分析结果：绘制圈图 (Chordal Chart)"),
            tags$li("仅上传基因列表：绘制柱状图或气泡图"),
            tags$li("支持结果表格下载 (CSV/Excel)"),
            tags$li("支持图表下载 (PNG/PDF)")
          ),
          
          h4("4. 常见问题:"),
          tags$ul(
            tags$li("上传文件后没有反应？请检查文件格式是否正确"),
            tags$li("富集分析失败？请检查基因符号是否有效（如TP53, BRCA1等）"),
            tags$li("没有显示圈图？请确认已上传差异分析结果文件"),
            tags$li("KEGG分析较慢？这需要从KEGG数据库下载数据，请耐心等待")
          )
        )
      )
    )
  )
)

# 定义服务器逻辑
server <- function(input, output, session) {
  
  # 响应式值存储数据
  values <- reactiveValues(
    genes = NULL,
    deg_data = NULL,
    go_result = NULL,
    kegg_result = NULL,
    go_plot_obj = NULL,
    kegg_plot_obj = NULL,
    analysis_done = FALSE
  )
  
  # 监控差异分析文件上传状态
  output$deg_file_uploaded <- reactive({
    return(!is.null(input$deg_file))
  })
  outputOptions(output, "deg_file_uploaded", suspendWhenHidden = FALSE)
  
  # 监控GO分析状态
  output$show_go_status <- reactive({
    return(input$tabs == "go" && is.null(values$go_result) && values$analysis_done)
  })
  outputOptions(output, "show_go_status", suspendWhenHidden = FALSE)
  
  # 监控KEGG分析状态
  output$show_kegg_status <- reactive({
    return(input$tabs == "kegg" && is.null(values$kegg_result) && values$analysis_done)
  })
  outputOptions(output, "show_kegg_status", suspendWhenHidden = FALSE)
  
  # 状态信息
  output$go_status_message <- renderUI({
    if (is.null(values$genes)) {
      HTML("<div style='color:red;'>请先上传基因列表并点击'开始分析'按钮</div>")
    } else if (is.null(values$go_result)) {
      HTML("<div style='color:orange;'>GO富集分析中...请确保基因符号格式正确</div>")
    } else {
      HTML("<div style='color:green;'>GO富集分析已完成</div>")
    }
  })
  
  output$kegg_status_message <- renderUI({
    if (is.null(values$genes)) {
      HTML("<div style='color:red;'>请先上传基因列表并点击'开始分析'按钮</div>")
    } else if (is.null(values$kegg_result)) {
      HTML("<div style='color:orange;'>KEGG富集分析中...可能需要一些时间从KEGG数据库下载数据</div>")
    } else {
      HTML("<div style='color:green;'>KEGG富集分析已完成</div>")
    }
  })
  
  # 读取基因列表文件
  observeEvent(input$gene_file, {
    req(input$gene_file)
    
    tryCatch({
      ext <- tools::file_ext(input$gene_file$name)
      
      if (ext %in% c("csv", "txt")) {
        sep <- switch(input$sep,
                      "," = ",",
                      ";" = ";",
                      "\t" = "\t")
        genes <- read.csv(input$gene_file$datapath, 
                          header = input$has_header,
                          sep = sep,
                          stringsAsFactors = FALSE,
                          check.names = FALSE)
      } else if (ext %in% c("xlsx", "xls")) {
        genes <- read.xlsx(input$gene_file$datapath, check.names = FALSE)
      } else {
        showNotification("不支持的文件格式！", type = "error")
        return()
      }
      
      # 检查数据
      if (ncol(genes) < 1) {
        showNotification("文件至少需要有一列！", type = "error")
        return()
      }
      
      # 假设第一列是基因符号
      gene_col <- names(genes)[1]
      values$genes <- unique(na.omit(as.character(genes[[gene_col]])))
      
      # 重置分析结果
      values$go_result <- NULL
      values$kegg_result <- NULL
      values$analysis_done <- FALSE
      
      showNotification(paste("成功读取", length(values$genes), "个基因"), 
                       type = "default")
      
    }, error = function(e) {
      showNotification(paste("读取基因文件出错:", e$message), 
                       type = "error", duration = 10)
    })
  })
  
  # 读取差异分析文件
  observeEvent(input$deg_file, {
    req(input$deg_file)
    
    tryCatch({
      ext <- tools::file_ext(input$deg_file$name)
      
      if (ext %in% c("csv", "txt")) {
        sep <- switch(input$sep,
                      "," = ",",
                      ";" = ";",
                      "\t" = "\t")
        deg_data <- read.csv(input$deg_file$datapath, 
                             header = input$has_header,
                             sep = sep,
                             stringsAsFactors = FALSE,
                             check.names = FALSE)
      } else if (ext %in% c("xlsx", "xls")) {
        deg_data <- read.xlsx(input$deg_file$datapath, check.names = FALSE)
      } else {
        showNotification("不支持的文件格式！", type = "error")
        return()
      }
      
      values$deg_data <- deg_data
      
      # 重置分析结果
      values$go_result <- NULL
      values$kegg_result <- NULL
      values$analysis_done <- FALSE
      
      showNotification(paste("成功读取差异分析结果，", nrow(deg_data), "行数据"), 
                       type = "default")
      
    }, error = function(e) {
      showNotification(paste("读取差异分析文件出错:", e$message), 
                       type = "error", duration = 10)
    })
  })
  
  # 数据预览
  output$gene_preview <- renderDT({
    req(values$genes)
    data.frame(Gene_Symbol = head(values$genes, 20),
               Total_Genes = length(values$genes))
  }, options = list(pageLength = 10, dom = 't'))
  
  output$deg_preview <- renderDT({
    req(input$deg_file)
    
    tryCatch({
      ext <- tools::file_ext(input$deg_file$name)
      
      if (ext %in% c("csv", "txt")) {
        sep <- switch(input$sep,
                      "," = ",",
                      ";" = ";",
                      "\t" = "\t")
        preview <- read.csv(input$deg_file$datapath, 
                            header = input$has_header,
                            sep = sep,
                            nrows = 20,
                            stringsAsFactors = FALSE,
                            check.names = FALSE)
      } else if (ext %in% c("xlsx", "xls")) {
        preview <- read.xlsx(input$deg_file$datapath, rows = 1:20, check.names = FALSE)
      }
      
      if (!is.null(preview)) {
        preview
      }
    }, error = function(e) {
      data.frame(Error = paste("读取文件出错:", e$message))
    })
  }, options = list(pageLength = 10))
  
  # 上传信息
  output$upload_info <- renderText({
    info <- ""
    if (!is.null(values$genes)) {
      info <- paste0("已上传基因: ", length(values$genes), " 个\n")
    }
    if (!is.null(input$deg_file)) {
      info <- paste0(info, "已上传差异分析文件: ", input$deg_file$name)
    }
    if (info == "") {
      info <- "请上传基因列表文件"
    }
    info
  })
  
  # 调试信息
  output$debug_info <- renderText({
    paste0(
      "基因数量: ", ifelse(is.null(values$genes), 0, length(values$genes)), "\n",
      "差异文件: ", ifelse(is.null(input$deg_file), "未上传", "已上传"), "\n",
      "分析状态: ", ifelse(values$analysis_done, "已完成", "未开始")
    )
  })
  
  # 执行富集分析
  observeEvent(input$run_analysis, {
    req(values$genes)
    
    # 验证基因数量
    if (length(values$genes) < 5) {
      showNotification("基因数量太少（至少需要5个基因）", type = "warning")
      return()
    }
    
    withProgress(message = '正在进行富集分析...', value = 0, {
      # 基因ID转换
      incProgress(0.1, detail = "基因ID转换...")
      
      gene_symbol <- tryCatch({
        result <- bitr(geneID = values$genes,
                       fromType = "SYMBOL",
                       toType = "ENTREZID",
                       OrgDb = org.Hs.eg.db,
                       drop = TRUE)
        
        if (nrow(result) == 0) {
          showNotification("基因ID转换失败：没有找到匹配的ENTREZ ID", 
                           type = "error")
          return(NULL)
        }
        
        # 检查转换成功率
        conversion_rate <- nrow(result) / length(values$genes)
        if (conversion_rate < 0.5) {
          showNotification(paste0("警告：只有", round(conversion_rate*100, 1), 
                                  "%的基因成功转换ID"), 
                           type = "warning")
        }
        
        result
        
      }, error = function(e) {
        showNotification(paste("基因ID转换失败:", e$message), 
                         type = "error")
        return(NULL)
      })
      
      if (is.null(gene_symbol)) return()
      
      # GO富集分析
      incProgress(0.3, detail = "GO富集分析...")
      
      go_res <- tryCatch({
        enrich_result <- enrichGO(gene = gene_symbol$ENTREZID,
                                  OrgDb = org.Hs.eg.db,
                                  keyType = "ENTREZID",
                                  ont = input$ontology,
                                  pAdjustMethod = "BH",
                                  pvalueCutoff = input$pvalue_cutoff,
                                  qvalueCutoff = input$qvalue_cutoff,
                                  readable = TRUE)
        
        if (!is.null(enrich_result) && nrow(enrich_result@result) > 0) {
          result_df <- enrich_result@result
          result_df$richFactor <- result_df$Count / 
            as.numeric(sub("/\\d+", "", result_df$BgRatio))
          result_df
        } else {
          showNotification("GO富集分析未找到显著结果", type = "warning")
          NULL
        }
        
      }, error = function(e) {
        showNotification(paste("GO富集分析出错:", e$message), 
                         type = "error")
        return(NULL)
      })
      
      if (!is.null(go_res)) {
        values$go_result <- go_res
      }
      
      # KEGG富集分析
      incProgress(0.6, detail = "KEGG富集分析...")
      
      kegg_res <- tryCatch({
        kk <- enrichKEGG(gene = gene_symbol$ENTREZID,
                         organism = "hsa",
                         keyType = "kegg",
                         pvalueCutoff = input$pvalue_cutoff,
                         qvalueCutoff = input$qvalue_cutoff)
        
        if (!is.null(kk) && nrow(kk@result) > 0) {
          kk <- setReadable(kk, OrgDb = org.Hs.eg.db, keyType = "ENTREZID")
          result_df <- kk@result
          result_df$richFactor <- result_df$Count / 
            as.numeric(sub("/\\d+", "", result_df$BgRatio))
          result_df
        } else {
          showNotification("KEGG富集分析未找到显著结果", type = "warning")
          NULL
        }
        
      }, error = function(e) {
        showNotification(paste("KEGG富集分析出错:", e$message), 
                         type = "error")
        return(NULL)
      })
      
      if (!is.null(kegg_res)) {
        values$kegg_result <- kegg_res
      }
      
      incProgress(1, detail = "完成！")
      values$analysis_done <- TRUE
      
      # 显示成功消息
      go_count <- ifelse(is.null(go_res), 0, nrow(go_res))
      kegg_count <- ifelse(is.null(kegg_res), 0, nrow(kegg_res))
      
      showNotification(paste0("分析完成！找到", go_count, "个GO通路，", 
                              kegg_count, "个KEGG通路"), 
                       type = "default")
    })
  })
  
  # GO结果计数
  output$go_bp_count <- renderValueBox({
    count <- 0
    if (!is.null(values$go_result)) {
      count <- sum(values$go_result$ONTOLOGY == "BP", na.rm = TRUE)
    }
    valueBox(count, "BP通路数", icon = icon("dna"), color = "blue")
  })
  
  output$go_cc_count <- renderValueBox({
    count <- 0
    if (!is.null(values$go_result)) {
      count <- sum(values$go_result$ONTOLOGY == "CC", na.rm = TRUE)
    }
    valueBox(count, "CC通路数", icon = icon("circle"), color = "green")  # 修复了图标名称
  })
  
  output$go_mf_count <- renderValueBox({
    count <- 0
    if (!is.null(values$go_result)) {
      count <- sum(values$go_result$ONTOLOGY == "MF", na.rm = TRUE)
    }
    valueBox(count, "MF通路数", icon = icon("flask"), color = "yellow")
  })
  
  output$kegg_count <- renderValueBox({
    count <- 0
    if (!is.null(values$kegg_result)) {
      count <- nrow(values$kegg_result)
    }
    valueBox(count, "KEGG通路数", icon = icon("project-diagram"), color = "red")
  })
  
  # GO结果表格 - 修复select问题
  output$go_table <- renderDT({
    req(values$go_result)
    
    tryCatch({
      # 使用基础R方法选择列，避免dplyr::select的问题
      cols_to_show <- c("ID", "Description", "ONTOLOGY", "pvalue", "p.adjust", "qvalue", 
                        "Count", "GeneRatio", "BgRatio", "geneID", "richFactor")
      
      # 检查哪些列存在
      existing_cols <- intersect(cols_to_show, names(values$go_result))
      
      # 只选择存在的列
      display_data <- values$go_result[, existing_cols, drop = FALSE]
      
      # 重命名列以便更好的显示
      colnames(display_data) <- ifelse(colnames(display_data) == "p.adjust", "adj.pvalue", 
                                       ifelse(colnames(display_data) == "geneID", "Genes",
                                              colnames(display_data)))
      
      # 格式化数值列
      if ("pvalue" %in% names(display_data)) {
        display_data$pvalue <- round(display_data$pvalue, 4)
      }
      if ("adj.pvalue" %in% names(display_data)) {
        display_data$adj.pvalue <- round(display_data$adj.pvalue, 4)
      }
      if ("qvalue" %in% names(display_data)) {
        display_data$qvalue <- round(display_data$qvalue, 4)
      }
      if ("richFactor" %in% names(display_data)) {
        display_data$richFactor <- round(display_data$richFactor, 3)
      }
      
      datatable(display_data,
                options = list(
                  pageLength = 20,
                  scrollX = TRUE,
                  lengthMenu = c(10, 20, 50, 100),
                  order = list(list(which(names(display_data) == "pvalue") - 1, 'asc'))  # 按pvalue排序
                ),
                filter = 'top',
                class = 'display compact hover',
                rownames = FALSE) %>%
        formatStyle('pvalue',
                    background = styleColorBar(range(display_data$pvalue, na.rm = TRUE), 'lightblue'),
                    backgroundSize = '100% 90%',
                    backgroundRepeat = 'no-repeat',
                    backgroundPosition = 'center')
      
    }, error = function(e) {
      # 如果出错，显示原始数据
      datatable(values$go_result,
                options = list(
                  pageLength = 20,
                  scrollX = TRUE
                ),
                filter = 'top',
                class = 'display compact hover',
                rownames = FALSE)
    })
  })
  
  # KEGG结果表格 - 修复select问题
  output$kegg_table <- renderDT({
    req(values$kegg_result)
    
    tryCatch({
      # 使用基础R方法选择列，避免dplyr::select的问题
      cols_to_show <- c("ID", "Description", "pvalue", "p.adjust", "qvalue", 
                        "Count", "GeneRatio", "BgRatio", "geneID", "richFactor")
      
      # 检查哪些列存在
      existing_cols <- intersect(cols_to_show, names(values$kegg_result))
      
      # 只选择存在的列
      display_data <- values$kegg_result[, existing_cols, drop = FALSE]
      
      # 重命名列以便更好的显示
      colnames(display_data) <- ifelse(colnames(display_data) == "p.adjust", "adj.pvalue", 
                                       ifelse(colnames(display_data) == "geneID", "Genes",
                                              colnames(display_data)))
      
      # 格式化数值列
      if ("pvalue" %in% names(display_data)) {
        display_data$pvalue <- round(display_data$pvalue, 4)
      }
      if ("adj.pvalue" %in% names(display_data)) {
        display_data$adj.pvalue <- round(display_data$adj.pvalue, 4)
      }
      if ("qvalue" %in% names(display_data)) {
        display_data$qvalue <- round(display_data$qvalue, 4)
      }
      if ("richFactor" %in% names(display_data)) {
        display_data$richFactor <- round(display_data$richFactor, 3)
      }
      
      datatable(display_data,
                options = list(
                  pageLength = 20,
                  scrollX = TRUE,
                  lengthMenu = c(10, 20, 50, 100),
                  order = list(list(which(names(display_data) == "pvalue") - 1, 'asc'))  # 按pvalue排序
                ),
                filter = 'top',
                class = 'display compact hover',
                rownames = FALSE) %>%
        formatStyle('pvalue',
                    background = styleColorBar(range(display_data$pvalue, na.rm = TRUE), 'lightblue'),
                    backgroundSize = '100% 90%',
                    backgroundRepeat = 'no-repeat',
                    backgroundPosition = 'center')
      
    }, error = function(e) {
      # 如果出错，显示原始数据
      datatable(values$kegg_result,
                options = list(
                  pageLength = 20,
                  scrollX = TRUE
                ),
                filter = 'top',
                class = 'display compact hover',
                rownames = FALSE)
    })
  })
  
  # GO可视化
  output$go_plot <- renderPlot({
    req(values$go_result)
    
    tryCatch({
      # 根据是否有差异分析结果决定绘图类型
      has_deg <- !is.null(input$deg_file) && !is.null(values$deg_data)
      
      if (has_deg && input$go_plot_type == "圈图") {
        # 准备数据
        go_sub <- head(values$go_result[order(values$go_result$pvalue), ], 
                       min(input$show_category, nrow(values$go_result)))
        
        if (nrow(go_sub) == 0) {
          plot(0, 0, type = "n", xlab = "", ylab = "", axes = FALSE,
               main = "没有显著富集的GO通路")
          text(0, 0, "请调整p-value阈值或检查输入基因", cex = 1.2)
          return()
        }
        
        # 准备圈图数据
        go_data <- data.frame(
          Category = go_sub$ONTOLOGY,
          ID = go_sub$ID,
          Term = go_sub$Description,
          Genes = go_sub$geneID,
          adj_pval = go_sub$pvalue
        )
        
        # 准备基因列表 - 需要从deg_data中提取
        if (!is.null(input$gene_col) && !is.null(input$logfc_col)) {
          # 读取deg文件
          ext <- tools::file_ext(input$deg_file$name)
          if (ext %in% c("csv", "txt")) {
            sep <- switch(input$sep,
                          "," = ",",
                          ";" = ";",
                          "\t" = "\t")
            deg_data_full <- read.csv(input$deg_file$datapath, 
                                      header = input$has_header,
                                      sep = sep,
                                      stringsAsFactors = FALSE,
                                      check.names = FALSE)
          } else if (ext %in% c("xlsx", "xls")) {
            deg_data_full <- read.xlsx(input$deg_file$datapath, check.names = FALSE)
          }
          
          # 检查列名
          if (input$gene_col %in% names(deg_data_full) && 
              input$logfc_col %in% names(deg_data_full)) {
            gene_list <- data.frame(
              ID = deg_data_full[[input$gene_col]],
              logFC = deg_data_full[[input$logfc_col]]
            )
            
            # 创建圈图数据
            circle_data <- circle_dat(go_data, gene_list)
            
            # 生成圈图
            p <- GOCircle(
              data = circle_data,
              nsub = min(input$show_category, nrow(go_data)),
              rad1 = 2.5, rad2 = 3.5,
              zsc.col = c("#96C37D", 'white', '#5F97D2'),
              lfc.col = c('#96C37D', '#5F97D2'),
              label.size = 3.2,
              label.fontface = 'plain',
              table.legend = ifelse(is.null(input$go_table_legend), TRUE, input$go_table_legend)
            )
            
            values$go_plot_obj <- p
            return(p)
          }
        }
      }
      
      # 如果圈图条件不满足，绘制简单图表
      go_sub <- head(values$go_result[order(values$go_result$pvalue), ], 
                     min(input$show_category, nrow(values$go_result)))
      
      if (nrow(go_sub) == 0) {
        plot(0, 0, type = "n", xlab = "", ylab = "", axes = FALSE,
             main = "没有显著富集的GO通路")
        text(0, 0, "请调整p-value阈值或检查输入基因", cex = 1.2)
        return()
      }
      
      if (input$go_plot_type == "柱状图") {
        # 柱状图
        go_sub$log10_pvalue <- -log10(go_sub$pvalue)
        
        # 确保Description是字符型
        go_sub$Description <- as.character(go_sub$Description)
        
        p <- ggplot(go_sub, aes(x = reorder(Description, log10_pvalue), 
                                y = log10_pvalue, 
                                fill = if("ONTOLOGY" %in% names(go_sub)) ONTOLOGY else "Category")) +
          geom_bar(stat = "identity") +
          coord_flip() +
          labs(x = "", y = "-log10(p-value)", 
               title = "GO富集分析结果") +
          theme_minimal() +
          theme(axis.text = element_text(size = 10),
                plot.title = element_text(hjust = 0.5, size = 16))
        
        if ("ONTOLOGY" %in% names(go_sub)) {
          p <- p + scale_fill_manual(values = c("BP" = "#2E86AB", "CC" = "#A23B72", "MF" = "#F18F01")) +
            labs(fill = "GO分类")
        }
        
      } else {
        # 气泡图
        # 确保Description是字符型
        go_sub$Description <- as.character(go_sub$Description)
        
        p <- ggplot(go_sub, aes(x = if("richFactor" %in% names(go_sub)) richFactor else Count, 
                                y = reorder(Description, pvalue))) +
          geom_point(aes(size = Count, color = -log10(pvalue))) +
          scale_color_gradient(low = "blue", high = "red", name = "-log10(p-value)") +
          scale_size_continuous(name = "基因数", range = c(3, 10)) +
          labs(x = if("richFactor" %in% names(go_sub)) "富集因子" else "基因数", 
               y = "", 
               title = "GO富集分析气泡图") +
          theme_minimal() +
          theme(axis.text = element_text(size = 10),
                plot.title = element_text(hjust = 0.5, size = 16),
                legend.position = "right")
      }
      
      values$go_plot_obj <- p
      p
      
    }, error = function(e) {
      plot(0, 0, type = "n", xlab = "", ylab = "", axes = FALSE,
           main = "绘图出错")
      text(0, 0, paste("错误:", e$message), cex = 1.2)
    })
  })
  
  # KEGG可视化
  output$kegg_plot <- renderPlot({
    req(values$kegg_result)
    
    tryCatch({
      # 根据是否有差异分析结果决定绘图类型
      has_deg <- !is.null(input$deg_file) && !is.null(values$deg_data)
      
      if (has_deg && input$kegg_plot_type == "圈图") {
        # 准备数据
        kegg_sub <- head(values$kegg_result[order(values$kegg_result$pvalue), ], 
                         min(input$show_category, nrow(values$kegg_result)))
        
        if (nrow(kegg_sub) == 0) {
          plot(0, 0, type = "n", xlab = "", ylab = "", axes = FALSE,
               main = "没有显著富集的KEGG通路")
          text(0, 0, "请调整p-value阈值或检查输入基因", cex = 1.2)
          return()
        }
        
        # 准备圈图数据
        kegg_data <- data.frame(
          Category = rep("KEGG", nrow(kegg_sub)),
          ID = kegg_sub$ID,
          Term = kegg_sub$Description,
          Genes = kegg_sub$geneID,
          adj_pval = kegg_sub$pvalue
        )
        
        # 准备基因列表 - 需要从deg_data中提取
        if (!is.null(input$gene_col) && !is.null(input$logfc_col)) {
          # 读取deg文件
          ext <- tools::file_ext(input$deg_file$name)
          if (ext %in% c("csv", "txt")) {
            sep <- switch(input$sep,
                          "," = ",",
                          ";" = ";",
                          "\t" = "\t")
            deg_data_full <- read.csv(input$deg_file$datapath, 
                                      header = input$has_header,
                                      sep = sep,
                                      stringsAsFactors = FALSE,
                                      check.names = FALSE)
          } else if (ext %in% c("xlsx", "xls")) {
            deg_data_full <- read.xlsx(input$deg_file$datapath, check.names = FALSE)
          }
          
          # 检查列名
          if (input$gene_col %in% names(deg_data_full) && 
              input$logfc_col %in% names(deg_data_full)) {
            gene_list <- data.frame(
              ID = deg_data_full[[input$gene_col]],
              logFC = deg_data_full[[input$logfc_col]]
            )
            
            # 创建圈图数据
            circle_data <- circle_dat(kegg_data, gene_list)
            
            # 生成圈图
            p <- GOCircle(
              data = circle_data,
              nsub = min(input$show_category, nrow(kegg_data)),
              rad1 = 2, rad2 = 3,
              zsc.col = c("#F8766D", 'white', '#003087'),
              lfc.col = c('#F8766D', '#003087'),
              label.size = 5,
              label.fontface = 'plain',
              table.legend = ifelse(is.null(input$kegg_table_legend), TRUE, input$kegg_table_legend)
            )
            
            values$kegg_plot_obj <- p
            return(p)
          }
        }
      }
      
      # 如果圈图条件不满足，绘制简单图表
      kegg_sub <- head(values$kegg_result[order(values$kegg_result$pvalue), ], 
                       min(input$show_category, nrow(values$kegg_result)))
      
      if (nrow(kegg_sub) == 0) {
        plot(0, 0, type = "n", xlab = "", ylab = "", axes = FALSE,
             main = "没有显著富集的KEGG通路")
        text(0, 0, "请调整p-value阈值或检查输入基因", cex = 1.2)
        return()
      }
      
      if (input$kegg_plot_type == "柱状图") {
        # 柱状图
        kegg_sub$log10_pvalue <- -log10(kegg_sub$pvalue)
        
        # 确保Description是字符型
        kegg_sub$Description <- as.character(kegg_sub$Description)
        
        p <- ggplot(kegg_sub, aes(x = reorder(Description, log10_pvalue), 
                                  y = log10_pvalue)) +
          geom_bar(stat = "identity", fill = "steelblue", alpha = 0.8) +
          coord_flip() +
          labs(x = "", y = "-log10(p-value)", 
               title = "KEGG富集分析结果") +
          theme_minimal() +
          theme(axis.text = element_text(size = 10),
                plot.title = element_text(hjust = 0.5, size = 16))
        
      } else {
        # 气泡图
        # 确保Description是字符型
        kegg_sub$Description <- as.character(kegg_sub$Description)
        
        p <- ggplot(kegg_sub, aes(x = if("richFactor" %in% names(kegg_sub)) richFactor else Count, 
                                  y = reorder(Description, pvalue))) +
          geom_point(aes(size = Count, color = -log10(pvalue))) +
          scale_color_gradient(low = "blue", high = "red", name = "-log10(p-value)") +
          scale_size_continuous(name = "基因数", range = c(3, 10)) +
          labs(x = if("richFactor" %in% names(kegg_sub)) "富集因子" else "基因数", 
               y = "", 
               title = "KEGG富集分析气泡图") +
          theme_minimal() +
          theme(axis.text = element_text(size = 10),
                plot.title = element_text(hjust = 0.5, size = 16),
                legend.position = "right")
      }
      
      values$kegg_plot_obj <- p
      p
      
    }, error = function(e) {
      plot(0, 0, type = "n", xlab = "", ylab = "", axes = FALSE,
           main = "绘图出错")
      text(0, 0, paste("错误:", e$message), cex = 1.2)
    })
  })
  
  # 下载处理
  output$download_go_table <- downloadHandler(
    filename = function() {
      paste0("GO_enrichment_", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      req(values$go_result)
      write.xlsx(values$go_result, file)
    }
  )
  
  output$download_go_csv <- downloadHandler(
    filename = function() {
      paste0("GO_enrichment_", Sys.Date(), ".csv")
    },
    content = function(file) {
      req(values$go_result)
      write.csv(values$go_result, file, row.names = FALSE)
    }
  )
  
  output$download_kegg_table <- downloadHandler(
    filename = function() {
      paste0("KEGG_enrichment_", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      req(values$kegg_result)
      write.xlsx(values$kegg_result, file)
    }
  )
  
  output$download_kegg_csv <- downloadHandler(
    filename = function() {
      paste0("KEGG_enrichment_", Sys.Date(), ".csv")
    },
    content = function(file) {
      req(values$kegg_result)
      write.csv(values$kegg_result, file, row.names = FALSE)
    }
  )
  
  output$download_go_png <- downloadHandler(
    filename = function() {
      paste0("GO_plot_", Sys.Date(), ".png")
    },
    content = function(file) {
      req(values$go_plot_obj)
      png(file, width = input$go_plot_width, height = input$go_plot_height, 
          units = "in", res = 300)
      print(values$go_plot_obj)
      dev.off()
    }
  )
  
  output$download_go_pdf <- downloadHandler(
    filename = function() {
      paste0("GO_plot_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      req(values$go_plot_obj)
      pdf(file, width = input$go_plot_width, height = input$go_plot_height)
      print(values$go_plot_obj)
      dev.off()
    }
  )
  
  output$download_kegg_png <- downloadHandler(
    filename = function() {
      paste0("KEGG_plot_", Sys.Date(), ".png")
    },
    content = function(file) {
      req(values$kegg_plot_obj)
      png(file, width = input$kegg_plot_width, height = input$kegg_plot_height, 
          units = "in", res = 300)
      print(values$kegg_plot_obj)
      dev.off()
    }
  )
  
  output$download_kegg_pdf <- downloadHandler(
    filename = function() {
      paste0("KEGG_plot_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      req(values$kegg_plot_obj)
      pdf(file, width = input$kegg_plot_width, height = input$kegg_plot_height)
      print(values$kegg_plot_obj)
      dev.off()
    }
  )
}

# 运行应用
shinyApp(ui = ui, server = server)