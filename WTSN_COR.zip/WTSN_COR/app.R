# app.R
library(shiny)
library(ggplot2)
library(ggpubr)
library(ggExtra)
library(corrplot)
library(DT)
library(shinythemes)
library(reshape2)
library(data.table)

# 设置最大上传文件大小为100MB
options(shiny.maxRequestSize = 100 * 1024^2)

# UI部分
ui <- fluidPage(
  theme = shinytheme("flatly"),
  tags$head(
    tags$style(HTML("
      .shiny-file-input-progress {
        display: none;
      }
      .progress-bar {
        height: 20px;
      }
      .loading-message {
        padding: 10px;
        margin: 10px 0;
        background-color: #f8f9fa;
        border-radius: 5px;
      }
    "))
  ),
  
  titlePanel("基因表达数据相关性分析平台"),
  sidebarLayout(
    sidebarPanel(
      width = 3,
      h4("数据上传"),
      helpText("支持上传最大100MB的CSV文件"),
      fileInput("file", "上传数据文件 (CSV格式)",
                accept = c(".csv", ".txt"),
                buttonLabel = "浏览...",
                placeholder = "选择文件"),
      
      conditionalPanel(
        condition = "input.file != null",
        div(class = "loading-message",
            textOutput("file_status")
        )
      ),
      
      radioButtons("data_type", "数据类型",
                   choices = c("基因表达谱" = "gene_expr",
                               "两组数据" = "two_groups"),
                   selected = "gene_expr"),
      
      conditionalPanel(
        condition = "input.data_type == 'gene_expr'",
        selectizeInput("genes", "选择基因:",
                       choices = NULL,
                       multiple = TRUE,
                       options = list(maxItems = 20,
                                      placeholder = '输入或选择基因名称')),
        helpText("提示：可以输入基因名称进行搜索")
      ),
      
      conditionalPanel(
        condition = "input.data_type == 'two_groups'",
        selectInput("var1", "选择第一组数据列:", 
                    choices = NULL,
                    multiple = FALSE),
        selectInput("var2", "选择第二组数据列:", 
                    choices = NULL,
                    multiple = FALSE)
      ),
      
      hr(),
      h4("分析设置"),
      selectInput("cor_method", "相关性方法:",
                  choices = c("Spearman" = "spearman",
                              "Pearson" = "pearson",
                              "Kendall" = "kendall"),
                  selected = "spearman"),
      
      # 简化的热图设置选项
      conditionalPanel(
        condition = "input.data_type == 'gene_expr' && input.genes && input.genes.length > 2",
        h5("热图设置"),
        checkboxInput("show_pvalues", "显示P值标记", value = TRUE),
        sliderInput("font_size", "字体大小:", 
                    min = 0.5, max = 2, value = 1, step = 0.1),
        selectInput("heatmap_type", "热图类型:",
                    choices = c("相关系数热图" = "correlation",
                                "P值热图" = "pvalue"),
                    selected = "correlation")
      ),
      
      conditionalPanel(
        condition = "input.data_type == 'two_groups' || (input.data_type == 'gene_expr' && input.genes && input.genes.length == 2)",
        h5("散点图设置"),
        checkboxInput("add_marginal", "添加边缘分布图", value = TRUE),
        checkboxInput("add_regression", "添加回归线", value = TRUE),
        checkboxInput("add_cor_label", "显示相关性标签", value = TRUE),
        selectInput("reg_method", "回归方法:",
                    choices = c("线性回归" = "lm",
                                "局部回归" = "loess"),
                    selected = "lm")
      ),
      
      hr(),
      h4("图形设置"),
      sliderInput("point_size", "点大小:",
                  min = 1, max = 10, value = 3, step = 0.5),
      sliderInput("plot_width", "图形宽度(像素):",
                  min = 400, max = 2000, value = 800, step = 50),
      sliderInput("plot_height", "图形高度(像素):",
                  min = 300, max = 1500, value = 600, step = 50),
      
      hr(),
      h4("下载设置"),
      radioButtons("download_format", "下载格式:",
                   choices = c("PNG" = "png", 
                               "PDF" = "pdf"),
                   selected = "png"),
      numericInput("dpi", "图片分辨率(DPI):", 
                   value = 300, min = 72, max = 600, step = 50),
      br(),
      conditionalPanel(
        condition = "input.data_type == 'two_groups' || (input.data_type == 'gene_expr' && input.genes && input.genes.length == 2)",
        div(style = "margin-top: 10px;",
            downloadButton("download_scatter", "下载散点图",
                           class = "btn-success")
        )
      ),
      conditionalPanel(
        condition = "input.data_type == 'gene_expr' && input.genes && input.genes.length > 2",
        div(style = "margin-top: 10px;",
            downloadButton("download_heatmap", "下载热图",
                           class = "btn-success")
        )
      ),
      
      hr(),
      div(style = "font-size: 12px; color: #666;",
          p("注意事项:"),
          tags$ul(
            tags$li("支持最大100MB的文件"),
            tags$li("基因表达谱：行为基因，列为样本"),
            tags$li("两组数据：列为变量，行为观测值")
          )
      )
    ),
    
    mainPanel(
      width = 9,
      tabsetPanel(
        id = "main_tabs",
        tabPanel("数据预览",
                 div(style = "margin-bottom: 10px;",
                     verbatimTextOutput("file_info")
                 ),
                 DTOutput("data_preview"),
                 hr(),
                 h4("数据统计摘要"),
                 verbatimTextOutput("data_summary")
        ),
        tabPanel("相关性分析",
                 conditionalPanel(
                   condition = "input.data_type == 'two_groups' || (input.data_type == 'gene_expr' && input.genes && input.genes.length == 2)",
                   h4("散点图"),
                   div(style = "text-align: center;",
                       plotOutput("scatter_plot", 
                                  height = "auto")
                   ),
                   hr(),
                   h4("相关性统计结果"),
                   verbatimTextOutput("cor_stats"),
                   br(),
                   h4("回归分析结果"),
                   verbatimTextOutput("regression_summary")
                 ),
                 conditionalPanel(
                   condition = "input.data_type == 'gene_expr' && input.genes && input.genes.length > 2",
                   h4("相关性热图"),
                   div(style = "text-align: center;",
                       plotOutput("heatmap_plot",
                                  height = "auto")
                   ),
                   hr(),
                   h4("相关性矩阵"),
                   DTOutput("cor_matrix"),
                   br(),
                   h4("P值矩阵"),
                   DTOutput("pvalue_matrix"),
                   br(),
                   h4("显著性标记说明"),
                   tags$ul(
                     tags$li("*** : p < 0.001"),
                     tags$li("**  : p < 0.01"),
                     tags$li("*   : p < 0.05"),
                     tags$li("ns  : p >= 0.05 (不显著)")
                   )
                 )
        ),
        tabPanel("使用说明",
                 h3("使用指南"),
                 hr(),
                 h4("1. 数据上传"),
                 p("支持上传CSV/TXT格式的文件，最大文件大小为100MB。"),
                 p("数据格式可以是："),
                 tags$ul(
                   tags$li("基因表达谱：行为基因，列为样本（推荐格式）"),
                   tags$li("两组数据：列为变量，行为观测值")
                 ),
                 h4("2. 数据类型选择"),
                 p("- 如果选择'基因表达谱'，可以在基因列表中选择2个或多个基因进行分析"),
                 p("- 如果选择'两组数据'，需要分别选择两个变量列进行相关性分析"),
                 h4("3. 分析结果"),
                 p("- 选择2个基因/变量：生成散点图，显示相关系数和P值"),
                 p("- 选择多个基因：生成相关性热图，显示相关系数矩阵和P值矩阵"),
                 h4("4. 热图设置"),
                 p("- 相关系数热图：颜色表示相关系数大小，可选择性显示P值标记"),
                 p("- P值热图：颜色表示P值大小")
        )
      )
    )
  )
)

# Server部分
server <- function(input, output, session) {
  
  # 文件状态显示
  output$file_status <- renderText({
    req(input$file)
    paste("正在处理文件:", input$file$name)
  })
  
  # 文件信息
  output$file_info <- renderText({
    req(input$file)
    paste("文件:", input$file$name, "\n",
          "大小:", round(input$file$size/1024/1024, 2), "MB\n",
          "类型:", input$file$type)
  })
  
  # 读取数据（优化大文件读取）
  data <- reactive({
    req(input$file)
    
    # 显示加载消息
    showNotification(paste("正在读取文件:", input$file$name), 
                     type = "message", duration = 5)
    
    tryCatch({
      # 根据文件大小选择读取方法
      file_size_mb <- input$file$size / 1024 / 1024
      
      if (file_size_mb > 50) {
        # 大文件使用fread
        showNotification("检测到大文件，使用快速读取模式...", 
                         type = "warning", duration = 3)
        
        # 读取数据
        df <- fread(input$file$datapath, 
                    header = TRUE,
                    showProgress = TRUE)
        
        # 转换为data.frame
        df <- as.data.frame(df)
        
      } else {
        # 小文件使用read.csv
        df <- read.csv(input$file$datapath, 
                       check.names = FALSE,
                       row.names = 1)
        
        # 如果没有成功设置行名，重新读取
        if (ncol(df) == 0 || (!is.null(rownames(df)) && all(rownames(df) == as.character(1:nrow(df))))) {
          df <- read.csv(input$file$datapath, 
                         check.names = FALSE)
        }
      }
      
      # 尝试转换数值列
      for (col in colnames(df)) {
        if (!is.numeric(df[[col]])) {
          df[[col]] <- as.numeric(as.character(df[[col]]))
        }
      }
      
      # 移除全NA的列
      df <- df[, colSums(is.na(df)) < nrow(df), drop = FALSE]
      
      # 移除全NA的行
      df <- df[rowSums(is.na(df)) < ncol(df), , drop = FALSE]
      
      showNotification("文件读取完成！", type = "message", duration = 3)
      
      return(df)
      
    }, error = function(e) {
      showNotification(paste("读取文件出错:", e$message), 
                       type = "error", duration = 10)
      return(NULL)
    })
  })
  
  # 更新基因选择列表
  observe({
    req(data())
    
    if(input$data_type == "gene_expr") {
      gene_names <- tryCatch({
        # 尝试获取行名
        if (!is.null(rownames(data())) && length(rownames(data())) > 0) {
          rownames(data())
        } else {
          # 如果没有行名，使用列名
          colnames(data())
        }
      }, error = function(e) {
        colnames(data())
      })
      
      updateSelectizeInput(session, "genes",
                           choices = gene_names,
                           server = TRUE,
                           options = list(
                             maxOptions = 1000,
                             placeholder = '输入基因名称...',
                             closeAfterSelect = TRUE
                           ))
    }
  })
  
  # 更新变量选择列表
  observe({
    req(data())
    if(input$data_type == "two_groups") {
      updateSelectInput(session, "var1",
                        choices = colnames(data()))
      updateSelectInput(session, "var2",
                        choices = colnames(data()))
    }
  })
  
  # 数据预览
  output$data_preview <- renderDT({
    req(data())
    df <- data()
    
    # 限制显示行数
    display_rows <- min(50, nrow(df))
    display_cols <- min(20, ncol(df))
    
    datatable(df[1:display_rows, 1:display_cols, drop = FALSE],
              options = list(
                pageLength = 10,
                scrollX = TRUE,
                scrollY = "400px",
                dom = 'Blfrtip',
                buttons = c('copy', 'csv', 'excel'),
                lengthMenu = list(c(5, 10, 25, 50, -1), 
                                  c('5', '10', '25', '50', 'All'))
              ),
              class = 'display compact',
              caption = paste("显示前", display_rows, "行和前", 
                              display_cols, "列")
    )
  })
  
  # 数据统计摘要
  output$data_summary <- renderPrint({
    req(data())
    df <- data()
    
    cat("数据概览\n")
    cat("==========\n")
    cat(sprintf("行数: %d\n", nrow(df)))
    cat(sprintf("列数: %d\n", ncol(df)))
    cat(sprintf("缺失值数量: %d\n", sum(is.na(df))))
    
    if (ncol(df) <= 10 && nrow(df) > 0) {
      cat("\n列数据类型:\n")
      print(sapply(df, class))
    } else if (nrow(df) > 0) {
      cat("\n数据列过多，只显示数据类型统计:\n")
      print(table(sapply(df, class)))
    }
  })
  
  # 准备相关性分析数据
  analysis_data <- reactive({
    req(data())
    
    # 显示处理消息
    showNotification("正在准备分析数据...", 
                     type = "message", duration = 2)
    
    if(input$data_type == "gene_expr") {
      genes <- input$genes
      
      # 检查genes是否为空或长度小于2
      if(is.null(genes) || length(genes) < 2) {
        return(NULL)
      }
      
      # 提取选中的基因数据
      tryCatch({
        df <- data()
        
        # 检查数据格式
        if (!is.null(rownames(df)) && length(rownames(df)) > 0) {
          # 行为基因，列为样本
          if(all(genes %in% rownames(df))) {
            selected_data <- df[genes, , drop = FALSE]
            # 转置：行为样本，列为基因
            selected_data <- as.data.frame(t(selected_data))
            colnames(selected_data) <- genes
            df_result <- selected_data
          } else if(all(genes %in% colnames(df))) {
            # 列为基因，行为样本
            df_result <- df[, genes, drop = FALSE]
          } else {
            missing_genes <- setdiff(genes, c(rownames(df), colnames(df)))
            showNotification(paste("以下基因不存在:", 
                                   paste(missing_genes, collapse=", ")), 
                             type = "error")
            return(NULL)
          }
        } else {
          # 没有行名，假设列为基因
          if(all(genes %in% colnames(df))) {
            df_result <- df[, genes, drop = FALSE]
          } else {
            missing_genes <- setdiff(genes, colnames(df))
            showNotification(paste("以下基因不存在:", 
                                   paste(missing_genes, collapse=", ")), 
                             type = "error")
            return(NULL)
          }
        }
        
        # 移除有缺失值的行
        complete_cases <- complete.cases(df_result)
        if (sum(!complete_cases) > 0) {
          df_result <- df_result[complete_cases, , drop = FALSE]
          showNotification(sprintf("移除了%d行有缺失值的数据", 
                                   sum(!complete_cases)), 
                           type = "warning", duration = 3)
        }
        
        return(df_result)
      }, error = function(e) {
        showNotification(paste("提取数据出错:", e$message), 
                         type = "error")
        return(NULL)
      })
      
    } else if(input$data_type == "two_groups") {
      req(input$var1, input$var2)
      
      tryCatch({
        df <- data()
        df_result <- data.frame(
          x = df[, input$var1],
          y = df[, input$var2]
        )
        colnames(df_result) <- c(input$var1, input$var2)
        
        # 移除有缺失值的行
        complete_cases <- complete.cases(df_result)
        if (sum(!complete_cases) > 0) {
          df_result <- df_result[complete_cases, , drop = FALSE]
          showNotification(sprintf("移除了%d行有缺失值的数据", 
                                   sum(!complete_cases)), 
                           type = "warning", duration = 3)
        }
        
        return(df_result)
      }, error = function(e) {
        showNotification(paste("提取数据出错:", e$message), 
                         type = "error")
        return(NULL)
      })
    }
  })
  
  # 散点图（两个基因/变量）- 修复线性回归问题
  output$scatter_plot <- renderPlot({
    req(analysis_data())
    df <- analysis_data()
    
    if(is.null(df) || ncol(df) != 2) return(NULL)
    
    # 移除NA值
    df_clean <- df[complete.cases(df), , drop = FALSE]
    if(nrow(df_clean) < 2) {
      showNotification("数据不足，无法计算相关性", type = "warning")
      return(NULL)
    }
    
    # 计算相关性
    cor_test <- tryCatch({
      cor.test(df_clean[, 1], df_clean[, 2], 
               method = input$cor_method)
    }, error = function(e) {
      showNotification("相关性计算出错，数据可能存在问题", 
                       type = "error")
      return(NULL)
    })
    
    if(is.null(cor_test)) return(NULL)
    
    # 创建基础散点图
    p <- ggplot(df_clean, aes(x = df_clean[, 1], y = df_clean[, 2])) +
      geom_point(size = input$point_size, alpha = 0.7, color = "steelblue") +
      xlab(colnames(df_clean)[1]) +
      ylab(colnames(df_clean)[2]) +
      ggtitle(paste(colnames(df_clean)[1], "vs", colnames(df_clean)[2])) +
      theme_bw(base_size = 14) +
      theme(plot.title = element_text(hjust = 0.5, face = "bold"),
            panel.grid.minor = element_blank())
    
    # 添加回归线 - 修复线性回归绘制问题
    if(isTRUE(input$add_regression)) {
      if(input$reg_method == "lm") {
        # 使用线性回归，确保有足够的数据点
        if(nrow(df_clean) >= 2) {
          p <- p + geom_smooth(method = "lm", formula = y ~ x, 
                               se = TRUE, color = "red", alpha = 0.2)
        }
      } else {
        # 使用局部回归
        if(nrow(df_clean) >= 3) {
          p <- p + geom_smooth(method = "loess", formula = y ~ x, 
                               se = TRUE, color = "red", alpha = 0.2)
        }
      }
    }
    
    # 添加相关性标签
    if(isTRUE(input$add_cor_label)) {
      # 创建自定义标签
      p_value_text <- ifelse(cor_test$p.value < 0.001, "< 0.001", 
                             sprintf("%.3f", cor_test$p.value))
      
      cor_label <- sprintf("%s\nCor = %.3f\nP = %s\nn = %d", 
                           toupper(input$cor_method),
                           cor_test$estimate, 
                           p_value_text,
                           nrow(df_clean))
      
      # 计算坐标位置
      x_range <- range(df_clean[, 1], na.rm = TRUE)
      y_range <- range(df_clean[, 2], na.rm = TRUE)
      
      p <- p + annotate("text",
                        x = x_range[1] + 0.05 * diff(x_range),
                        y = y_range[2] - 0.05 * diff(y_range),
                        label = cor_label,
                        size = 5,
                        hjust = 0,
                        vjust = 1,
                        color = "darkblue",
                        fontface = "bold")
    }
    
    # 添加边缘分布图
    if(isTRUE(input$add_marginal) && nrow(df_clean) >= 5) {
      p <- ggMarginal(p, type = "density",
                      fill = "lightblue", alpha = 0.7)
    }
    
    return(p)
  }, width = function() input$plot_width,
  height = function() input$plot_height)
  
  # 相关性统计结果
  output$cor_stats <- renderPrint({
    req(analysis_data())
    df <- analysis_data()
    
    if(is.null(df) || ncol(df) != 2) {
      cat("等待有效数据...\n")
      return(NULL)
    }
    
    # 移除NA值
    df_clean <- df[complete.cases(df), , drop = FALSE]
    if(nrow(df_clean) < 2) {
      cat("数据不足，无法计算相关性\n")
      return(NULL)
    }
    
    cor_result <- cor.test(df_clean[, 1], df_clean[, 2], 
                           method = input$cor_method)
    
    cat("相关性分析结果\n")
    cat("================\n")
    cat(sprintf("方法: %s\n", toupper(input$cor_method)))
    cat(sprintf("变量1: %s\n", colnames(df_clean)[1]))
    cat(sprintf("变量2: %s\n", colnames(df_clean)[2]))
    cat(sprintf("相关系数: %.4f\n", cor_result$estimate))
    cat(sprintf("P值: %.4e\n", cor_result$p.value))
    cat(sprintf("显著性: %s\n", 
                ifelse(cor_result$p.value < 0.001, "***",
                       ifelse(cor_result$p.value < 0.01, "**",
                              ifelse(cor_result$p.value < 0.05, "*", "不显著")))))
    if(!is.null(cor_result$conf.int)) {
      cat(sprintf("95%% 置信区间: [%.4f, %.4f]\n", 
                  cor_result$conf.int[1], 
                  cor_result$conf.int[2]))
    }
    cat(sprintf("样本量: %d\n", nrow(df_clean)))
    if(!is.null(cor_result$parameter)) {
      cat(sprintf("自由度: %d\n", cor_result$parameter))
    }
  })
  
  # 回归分析结果
  output$regression_summary <- renderPrint({
    req(analysis_data())
    df <- analysis_data()
    
    if(is.null(df) || ncol(df) != 2) return(NULL)
    
    # 移除NA值
    df_clean <- df[complete.cases(df), , drop = FALSE]
    if(nrow(df_clean) < 2) {
      cat("数据不足，无法进行回归分析\n")
      return(NULL)
    }
    
    # 执行线性回归
    lm_model <- lm(df_clean[, 2] ~ df_clean[, 1])
    
    cat("线性回归分析结果\n")
    cat("=================\n")
    print(summary(lm_model))
    
    cat("\n回归方程:\n")
    cat(sprintf("Y = %.4f + %.4f * X\n", 
                coef(lm_model)[1], coef(lm_model)[2]))
  })
  
  # 热图（多个基因）- 简化版本
  output$heatmap_plot <- renderPlot({
    req(analysis_data())
    df <- analysis_data()
    
    if(is.null(df) || ncol(df) < 3) {
      return(NULL)
    }
    
    # 限制基因数量以避免计算过载
    if(ncol(df) > 20) {
      showNotification("基因数量超过20个，只显示前20个", 
                       type = "warning")
      df <- df[, 1:20, drop = FALSE]
    }
    
    # 移除有缺失值的行
    df_complete <- df[complete.cases(df), , drop = FALSE]
    if(nrow(df_complete) < 3) {
      showNotification("数据不足，无法计算相关性", type = "warning")
      return(NULL)
    }
    
    # 计算相关性矩阵
    cor_matrix <- tryCatch({
      cor_result <- cor(df_complete, method = input$cor_method, use = "pairwise.complete.obs")
      # 替换NA值为0
      cor_result[is.na(cor_result)] <- 0
      cor_result
    }, error = function(e) {
      showNotification("相关性计算出错", type = "error")
      return(NULL)
    })
    
    if(is.null(cor_matrix)) return(NULL)
    
    # 计算P值矩阵
    n_genes <- ncol(df_complete)
    p_matrix <- matrix(1, nrow = n_genes, ncol = n_genes)
    
    for(i in 1:n_genes) {
      for(j in 1:n_genes) {
        if(i != j) {
          test_result <- tryCatch({
            cor.test(df_complete[, i], df_complete[, j], 
                     method = input$cor_method,
                     exact = FALSE)
          }, error = function(e) NULL)
          
          if(!is.null(test_result)) {
            p_matrix[i, j] <- test_result$p.value
          }
        }
      }
    }
    
    # 确保p_matrix中没有NA值
    p_matrix[is.na(p_matrix)] <- 1
    
    rownames(p_matrix) <- colnames(p_matrix) <- colnames(df_complete)
    
    # 获取热图类型
    heatmap_type <- input$heatmap_type
    if(is.null(heatmap_type)) heatmap_type <- "correlation"
    
    show_pvalues <- isTRUE(input$show_pvalues)
    
    # 设置图形参数
    par(mar = c(0, 0, 3, 0))
    
    if(heatmap_type == "correlation") {
      # 相关系数热图
      col <- colorRampPalette(c("blue", "white", "red"))(100)
      
      # 绘制相关系数热图
      corrplot(cor_matrix,
               method = "color",
               type = "full",
               tl.col = "black",
               tl.cex = 0.8 * input$font_size,
               cl.cex = 0.8 * input$font_size,
               col = col,
               diag = TRUE,
               is.corr = TRUE,
               mar = c(0, 0, 0, 0))
      
      # 如果需要显示P值标记
      if(show_pvalues) {
        # 添加显著性标记
        for(i in 1:n_genes) {
          for(j in 1:n_genes) {
            if(i != j && !is.na(p_matrix[i, j])) {
              if(p_matrix[i, j] < 0.001) {
                text(j, i, "***", 
                     cex = 1.2 * input$font_size, 
                     col = "white", font = 2)
              } else if(p_matrix[i, j] < 0.01) {
                text(j, i, "**", 
                     cex = 1.2 * input$font_size, 
                     col = "white", font = 2)
              } else if(p_matrix[i, j] < 0.05) {
                text(j, i, "*", 
                     cex = 1.2 * input$font_size, 
                     col = "white", font = 2)
              }
            }
          }
        }
      }
      
      title(paste("基因表达相关性热图 (", 
                  toupper(input$cor_method), ")", sep = ""), 
            line = 1)
      
    } else {
      # P值热图
      # 将P值转换为-log10(P值)，使小P值显示为深色
      log_p_matrix <- -log10(p_matrix + 1e-10)  # 加上小值避免log10(0)
      diag(log_p_matrix) <- 0  # 对角线设置为0
      
      # 设置颜色：深色表示小P值（高显著性）
      col <- colorRampPalette(c("white", "yellow", "red", "darkred"))(100)
      
      # 绘制P值热图
      corrplot(log_p_matrix,
               method = "color",
               type = "full",
               tl.col = "black",
               tl.cex = 0.8 * input$font_size,
               cl.cex = 0.8 * input$font_size,
               col = col,
               is.corr = FALSE,
               mar = c(0, 0, 0, 0))
      
      title(paste("基因表达P值热图 (-log10(P), ", 
                  toupper(input$cor_method), ")", sep = ""), 
            line = 1)
    }
    
  }, width = function() min(input$plot_width, 1000),
  height = function() min(input$plot_height, 800))
  
  # 相关性矩阵表格
  output$cor_matrix <- renderDT({
    req(analysis_data())
    df <- analysis_data()
    
    if(is.null(df) || ncol(df) < 3) return(NULL)
    
    # 移除有缺失值的行
    df_complete <- df[complete.cases(df), , drop = FALSE]
    if(nrow(df_complete) < 3) return(NULL)
    
    cor_matrix <- cor(df_complete, method = input$cor_method, use = "pairwise.complete.obs")
    cor_matrix[is.na(cor_matrix)] <- 0
    
    datatable(round(cor_matrix, 4),
              options = list(
                pageLength = 10,
                scrollX = TRUE,
                dom = 'Bfrtip',
                buttons = c('copy', 'csv')
              ),
              caption = "相关性矩阵")
  })
  
  # P值矩阵表格
  output$pvalue_matrix <- renderDT({
    req(analysis_data())
    df <- analysis_data()
    
    if(is.null(df) || ncol(df) < 3) return(NULL)
    
    # 移除有缺失值的行
    df_complete <- df[complete.cases(df), , drop = FALSE]
    if(nrow(df_complete) < 3) return(NULL)
    
    # 计算P值矩阵
    n_genes <- ncol(df_complete)
    p_matrix <- matrix(NA, nrow = n_genes, ncol = n_genes)
    
    for(i in 1:n_genes) {
      for(j in 1:n_genes) {
        if(i != j) {
          test_result <- tryCatch({
            cor.test(df_complete[, i], df_complete[, j], 
                     method = input$cor_method,
                     exact = FALSE)
          }, error = function(e) NULL)
          
          if(!is.null(test_result)) {
            p_matrix[i, j] <- test_result$p.value
          }
        }
      }
    }
    
    p_matrix[is.na(p_matrix)] <- 1
    rownames(p_matrix) <- colnames(p_matrix) <- colnames(df_complete)
    
    # 格式化P值显示
    p_matrix_formatted <- apply(p_matrix, 2, function(x) {
      sapply(x, function(p) {
        if(is.na(p)) return("")
        if(p < 0.001) return("< 0.001***")
        if(p < 0.01) return(sprintf("%.3f**", p))
        if(p < 0.05) return(sprintf("%.3f*", p))
        return(sprintf("%.3f", p))
      })
    })
    
    datatable(p_matrix_formatted,
              options = list(
                pageLength = 10,
                scrollX = TRUE,
                dom = 'Bfrtip',
                buttons = c('copy', 'csv')
              ),
              caption = "P值矩阵 (* p<0.05, ** p<0.01, *** p<0.001)")
  })
  
  # 下载散点图
  output$download_scatter <- downloadHandler(
    filename = function() {
      paste("scatter_plot_", Sys.Date(), ".", input$download_format, sep = "")
    },
    content = function(file) {
      req(analysis_data())
      df <- analysis_data()
      
      if(is.null(df) || ncol(df) != 2) {
        showNotification("没有有效数据可下载", type = "error")
        return()
      }
      
      # 移除NA值
      df_clean <- df[complete.cases(df), , drop = FALSE]
      if(nrow(df_clean) < 2) {
        showNotification("数据不足，无法生成图形", type = "warning")
        return()
      }
      
      # 创建图形
      p <- ggplot(df_clean, aes(x = df_clean[, 1], y = df_clean[, 2])) +
        geom_point(size = 3, alpha = 0.7, color = "steelblue") +
        xlab(colnames(df_clean)[1]) +
        ylab(colnames(df_clean)[2]) +
        ggtitle(paste(colnames(df_clean)[1], "vs", colnames(df_clean)[2])) +
        theme_bw(base_size = 14) +
        theme(plot.title = element_text(hjust = 0.5, face = "bold"))
      
      if(isTRUE(input$add_regression)) {
        if(input$reg_method == "lm") {
          p <- p + geom_smooth(method = "lm", formula = y ~ x, 
                               se = TRUE, color = "red", alpha = 0.2)
        } else {
          p <- p + geom_smooth(method = "loess", formula = y ~ x, 
                               se = TRUE, color = "red", alpha = 0.2)
        }
      }
      
      if(isTRUE(input$add_marginal) && nrow(df_clean) >= 5) {
        p <- ggMarginal(p, type = "density",
                        fill = "lightblue", alpha = 0.7)
      }
      
      # 保存图形
      if(input$download_format == "png") {
        ggsave(file, p, 
               width = input$plot_width/100, 
               height = input$plot_height/100,
               dpi = input$dpi)
      } else {
        ggsave(file, p, 
               width = input$plot_width/100, 
               height = input$plot_height/100)
      }
    }
  )
  
  # 下载热图
  output$download_heatmap <- downloadHandler(
    filename = function() {
      paste("heatmap_", Sys.Date(), ".", input$download_format, sep = "")
    },
    content = function(file) {
      req(analysis_data())
      df <- analysis_data()
      
      if(is.null(df) || ncol(df) < 3) {
        showNotification("没有有效数据可下载", type = "error")
        return()
      }
      
      # 限制基因数量
      if(ncol(df) > 20) {
        df <- df[, 1:20, drop = FALSE]
      }
      
      # 移除有缺失值的行
      df_complete <- df[complete.cases(df), , drop = FALSE]
      if(nrow(df_complete) < 3) {
        showNotification("数据不足，无法生成热图", type = "warning")
        return()
      }
      
      # 计算相关性矩阵和P值
      cor_matrix <- cor(df_complete, method = input$cor_method, use = "pairwise.complete.obs")
      cor_matrix[is.na(cor_matrix)] <- 0
      
      n_genes <- ncol(df_complete)
      p_matrix <- matrix(1, nrow = n_genes, ncol = n_genes)
      for(i in 1:n_genes) {
        for(j in 1:n_genes) {
          if(i != j) {
            test_result <- tryCatch({
              cor.test(df_complete[, i], df_complete[, j], 
                       method = input$cor_method,
                       exact = FALSE)
            }, error = function(e) NULL)
            
            if(!is.null(test_result)) {
              p_matrix[i, j] <- test_result$p.value
            }
          }
        }
      }
      
      p_matrix[is.na(p_matrix)] <- 1
      rownames(p_matrix) <- colnames(p_matrix) <- colnames(df_complete)
      
      # 获取热图类型
      heatmap_type <- input$heatmap_type
      if(is.null(heatmap_type)) heatmap_type <- "correlation"
      
      show_pvalues <- isTRUE(input$show_pvalues)
      
      # 保存图形
      if(input$download_format == "png") {
        png(file, 
            width = input$plot_width, 
            height = input$plot_height,
            units = "px", res = input$dpi/72*96)
      } else {
        pdf(file, 
            width = input$plot_width/100, 
            height = input$plot_height/100)
      }
      
      # 设置图形参数
      par(mar = c(0, 0, 3, 0))
      
      if(heatmap_type == "correlation") {
        # 相关系数热图
        col <- colorRampPalette(c("blue", "white", "red"))(100)
        
        # 绘制相关系数热图
        corrplot(cor_matrix,
                 method = "color",
                 type = "full",
                 tl.col = "black",
                 tl.cex = 0.8 * input$font_size,
                 cl.cex = 0.8 * input$font_size,
                 col = col,
                 diag = TRUE,
                 is.corr = TRUE,
                 mar = c(0, 0, 0, 0))
        
        # 如果需要显示P值标记
        if(show_pvalues) {
          # 添加显著性标记
          for(i in 1:n_genes) {
            for(j in 1:n_genes) {
              if(i != j && !is.na(p_matrix[i, j])) {
                if(p_matrix[i, j] < 0.001) {
                  text(j, i, "***", 
                       cex = 1.2 * input$font_size, 
                       col = "white", font = 2)
                } else if(p_matrix[i, j] < 0.01) {
                  text(j, i, "**", 
                       cex = 1.2 * input$font_size, 
                       col = "white", font = 2)
                } else if(p_matrix[i, j] < 0.05) {
                  text(j, i, "*", 
                       cex = 1.2 * input$font_size, 
                       col = "white", font = 2)
                }
              }
            }
          }
        }
        
        title(paste("基因表达相关性热图 (", 
                    toupper(input$cor_method), ")", sep = ""), 
              line = 1)
        
      } else {
        # P值热图
        # 将P值转换为-log10(P值)，使小P值显示为深色
        log_p_matrix <- -log10(p_matrix + 1e-10)  # 加上小值避免log10(0)
        diag(log_p_matrix) <- 0  # 对角线设置为0
        
        # 设置颜色：深色表示小P值（高显著性）
        col <- colorRampPalette(c("white", "yellow", "red", "darkred"))(100)
        
        # 绘制P值热图
        corrplot(log_p_matrix,
                 method = "color",
                 type = "full",
                 tl.col = "black",
                 tl.cex = 0.8 * input$font_size,
                 cl.cex = 0.8 * input$font_size,
                 col = col,
                 is.corr = FALSE,
                 mar = c(0, 0, 0, 0))
        
        title(paste("基因表达P值热图 (-log10(P), ", 
                    toupper(input$cor_method), ")", sep = ""), 
              line = 1)
      }
      
      dev.off()
    }
  )
}

# 运行应用
shinyApp(ui = ui, server = server)