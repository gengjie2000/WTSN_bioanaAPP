# app.R - 基于本地ensembl.Rdata的基因染色体定位分析平台 (修正版)

library(shiny)
library(RCircos)
library(dplyr)
library(DT)

# 定义UI界面
ui <- fluidPage(
  titlePanel("基因染色体定位分析平台 (本地数据库版)"),
  tags$style(HTML("
    .btn-block {
      width: 100%;
    }
    .well {
      background-color: #f8f9fa;
      border-radius: 10px;
      padding: 15px;
    }
    .shiny-output-error {
      color: #dc3545;
      font-weight: bold;
    }
  ")),
  sidebarLayout(
    sidebarPanel(
      width = 3,
      h4("输入设置"),
      textAreaInput(
        "gene_input",
        label = "输入基因名称 (每行一个或用逗号分隔)",
        value = "TP53, BRCA1, EGFR, MYC, KRAS",
        rows = 8,
        placeholder = "请输入基因名称，例如：TP53, BRCA1"
      ),
      
      br(),
      h4("绘图参数"),
      numericInput(
        "text_size",
        label = "文本大小",
        value = 3,
        min = 0.5,
        max = 3,
        step = 0.1
      ),
      numericInput(
        "track_num",
        label = "轨道位置",
        value = 1,
        min = 0.5,
        max = 5,
        step = 0.1
      ),
      numericInput(
        "plot_width",
        label = "图片宽度 (英寸)",
        value = 10,
        min = 5,
        max = 20,
        step = 0.5
      ),
      numericInput(
        "plot_height",
        label = "图片高度 (英寸)",
        value = 10,
        min = 5,
        max = 20,
        step = 0.5
      ),
      
      br(),
      actionButton(
        "submit",
        "开始分析",
        icon = icon("play"),
        class = "btn-primary btn-block"
      ),
      
      br(), br(),
      h4("下载设置"),
      textInput("png_filename", "PNG文件名", value = "gene_chromosome_plot.png"),
      textInput("pdf_filename", "PDF文件名", value = "gene_chromosome_plot.pdf"),
      fluidRow(
        column(6, downloadButton("download_png", "下载PNG", class = "btn-success")),
        column(6, downloadButton("download_pdf", "下载PDF", class = "btn-danger"))
      ),
      
      br(), br(),
      h4("状态"),
      verbatimTextOutput("status_info"),
      
      br(),
      h5("说明"),
      tags$ul(
        tags$li("使用本地Ensembl数据库查询"),
        tags$li("支持标准染色体(1-22, X, Y, MT)"),
        tags$li("自动过滤无效基因")
      )
    ),
    mainPanel(
      width = 9,
      tabsetPanel(
        type = "tabs",
        tabPanel(
          "数据表格",
          br(),
          fluidRow(
            column(12,
                   div(class = "well",
                       h5("基因定位数据"),
                       DTOutput("gene_table")
                   )
            )
          ),
          br(),
          fluidRow(
            # column(6,
            #        div(class = "well",
            #            h5("数据摘要"),
            #            verbatimTextOutput("data_summary")
            #        )
            # ),
            column(12,
                   div(class = "well",
                       h5("基因统计"),
                       plotOutput("gene_stats", height = "200px")
                   )
            )
          )
        ),
        tabPanel(
          "染色体圈图",
          br(),
          fluidRow(
            column(12,
                   div(class = "well",
                       plotOutput("circos_plot", height = "800px")
                   )
            )
          ),
          br(),
          fluidRow(
            column(6,
                   div(class = "well",
                       h4("图例说明"),
                       tags$ul(
                         tags$li("红色线条：基因在染色体上的位置"),
                         tags$li("黑色标签：基因名称"),
                         tags$li("外层：染色体条带"),
                         tags$li("内层：基因定位")
                       )
                   )
            ),
            column(6,
                   div(class = "well",
                       h4("染色体覆盖"),
                       plotOutput("chromosome_coverage", height = "200px")
                   )
            )
          )
        ),
        tabPanel(
          "使用说明",
          br(),
          div(class = "well",
              h3("使用指南"),
              tags$ol(
                tags$li("在左侧面板输入基因名称（每行一个或用逗号分隔）"),
                tags$li("调整绘图参数（可选）"),
                tags$li("点击'开始分析'按钮"),
                tags$li("在'数据表格'标签页查看基因位置信息"),
                tags$li("在'染色体圈图'标签页查看可视化结果"),
                tags$li("点击下载按钮保存PNG或PDF格式图片")
              ),
              br(),
              h3("示例基因"),
              code("TP53, BRCA1, EGFR, MYC, KRAS, APC, RB1, PTEN, VHL, NF1"),
              br(), br(),
              h3("注意事项"),
              tags$ul(
                tags$li("应用使用本地Ensembl数据库，无需网络连接"),
                tags$li("只显示标准染色体(1-22, X, Y, MT)"),
                tags$li("未找到的基因会被自动过滤"),
                tags$li("建议一次不要查询超过100个基因")
              )
          )
        )
      )
    )
  )
)

# 定义服务器逻辑
server <- function(input, output, session) {
  
  # 自定义通知函数 - 解决type参数错误问题
  show_status_message <- function(message, type = "default", duration = 5) {
    # 确保type是有效值
    valid_types <- c("default", "message", "warning", "error")
    if (!type %in% valid_types) {
      type <- "default"
    }
    showNotification(message, type = type, duration = duration)
  }
  
  # 加载本地Ensembl数据库
  ensembl_data <- reactive({
    # 检查ensembl.Rdata文件是否存在
    if (!file.exists("ensembl.Rdata")) {
      show_status_message("错误: ensembl.Rdata文件不存在！", "error", 10)
      return(NULL)
    }
    
    # 加载ensembl对象
    load("ensembl.Rdata")
    
    # 返回ensembl对象
    return(ensembl)
  })
  
  # 响应式数据：基因位置信息
  gene_data <- eventReactive(input$submit, {
    req(input$gene_input)
    
    # 显示等待消息 - 使用正确的type参数
    show_status_message("正在查询基因位置信息...", "default", NULL)
    
    tryCatch({
      # 清理输入并转换为基因列表
      genes <- input$gene_input %>%
        strsplit("[,\n]") %>%
        unlist() %>%
        trimws() %>%
        .[. != ""] %>%
        unique()
      
      # 检查是否有输入
      validate(
        need(length(genes) > 0, "请输入至少一个基因名称")
      )
      
      # 获取本地ensembl对象
      ensembl <- ensembl_data()
      if (is.null(ensembl)) {
        return(NULL)
      }
      
      # 查询基因位置信息
      gene_info <- biomaRt::getBM(
        attributes = c(
          "chromosome_name", 
          "start_position", 
          "end_position", 
          "external_gene_name"
        ),
        filters = "external_gene_name",
        values = genes,
        mart = ensembl
      )
      
      # 检查是否找到数据
      if (nrow(gene_info) == 0) {
        not_found <- paste(setdiff(genes, gene_info$Gene), collapse = ", ")
        show_status_message(
          paste("未找到任何基因的染色体位置信息。\n",
                "请检查基因名称是否正确。"),
          "error",
          10
        )
        return(NULL)
      }
      
      # 重命名列
      colnames(gene_info) <- c("Chromosome", "Start", "End", "Gene")
      
      # 添加chr前缀
      gene_info$Chromosome <- paste0("chr", gene_info$Chromosome)
      
      # 过滤有效染色体
      valid_chroms <- paste0("chr", c(1:22, "X", "Y", "MT"))
      gene_info <- gene_info[gene_info$Chromosome %in% valid_chroms, ]
      
      # 再次检查过滤后是否有数据
      if (nrow(gene_info) == 0) {
        show_status_message(
          "找到的基因都不在标准染色体上。",
          "warning",
          10
        )
        return(NULL)
      }
      
      # 显示成功消息
      show_status_message(
        paste("成功找到", nrow(gene_info), "个基因的位置信息"),
        "default",
        5
      )
      
      # 计算基因长度
      gene_info$Length <- gene_info$End - gene_info$Start
      
      # 排序
      gene_info <- gene_info[order(gene_info$Chromosome, gene_info$Start), ]
      
      gene_info
      
    }, error = function(e) {
      # 显示错误消息
      show_status_message(paste("查询出错:", e$message), "error", 10)
      return(NULL)
    })
  })
  
  # 输出状态信息
  output$status_info <- renderText({
    if (!file.exists("ensembl.Rdata")) {
      return("状态: ensembl.Rdata文件未找到\n请确保文件在当前目录")
    } else {
      tryCatch({
        load("ensembl.Rdata")
        "状态: 本地数据库已加载\n就绪"
      }, error = function(e) {
        paste("状态: 数据库加载失败\n错误:", e$message)
      })
    }
  })
  
  # 输出数据表格
  output$gene_table <- renderDT({
    data <- gene_data()
    req(data)
    
    datatable(
      data %>%
        select(Gene, Chromosome, Start, End, Length) %>%
        mutate(Length = format(Length, big.mark = ",")),
      options = list(
        pageLength = 10,
        scrollX = TRUE,
        dom = 'Bfrtip',
        buttons = list(
          list(extend = 'copy', title = NULL),
          list(extend = 'csv', title = "基因染色体定位数据"),
          list(extend = 'excel', title = "基因染色体定位数据")
        )
      ),
      rownames = FALSE,
      class = 'display compact stripe',
      caption = "基因染色体定位数据表"
    ) %>%
      formatStyle(
        'Chromosome',
        backgroundColor = styleEqual(
          unique(data$Chromosome),
          colorRampPalette(c("#e3f2fd", "#bbdefb"))(length(unique(data$Chromosome)))
        )
      )
  })
  
  # 输出数据摘要
  output$data_summary <- renderText({
    data <- gene_data()
    req(data)
    
    genes_found <- length(unique(data$Gene))
    genes_input <- length(strsplit(input$gene_input, "[,\n]")[[1]] %>% 
                            trimws() %>% .[. != ""])
    
    paste(
      "输入基因数量: ", genes_input, "\n",
      "成功定位基因: ", genes_found, "\n",
      "缺失基因数量: ", genes_input - genes_found, "\n",
      "覆盖染色体数: ", length(unique(data$Chromosome)), "\n",
      "染色体列表: ", paste(sort(unique(data$Chromosome)), collapse = ", "), "\n",
      "最小基因长度: ", format(min(data$Length), big.mark = ","), "\n",
      "最大基因长度: ", format(max(data$Length), big.mark = ","), "\n",
      "平均基因长度: ", format(mean(data$Length), big.mark = ",", digits = 0)
    )
  })
  
  # 基因统计图
  output$gene_stats <- renderPlot({
    data <- gene_data()
    req(data)
    
    par(mar = c(4, 8, 2, 2))
    barplot(
      sort(table(data$Gene), decreasing = TRUE)[1:min(10, nrow(data))],
      horiz = TRUE,
      las = 1,
      col = "#4caf50",
      xlab = "出现次数",
      main = "Top 10 基因频率",
      cex.names = 0.8
    )
  })
  
  # 染色体覆盖图
  output$chromosome_coverage <- renderPlot({
    data <- gene_data()
    req(data)
    
    chrom_counts <- table(data$Chromosome)
    chrom_order <- paste0("chr", c(1:22, "X", "Y", "MT"))
    chrom_counts <- chrom_counts[intersect(chrom_order, names(chrom_counts))]
    
    if (length(chrom_counts) > 0) {
      par(mar = c(5, 4, 2, 2))
      barplot(
        chrom_counts,
        col = ifelse(names(chrom_counts) %in% c("chrX", "chrY"), "#ff9800", "#2196f3"),
        ylab = "基因数量",
        main = "各染色体基因分布",
        cex.names = 0.7
      )
    } else {
      plot(0, 0, type = "n", xlab = "", ylab = "", axes = FALSE)
      text(0, 0, "无数据", cex = 1.5)
    }
  })
  
  # 生成圈图
  generate_circos_plot <- function() {
    data <- gene_data()
    req(data)
    
    # 准备RCircos数据格式
    plot_data <- data.frame(
      Chromosome = data$Chromosome,
      chromStart = data$Start,
      chromEnd = data$End,
      Gene = data$Gene
    )
    
    # 设置RCircos参数
    data(UCSC.HG19.Human.CytoBandIdeogram)
    cyto.info <- UCSC.HG19.Human.CytoBandIdeogram
    chr.exclude <- NULL
    tracks.inside <- 10
    tracks.outside <- 0
    
    RCircos.Set.Core.Components(cyto.info, chr.exclude, tracks.inside, tracks.outside)
    
    # 调整文本大小
    rcircos.params <- RCircos.Get.Plot.Parameters()
    rcircos.params$text.size <- input$text_size
    RCircos.Reset.Plot.Parameters(rcircos.params)
    
    # 绘制图形
    RCircos.Set.Plot.Area()
    RCircos.Chromosome.Ideogram.Plot()
    
    # 绘制基因连接线和名称
    side <- "in"
    track.num <- input$track_num
    
    # 绘制连接线
    RCircos.Gene.Connector.Plot(plot_data, track.num = track.num, side = side)
    
    # 绘制基因名称
    name.col <- 4
    RCircos.Gene.Name.Plot(plot_data, name.col = name.col, 
                           track.num = track.num + 0.5, side = side)
  }
  
  # 显示交互式圈图
  output$circos_plot <- renderPlot({
    generate_circos_plot()
  }, width = function() input$plot_width * 100,
  height = function() input$plot_height * 100)
  
  # 下载PNG图片
  output$download_png <- downloadHandler(
    filename = function() {
      if (input$png_filename == "") {
        return("gene_chromosome_plot.png")
      } else {
        # 确保文件扩展名正确
        if (!grepl("\\.png$", input$png_filename, ignore.case = TRUE)) {
          return(paste0(input$png_filename, ".png"))
        }
        return(input$png_filename)
      }
    },
    content = function(file) {
      # 显示保存通知
      show_status_message("正在生成PNG图片...", "default", 2)
      
      # 设置图片参数
      width_px <- input$plot_width * 300
      height_px <- input$plot_height * 300
      
      # 保存PNG
      png(file, 
          width = width_px, 
          height = height_px, 
          res = 300,
          bg = "white")
      generate_circos_plot()
      dev.off()
      
      # 显示成功通知
      show_status_message("PNG图片已保存", "default", 3)
    }
  )
  
  # 下载PDF图片
  output$download_pdf <- downloadHandler(
    filename = function() {
      if (input$pdf_filename == "") {
        return("gene_chromosome_plot.pdf")
      } else {
        # 确保文件扩展名正确
        if (!grepl("\\.pdf$", input$pdf_filename, ignore.case = TRUE)) {
          return(paste0(input$pdf_filename, ".pdf"))
        }
        return(input$pdf_filename)
      }
    },
    content = function(file) {
      # 显示保存通知
      show_status_message("正在生成PDF图片...", "default", 2)
      
      # 保存PDF
      pdf(file, 
          width = input$plot_width, 
          height = input$plot_height,
          bg = "white")
      generate_circos_plot()
      dev.off()
      
      # 显示成功通知
      show_status_message("PDF图片已保存", "default", 3)
    }
  )
}

# 运行应用
shinyApp(ui = ui, server = server)