# app.R

library(shiny)
library(shinythemes)
library(DT)
library(tidyverse)
library(data.table)
library(GSVA)
library(ComplexHeatmap)
library(ggpubr)
library(corrplot)

# 设置最大上传文件大小为100MB
options(shiny.maxRequestSize = 100 * 1024^2)
# 预读取cellMarker数据
cellMarker <- data.table::fread("cellMarker.csv", data.table = FALSE)

# 处理cellMarker数据
cellMarker$`Cell type` <- gsub("cell", "cells", cellMarker$`Cell type`)
colnames(cellMarker)[2] <- "celltype"
type <- split(cellMarker, cellMarker$celltype)
cellMarker_list <- lapply(type, function(x) {
  unique(x$Metagene)
})

# UI界面
ui <- fluidPage(
  theme = shinytheme("flatly"),
  
  titlePanel("免疫细胞浸润分析系统"),
  sidebarLayout(
    sidebarPanel(
      width = 3,
      h4("数据上传"),
      
      # 上传表达数据
      fileInput("expr_file", "上传表达数据文件 (CSV/TXT)",
                accept = c(".csv", ".txt", ".tsv"),
                placeholder = "第一列为基因名"),
      
      # 上传分组数据
      fileInput("group_file", "上传分组数据文件 (CSV/TXT)",
                accept = c(".csv", ".txt", ".tsv"),
                placeholder = "第一列样本名，第二列分组"),
      
      # # 可选：上传hub基因列表
      # fileInput("hubgene_file", "上传Hub基因列表 (可选)",
      #           accept = c(".csv", ".txt", ".tsv"),
      #           placeholder = "单列基因名"),
      
      # 分析参数
      h4("分析参数"),
      selectInput("gsva_method", "GSVA方法",
                  choices = c("ssgsea", "gsva", "zscore", "plage"),
                  selected = "ssgsea"),
      
      # 颜色设置
      textInput("color_group1", "组1颜色", value = "#B72230"),
      textInput("color_group2", "组2颜色", value = "#104680"),
      
      # 开始分析按钮
      actionButton("analyze", "开始分析", 
                   class = "btn-primary btn-block"),
      
      br(),
      h4("结果下载"),
      downloadButton("dl_all", "下载所有结果(ZIP)", 
                     class = "btn-success btn-block"),
      
      br(),
      hr(),
      h5("使用说明"),
      tags$ul(
        tags$li("表达数据：基因名 × 样本矩阵"),
        tags$li("分组数据：两列，样本名和分组"),
        tags$li("支持FPKM/TPM/芯片数据")
      )
    ),
    
    mainPanel(
      width = 9,
      tabsetPanel(
        tabPanel("数据预览",
                 h3("表达数据预览"),
                 DTOutput("expr_preview"),
                 br(),
                 h3("分组数据预览"),
                 DTOutput("group_preview"),
                 br(),
                 h3("cellMarker数据预览"),
                 DTOutput("cellmarker_preview")
        ),
        
        tabPanel("GSVA结果",
                 h3("免疫细胞浸润得分"),
                 DTOutput("gsva_table"),
                 downloadButton("dl_gsva", "下载CSV")
        ),
        
        tabPanel("热图可视化",
                 h3("免疫细胞浸润热图"),
                 plotOutput("heatmap_plot", height = "800px"),
                 br(),
                 fluidRow(
                   column(6,
                          numericInput("heatmap_height", "高度(英寸)", 
                                       value = 8, min = 4, max = 20),
                          numericInput("heatmap_width", "宽度(英寸)", 
                                       value = 10, min = 4, max = 20)
                   ),
                   column(6,
                          downloadButton("dl_heatmap_png", "下载PNG"),
                          downloadButton("dl_heatmap_pdf", "下载PDF")
                   )
                 )
        ),
        
        tabPanel("组间差异",
                 h3("免疫细胞浸润差异箱线图"),
                 plotOutput("boxplot_plot", height = "600px"),
                 br(),
                 h4("差异分析结果"),
                 DTOutput("diff_table"),
                 fluidRow(
                   column(6,
                          numericInput("box_height", "高度(英寸)", 
                                       value = 8, min = 4, max = 20),
                          numericInput("box_width", "宽度(英寸)", 
                                       value = 18, min = 4, max = 20)
                   ),
                   column(6,
                          downloadButton("dl_boxplot_png", "下载PNG"),
                          downloadButton("dl_boxplot_pdf", "下载PDF"),
                          downloadButton("dl_diff_csv", "下载差异结果")
                   )
                 )
        ),
        
        # tabPanel("相关性分析",
        #          conditionalPanel(
        #            condition = "input.hubgene_file != null",
        #            h3("Hub基因与免疫细胞相关性"),
        #            plotOutput("cor_plot", height = "700px"),
        #            br(),
        #            h4("相关性矩阵"),
        #            DTOutput("cor_table"),
        #            fluidRow(
        #              column(6,
        #                     numericInput("cor_height", "高度(英寸)", 
        #                                  value = 6, min = 4, max = 20),
        #                     numericInput("cor_width", "宽度(英寸)", 
        #                                  value = 8, min = 4, max = 20)
        #              ),
        #              column(6,
        #                     downloadButton("dl_cor_png", "下载PNG"),
        #                     downloadButton("dl_cor_pdf", "下载PDF"),
        #                     downloadButton("dl_cor_csv", "下载相关性矩阵")
        #              )
        #            )
        #          ),
        #          conditionalPanel(
        #            condition = "input.hubgene_file == null",
        #            h4("请上传Hub基因列表进行相关性分析")
        #          )
        # )
      )
    )
  )
)

# 服务器逻辑
server <- function(input, output, session) {
  
  # 反应值存储
  values <- reactiveValues(
    expr_data = NULL,
    group_data = NULL,
    hubgene_data = NULL,
    gsva_result = NULL,
    diff_result = NULL,
    cor_matrix = NULL,
    cor_pvalues = NULL,
    data_long = NULL,
    sig_cells = NULL
  )
  
  # 读取表达数据
  observeEvent(input$expr_file, {
    req(input$expr_file)
    tryCatch({
      if(grepl("\\.csv$", input$expr_file$name)) {
        df <- read.csv(input$expr_file$datapath, row.names = 1)
      } else {
        df <- read.table(input$expr_file$datapath, 
                         header = TRUE, row.names = 1, sep = "\t")
      }
      values$expr_data <- as.matrix(df)
    }, error = function(e) {
      showNotification(paste("读取表达数据出错:", e$message), 
                       type = "error")
    })
  })
  
  # 读取分组数据
  observeEvent(input$group_file, {
    req(input$group_file)
    tryCatch({
      if(grepl("\\.csv$", input$group_file$name)) {
        df <- read.csv(input$group_file$datapath)
      } else {
        df <- read.table(input$group_file$datapath, 
                         header = TRUE, sep = "\t")
      }
      values$group_data <- df
    }, error = function(e) {
      showNotification(paste("读取分组数据出错:", e$message), 
                       type = "error")
    })
  })
  
  # 读取hub基因数据
  observeEvent(input$hubgene_file, {
    req(input$hubgene_file)
    tryCatch({
      if(grepl("\\.csv$", input$hubgene_file$name)) {
        df <- read.csv(input$hubgene_file$datapath)
      } else {
        df <- read.table(input$hubgene_file$datapath, 
                         header = FALSE, sep = "\t")
      }
      # 假设第一列为基因名
      values$hubgene_data <- df[,1]
    }, error = function(e) {
      showNotification(paste("读取Hub基因数据出错:", e$message), 
                       type = "error")
    })
  })
  
  # 数据预览
  output$expr_preview <- renderDT({
    req(values$expr_data)
    datatable(head(as.data.frame(values$expr_data), 10),
              options = list(scrollX = TRUE))
  })
  
  output$group_preview <- renderDT({
    req(values$group_data)
    datatable(values$group_data,
              options = list(scrollX = TRUE))
  })
  
  output$cellmarker_preview <- renderDT({
    datatable(head(cellMarker, 10),
              options = list(scrollX = TRUE))
  })
  
  # 主要分析函数
  observeEvent(input$analyze, {
    req(values$expr_data, values$group_data)
    
    # 显示进度条
    withProgress(message = '正在分析中...', value = 0, {
      
      # 步骤1: GSVA分析
      incProgress(0.2, detail = "进行GSVA分析")
      
      # 确保样本顺序匹配
      expr_samples <- colnames(values$expr_data)
      group_samples <- values$group_data[,1]
      
      # 取交集
      common_samples <- intersect(expr_samples, group_samples)
      if(length(common_samples) == 0) {
        showNotification("错误：表达数据和分组数据的样本名不匹配", 
                         type = "error")
        return()
      }
      
      # 筛选数据
      expr_subset <- values$expr_data[, common_samples]
      group_subset <- values$group_data[match(common_samples, 
                                              values$group_data[,1]), ]
      
      # 步骤1: 根据选择的方法创建对应的参数对象
      gsva_param <- switch(input$gsva_method,
                           "gsva" = gsvaParam(expr_subset, cellMarker_list),
                           "ssgsea" = ssgseaParam(expr_subset, cellMarker_list),        # 最大基因集
                           "zscore" = zscoreParam(expr_subset, cellMarker_list,
                                                  min.sz = 1,
                                                  max.sz = Inf),
                           "plage" = plageParam(expr_subset, cellMarker_list,
                                                min.sz = 1,
                                                max.sz = Inf)
      )
      
      # 步骤2: 使用参数对象执行GSVA分析
      tryCatch({
        gsva_res <- gsva(gsva_param)
        values$gsva_result <- gsva_res
      }, error = function(e) {
        showNotification(paste("GSVA分析出错:", e$message), type = "error")
        return()
      })
      
      # 步骤2: 差异分析
      incProgress(0.3, detail = "进行差异分析")
      
      if(!is.null(values$gsva_result)) {
        # 准备数据
        data_t <- as.data.frame(t(values$gsva_result))
        data_t$group <- group_subset[,2]
        data_t$sample <- rownames(data_t)
        
        # 长格式转换
        data_long <- pivot_longer(data_t, 
                                  cols = -c(group, sample),
                                  names_to = "celltype",
                                  values_to = "score")
        
        # Wilcoxon检验
        stat_results <- compare_means(
          score ~ group, 
          data = data_long, 
          group.by = "celltype",
          method = "wilcox.test",
          p.adjust.method = "fdr"
        )
        values$diff_result <- stat_results
        
        # 提取显著差异的细胞类型
        sig_cells <- stat_results[stat_results$p.adj < 0.05, "celltype"]
        values$sig_cells <- sig_cells
        values$data_long <- data_long
      }
      
      # 步骤3: 相关性分析（如果上传了hub基因）
      incProgress(0.3, detail = "进行相关性分析")
      
      if(!is.null(values$hubgene_data) && !is.null(values$gsva_result)) {
        # 检查hub基因是否在表达数据中
        hub_genes <- values$hubgene_data[values$hubgene_data %in% 
                                           rownames(values$expr_data)]
        
        if(length(hub_genes) > 0) {
          # 提取hub基因表达
          expr_hub <- values$expr_data[hub_genes, common_samples, drop = FALSE]
          
          # 转置
          expr_hub_t <- t(expr_hub)
          gsva_t <- t(values$gsva_result)
          
          # 合并数据
          combined_data <- cbind(expr_hub_t, gsva_t)
          
          # 计算相关性（只计算hub基因与免疫细胞之间的相关性）
          cor_matrix <- cor(combined_data, method = "spearman")
          
          # 提取hub基因与免疫细胞的相关性子矩阵
          hub_cor <- cor_matrix[1:length(hub_genes), 
                                (length(hub_genes)+1):ncol(cor_matrix)]
          
          # 显著性检验
          p_values <- matrix(NA, nrow = nrow(hub_cor), ncol = ncol(hub_cor))
          for(i in 1:nrow(hub_cor)) {
            for(j in 1:ncol(hub_cor)) {
              test <- cor.test(combined_data[,i], 
                               combined_data[,j+length(hub_genes)],
                               method = "spearman")
              p_values[i,j] <- test$p.value
            }
          }
          rownames(p_values) <- rownames(hub_cor)
          colnames(p_values) <- colnames(hub_cor)
          
          values$cor_matrix <- hub_cor
          values$cor_pvalues <- p_values
        }
      }
      
      incProgress(0.2, detail = "完成")
    })
    
    showNotification("分析完成！", type = "default")
  })
  
  # 显示GSVA结果表格
  output$gsva_table <- renderDT({
    req(values$gsva_result)
    datatable(round(as.data.frame(values$gsva_result), 4),
              options = list(scrollX = TRUE, pageLength = 15))
  })
  
  # 绘制热图
  output$heatmap_plot <- renderPlot({
    req(values$gsva_result, values$group_data)
    
    # 准备注释
    group_anno <- values$group_data[,2]
    names(group_anno) <- values$group_data[,1]
    
    # 只保留共有的样本
    common_samples <- intersect(colnames(values$gsva_result), 
                                names(group_anno))
    if(length(common_samples) == 0) {
      return(NULL)
    }
    
    gsva_subset <- values$gsva_result[, common_samples, drop = FALSE]
    group_subset <- group_anno[common_samples]
    
    # 颜色设置
    group_colors <- c(input$color_group1, input$color_group2)
    names(group_colors) <- unique(group_subset)
    
    # 创建注释
    ha <- HeatmapAnnotation(
      Group = group_subset,
      col = list(Group = group_colors),
      annotation_legend_param = list(
        title = "Group",
        title_gp = gpar(fontsize = 12),
        labels_gp = gpar(fontsize = 10)
      )
    )
    
    # 绘制热图
    Heatmap(gsva_subset,
            name = "Score",
            top_annotation = ha,
            show_column_names = FALSE,
            column_split = group_subset,
            column_title = NULL,
            cluster_columns = FALSE,
            row_names_gp = gpar(fontsize = 10),
            column_names_gp = gpar(fontsize = 8),
            heatmap_legend_param = list(
              title_gp = gpar(fontsize = 12),
              labels_gp = gpar(fontsize = 10)
            ))
  })
  
  # 绘制箱线图
  output$boxplot_plot <- renderPlot({
    req(values$data_long, values$diff_result)
    
    ggplot(values$data_long, aes(x = celltype, y = score, fill = group)) +
      geom_boxplot(outlier.shape = NA) +
      geom_jitter(width = 0.2, alpha = 0.5, size = 1) +
      scale_fill_manual(values = c(input$color_group1, input$color_group2)) +
      labs(x = "", y = "Immune Cell Score", fill = "Group") +
      theme_bw(base_size = 14) +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        axis.text.y = element_text(size = 10),
        legend.position = "top",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()
      ) +
      stat_compare_means(
        aes(group = group),
        method = "wilcox.test",
        label = "p.signif",
        symnum.args = list(
          cutpoints = c(0, 0.001, 0.01, 0.05, 1),
          symbols = c("***", "**", "*", "ns")
        ),
        size = 4
      )
  })
  
  # 显示差异结果表格
  output$diff_table <- renderDT({
    req(values$diff_result)
    datatable(values$diff_result,
              options = list(scrollX = TRUE, pageLength = 10))
  })
  
  # 绘制相关性热图
  output$cor_plot <- renderPlot({
    req(values$cor_matrix, values$cor_pvalues)
    
    # 设置颜色
    my_colors <- colorRampPalette(c("blue", "white", "orange"))(100)
    
    # 绘制相关性热图
    corrplot(values$cor_matrix,
             p.mat = values$cor_pvalues,
             method = "square",
             insig = 'label_sig',
             sig.level = c(0.001, 0.01, 0.05),
             pch.cex = 1,
             pch.col = "black",
             is.corr = TRUE,
             tl.col = "black",
             tl.cex = 0.8,
             cl.cex = 0.8,
             col = my_colors,
             mar = c(0, 0, 2, 0),
             title = "Spearman Correlation (Hub Genes vs Immune Cells)")
  })
  
  # 显示相关性矩阵
  output$cor_table <- renderDT({
    req(values$cor_matrix)
    datatable(round(as.data.frame(values$cor_matrix), 4),
              options = list(scrollX = TRUE, pageLength = 10))
  })
  
  # 下载处理函数
  
  # 下载GSVA结果
  output$dl_gsva <- downloadHandler(
    filename = function() {
      paste0("immune_cell_scores_", Sys.Date(), ".csv")
    },
    content = function(file) {
      req(values$gsva_result)
      write.csv(values$gsva_result, file, row.names = TRUE)
    }
  )
  
  # 下载热图PNG
  output$dl_heatmap_png <- downloadHandler(
    filename = function() {
      paste0("immune_heatmap_", Sys.Date(), ".png")
    },
    content = function(file) {
      req(values$gsva_result, values$group_data)
      
      # 准备数据
      group_anno <- values$group_data[,2]
      names(group_anno) <- values$group_data[,1]
      common_samples <- intersect(colnames(values$gsva_result), names(group_anno))
      
      if(length(common_samples) == 0) {
        return()
      }
      
      gsva_subset <- values$gsva_result[, common_samples, drop = FALSE]
      group_subset <- group_anno[common_samples]
      
      group_colors <- c(input$color_group1, input$color_group2)
      names(group_colors) <- unique(group_subset)
      
      ha <- HeatmapAnnotation(
        Group = group_subset,
        col = list(Group = group_colors)
      )
      
      png(file, width = input$heatmap_width * 300, 
          height = input$heatmap_height * 300, res = 300)
      
      draw(Heatmap(gsva_subset,
                   name = "Score",
                   top_annotation = ha,
                   show_column_names = FALSE,
                   column_split = group_subset,
                   column_title = NULL,
                   cluster_columns = FALSE))
      dev.off()
    }
  )
  
  # 下载热图PDF
  output$dl_heatmap_pdf <- downloadHandler(
    filename = function() {
      paste0("immune_heatmap_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      req(values$gsva_result, values$group_data)
      
      # 准备数据
      group_anno <- values$group_data[,2]
      names(group_anno) <- values$group_data[,1]
      common_samples <- intersect(colnames(values$gsva_result), names(group_anno))
      
      if(length(common_samples) == 0) {
        return()
      }
      
      gsva_subset <- values$gsva_result[, common_samples, drop = FALSE]
      group_subset <- group_anno[common_samples]
      
      group_colors <- c(input$color_group1, input$color_group2)
      names(group_colors) <- unique(group_subset)
      
      ha <- HeatmapAnnotation(
        Group = group_subset,
        col = list(Group = group_colors)
      )
      
      pdf(file, width = input$heatmap_width, 
          height = input$heatmap_height)
      
      draw(Heatmap(gsva_subset,
                   name = "Score",
                   top_annotation = ha,
                   show_column_names = FALSE,
                   column_split = group_subset,
                   column_title = NULL,
                   cluster_columns = FALSE))
      dev.off()
    }
  )
  
  # 下载箱线图PNG
  output$dl_boxplot_png <- downloadHandler(
    filename = function() {
      paste0("immune_boxplot_", Sys.Date(), ".png")
    },
    content = function(file) {
      req(values$data_long)
      
      p <- ggplot(values$data_long, aes(x = celltype, y = score, fill = group)) +
        geom_boxplot(outlier.shape = NA) +
        geom_jitter(width = 0.2, alpha = 0.5, size = 1) +
        scale_fill_manual(values = c(input$color_group1, input$color_group2)) +
        labs(x = "", y = "Immune Cell Score", fill = "Group") +
        theme_bw(base_size = 14) +
        theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
        stat_compare_means(
          aes(group = group),
          method = "wilcox.test",
          label = "p.signif",
          symnum.args = list(
            cutpoints = c(0, 0.001, 0.01, 0.05, 1),
            symbols = c("***", "**", "*", "ns")
          )
        )
      
      ggsave(file, p, width = input$box_width, 
             height = input$box_height, dpi = 300)
    }
  )
  
  # 下载箱线图PDF
  output$dl_boxplot_pdf <- downloadHandler(
    filename = function() {
      paste0("immune_boxplot_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      req(values$data_long)
      
      p <- ggplot(values$data_long, aes(x = celltype, y = score, fill = group)) +
        geom_boxplot(outlier.shape = NA) +
        geom_jitter(width = 0.2, alpha = 0.5, size = 1) +
        scale_fill_manual(values = c(input$color_group1, input$color_group2)) +
        labs(x = "", y = "Immune Cell Score", fill = "Group") +
        theme_bw(base_size = 14) +
        theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
        stat_compare_means(
          aes(group = group),
          method = "wilcox.test",
          label = "p.signif",
          symnum.args = list(
            cutpoints = c(0, 0.001, 0.01, 0.05, 1),
            symbols = c("***", "**", "*", "ns")
          )
        )
      
      ggsave(file, p, width = input$box_width, 
             height = input$box_height)
    }
  )
  
  # 下载差异结果
  output$dl_diff_csv <- downloadHandler(
    filename = function() {
      paste0("immune_diff_results_", Sys.Date(), ".csv")
    },
    content = function(file) {
      req(values$diff_result)
      write.csv(values$diff_result, file, row.names = FALSE)
    }
  )
  
  # 下载相关性图PNG
  output$dl_cor_png <- downloadHandler(
    filename = function() {
      paste0("correlation_heatmap_", Sys.Date(), ".png")
    },
    content = function(file) {
      req(values$cor_matrix, values$cor_pvalues)
      
      png(file, width = input$cor_width * 300, 
          height = input$cor_height * 300, res = 300)
      
      my_colors <- colorRampPalette(c("blue", "white", "orange"))(100)
      
      corrplot(values$cor_matrix,
               p.mat = values$cor_pvalues,
               method = "square",
               insig = 'label_sig',
               sig.level = c(0.001, 0.01, 0.05),
               pch.cex = 1,
               pch.col = "black",
               is.corr = TRUE,
               tl.col = "black",
               tl.cex = 0.8,
               cl.cex = 0.8,
               col = my_colors,
               mar = c(0, 0, 2, 0),
               title = "Spearman Correlation (Hub Genes vs Immune Cells)")
      dev.off()
    }
  )
  
  # 下载相关性图PDF
  output$dl_cor_pdf <- downloadHandler(
    filename = function() {
      paste0("correlation_heatmap_", Sys.Date(), ".pdf")
    },
    content = function(file) {
      req(values$cor_matrix, values$cor_pvalues)
      
      pdf(file, width = input$cor_width, 
          height = input$cor_height)
      
      my_colors <- colorRampPalette(c("blue", "white", "orange"))(100)
      
      corrplot(values$cor_matrix,
               p.mat = values$cor_pvalues,
               method = "square",
               insig = 'label_sig',
               sig.level = c(0.001, 0.01, 0.05),
               pch.cex = 1,
               pch.col = "black",
               is.corr = TRUE,
               tl.col = "black",
               tl.cex = 0.8,
               cl.cex = 0.8,
               col = my_colors,
               mar = c(0, 0, 2, 0),
               title = "Spearman Correlation (Hub Genes vs Immune Cells)")
      dev.off()
    }
  )
  
  # 下载相关性矩阵
  output$dl_cor_csv <- downloadHandler(
    filename = function() {
      paste0("correlation_matrix_", Sys.Date(), ".csv")
    },
    content = function(file) {
      req(values$cor_matrix)
      write.csv(values$cor_matrix, file, row.names = TRUE)
    }
  )
  
  # 下载所有结果（ZIP包）
  output$dl_all <- downloadHandler(
    filename = function() {
      paste0("immune_analysis_results_", Sys.Date(), ".zip")
    },
    content = function(file) {
      # 创建临时目录
      temp_dir <- tempdir()
      result_dir <- file.path(temp_dir, "immune_results")
      dir.create(result_dir)
      
      # 保存各个结果文件
      req(values$gsva_result)
      
      # 1. GSVA结果
      write.csv(values$gsva_result,
                file.path(result_dir, "01_immune_cell_scores.csv"),
                row.names = TRUE)
      
      # 2. 差异分析结果
      if(!is.null(values$diff_result)) {
        write.csv(values$diff_result,
                  file.path(result_dir, "02_differential_analysis.csv"),
                  row.names = FALSE)
      }
      
      # 3. 相关性矩阵
      if(!is.null(values$cor_matrix)) {
        write.csv(values$cor_matrix,
                  file.path(result_dir, "03_correlation_matrix.csv"),
                  row.names = TRUE)
      }
      
      # 4. 生成热图
      if(!is.null(values$gsva_result)) {
        # 准备数据
        group_anno <- values$group_data[,2]
        names(group_anno) <- values$group_data[,1]
        common_samples <- intersect(colnames(values$gsva_result), names(group_anno))
        
        if(length(common_samples) > 0) {
          gsva_subset <- values$gsva_result[, common_samples, drop = FALSE]
          group_subset <- group_anno[common_samples]
          
          group_colors <- c(input$color_group1, input$color_group2)
          names(group_colors) <- unique(group_subset)
          
          ha <- HeatmapAnnotation(
            Group = group_subset,
            col = list(Group = group_colors)
          )
          
          png(file.path(result_dir, "04_immune_heatmap.png"),
              width = 10 * 300, height = 8 * 300, res = 300)
          
          draw(Heatmap(gsva_subset,
                       name = "Score",
                       top_annotation = ha,
                       show_column_names = FALSE,
                       column_split = group_subset,
                       column_title = NULL,
                       cluster_columns = FALSE))
          dev.off()
          
          # 同样生成PDF版本
          pdf(file.path(result_dir, "04_immune_heatmap.pdf"),
              width = 10, height = 8)
          draw(Heatmap(gsva_subset,
                       name = "Score",
                       top_annotation = ha,
                       show_column_names = FALSE,
                       column_split = group_subset,
                       column_title = NULL,
                       cluster_columns = FALSE))
          dev.off()
        }
      }
      
      # 5. 生成箱线图
      if(!is.null(values$data_long)) {
        p_box <- ggplot(values$data_long, aes(x = celltype, y = score, fill = group)) +
          geom_boxplot(outlier.shape = NA) +
          geom_jitter(width = 0.2, alpha = 0.5, size = 1) +
          scale_fill_manual(values = c(input$color_group1, input$color_group2)) +
          labs(x = "", y = "Immune Cell Score", fill = "Group") +
          theme_bw(base_size = 14) +
          theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
          stat_compare_means(
            aes(group = group),
            method = "wilcox.test",
            label = "p.signif"
          )
        
        ggsave(file.path(result_dir, "05_immune_boxplot.png"),
               p_box, width = 12, height = 8, dpi = 300)
        ggsave(file.path(result_dir, "05_immune_boxplot.pdf"),
               p_box, width = 12, height = 8)
      }
      
      # 6. 生成分析报告文本文件
      report_text <- paste0(
        "免疫细胞浸润分析报告\n",
        "生成时间: ", Sys.time(), "\n\n",
        "数据信息:\n",
        "- 表达数据样本数: ", ncol(values$expr_data), "\n",
        "- 基因数: ", nrow(values$expr_data), "\n",
        "- 免疫细胞类型数: ", length(cellMarker_list), "\n\n",
        "分析参数:\n",
        "- GSVA方法: ", input$gsva_method, "\n",
        "- 组1颜色: ", input$color_group1, "\n",
        "- 组2颜色: ", input$color_group2, "\n"
      )
      
      writeLines(report_text, 
                 file.path(result_dir, "06_analysis_report.txt"))
      
      # 压缩所有文件
      zip_files <- list.files(result_dir, full.names = TRUE)
      zip(file, zip_files, flags = "-j")
    }
  )
}

# 运行应用
shinyApp(ui = ui, server = server)